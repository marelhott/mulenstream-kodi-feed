import json
from functools import lru_cache
try:
    from urllib.parse import urlencode
    from urllib.request import urlopen, Request
except ImportError:  # py2 / py3
    from urllib import urlencode
    from urllib2 import urlopen, Request


@lru_cache(maxsize=256)
def translate_text(text, target_language='cs', source_language='auto'):
    if not text or not target_language:
        return text

    url = 'https://translate.googleapis.com/translate_a/single?{}'.format(urlencode({
        'client': 'gtx',
        'sl': source_language,
        'tl': target_language,
        'dt': 't',
        'q': text,
    }))
    request = Request(url, headers={'User-Agent': 'Kodi StreamVault metadata scraper'})
    try:
        response = urlopen(request, timeout=10)
        payload = response.read().decode('utf-8')
        data = json.loads(payload)
        parts = []
        for item in data[0]:
            if item and item[0]:
                parts.append(item[0])
        translated = ''.join(parts).strip()
        return translated or text
    except Exception:
        return text
