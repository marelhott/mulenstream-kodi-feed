# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.constants import ADDON, ADDON_ID
from resources.lib.kodiutils import create_plugin_url, get_setting, set_setting
from resources.lib.common.logger import info
from resources.lib.kodiutils import container_update
from resources.lib.gui import home_win
from resources.lib.gui.item import SCItem
from resources.lib.mulenstream.filmographies import FilmographyStore
from resources.lib.mulenstream.library import LibraryManager
from resources.lib.mulenstream.model import title_for
from resources.lib.mulenstream.rankings import PROVIDERS, RankingProvider, provider_definition
from resources.lib.params import params


ACTION = 'ms_action'


def _url(action=None, **values):
    payload = {}
    if action:
        payload['action'] = action
    payload.update(values)
    return create_plugin_url(payload)


def _item(label, action=None, folder=True, art=None, **values):
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'false')
    if art:
        li.setArt(art)
    return _url(action, **values), li, folder


def _end(items, content='files'):
    xbmcplugin.setContent(params.handle, content)
    xbmcplugin.addDirectoryItems(params.handle, items, len(items))
    xbmcplugin.endOfDirectory(params.handle, succeeded=True, cacheToDisc=False)


class MulenController(object):
    def ensure_legacy_account_identity(self):
        """Keep the kra.sk authorization token and device identifier paired.

        Stream Cinema stores the authorization token in the user's kra.sk
        storage.  When an account has been migrated from the legacy addon,
        that storage legitimately returns the same token, but the freshly
        installed MulenStream has a new local UUID.  The backend rejects that
        mixed pair with HTTP 503 before the selected stream is resolved.

        This is deliberately limited to a one-time compatibility migration
        for the same local kra.sk account.  A standalone MulenStream account
        keeps its own UUID.
        """
        if get_setting('mulen.account.identity_compatible') == 'true':
            return
        try:
            legacy = xbmcaddon.Addon('plugin.video.stream-cinema')
            current_user = get_setting('kraska.user')
            legacy_user = legacy.getSetting('kraska.user')
            legacy_uuid = legacy.getSetting('system.uuid')
            if current_user and current_user == legacy_user and legacy_uuid:
                set_setting('system.uuid', legacy_uuid)
                info('MulenStream: paired migrated kra.sk account with its existing device identity')
            set_setting('mulen.account.identity_compatible', 'true')
        except Exception:
            # The original addon is optional; retry on a later invocation if
            # Kodi cannot read its settings during startup.
            return

    def handles(self):
        action = params.args.get('action')
        return not params.args or (action and action.startswith('ms_'))

    def run(self):
        self.ensure_legacy_account_identity()
        action = params.args.get('action') or 'ms_root'
        handler = getattr(self, action, None)
        if not handler:
            xbmcgui.Dialog().notification('MulenStream', 'Neznámá akce', xbmcgui.NOTIFICATION_ERROR)
            return True
        handler()
        return True

    def ms_root(self):
        home_win.clearProperty('MulenStream.person.role')
        items = [
            _item('Filmy', 'ms_movies'),
            _item('Seriály', 'ms_series'),
            _item('Dokumenty', 'ms_documents'),
            _item('Hledat', 'ms_search'),
            _item('Žebříčky', 'ms_rankings'),
            _item('Filmografie', 'ms_filmographies'),
            _item('Nastavení', 'ms_settings_menu'),
        ]
        _end(items)

    def ms_movies(self):
        _end([
            _item('Nově přidané filmy', None, url='/FMovies/latest'),
            _item('Nejnovější filmové streamy', None, url='/FMovies/newstream'),
            _item('Katalog filmů', None, url='/FMovies'),
        ], 'movies')

    def ms_series(self):
        _end([
            _item('Nově přidané seriály', None, url='/FSeries/latest'),
            _item('Nejnovější epizody / streamy', None, url='/FSeries/newep'),
            _item('Katalog seriálů', None, url='/FSeries'),
        ], 'tvshows')

    def ms_documents(self):
        _end([
            _item('Nově přidané dokumenty', None, url='/Filter?mu[]=1795&o=datum'),
            _item('Nejnovější dokumentární streamy', None, url='/Filter?mu[]=1795&o=stream'),
            _item('Katalog dokumentů', None, url='/Filter?mu[]=1795'),
        ], 'movies')

    def ms_search(self):
        _end([
            _item('Podle názvu', 'ms_search_title'),
            _item('Podle režiséra', 'ms_search_person', role='director'),
            _item('Podle herce', 'ms_search_person', role='actor'),
        ])

    def ms_search_title(self):
        items = [
            _item('Filmy', 'ms_search_prompt', search_id='search-movies'),
            _item('Seriály', 'ms_search_prompt', search_id='search-series'),
        ]
        _end(items)

    def ms_search_person(self):
        role = params.args.get('role') or 'actor'
        home_win.setProperty('MulenStream.person.role', role)
        self.ms_search_prompt(search_id='search-people', role=role)

    def ms_search_prompt(self, search_id=None, role=None):
        """Run a catalogue search directly and always finish the Kodi folder.

        The legacy history router leaves a plugin directory open after a
        search action when entered from a custom root menu.  That manifests as
        an infinite spinner.  MulenStream owns this small, deterministic path.
        """
        search_id = search_id or params.args.get('search_id')
        role = role or params.args.get('role')
        if role in ('director', 'actor'):
            home_win.setProperty('MulenStream.person.role', role)
        labels = {
            'search-movies': 'Hledat film',
            'search-series': 'Hledat seriál',
            'search-people': 'Hledat režiséra nebo herce',
        }
        query = xbmcgui.Dialog().input(labels.get(search_id, 'Hledat'))
        if not query or not query.strip():
            _end([])
            return
        try:
            from resources.lib.api.sc import Sc
            request = {'search': query.strip(), 'id': search_id}
            if search_id == 'search-people':
                request['ms'] = '1'
            response = Sc.get('/Search/%s' % search_id, params=request) or {}
            items = []
            for record in response.get('menu') or []:
                item = SCItem(record)
                if item.visible:
                    items.append(item.get())
            _end(items, 'movies' if search_id != 'search-series' else 'tvshows')
            if not items:
                xbmcgui.Dialog().notification('MulenStream', 'Nic nenalezeno')
        except Exception as exc:
            xbmcgui.Dialog().ok('MulenStream', 'Hledání se nepodařilo dokončit.\n%s' % exc)
            _end([])

    def ms_filmographies(self):
        items = []
        for person in FilmographyStore().all():
            role = 'Režie' if person.get('role') == 'director' else 'Herec'
            count = person.get('count')
            suffix = '  •  %d titulů' % count if count is not None else ''
            li = xbmcgui.ListItem(label='%s: %s%s' % (role, person.get('name'), suffix))
            li.addContextMenuItems([('Přestat sledovat filmografii', 'Container.Update(%s)' %
                                    _url('ms_filmography_remove', key=person['key']))])
            items.append((_url('ms_filmography_open', key=person['key']), li, True))
        if not items:
            items.append(_item('Zatím nesledujete žádného režiséra ani herce', 'ms_noop', folder=False))
        _end(items, 'movies')

    def ms_filmography_follow(self):
        try:
            payload = json.loads(params.args.get('ms_payload') or '{}')
            role = payload.get('person_role')
            FilmographyStore().follow(role, title_for(payload), payload.get('url'))
            # Render a real directory after a context-menu command. Kodi 21
            # can otherwise keep a RunPlugin action in a permanent busy state.
            self.ms_filmographies()
        except Exception as exc:
            xbmcgui.Dialog().ok('MulenStream', 'Filmografii se nepodařilo přidat.\n%s' % exc)
            xbmcplugin.endOfDirectory(params.handle, succeeded=True, cacheToDisc=False)

    def ms_filmography_remove(self):
        FilmographyStore().remove(params.args.get('key'))
        self.ms_filmographies()

    def ms_filmography_open(self):
        person = FilmographyStore().get(params.args.get('key'))
        if not person:
            xbmcgui.Dialog().notification('MulenStream', 'Filmografie nebyla nalezena')
            _end([], 'movies')
            return
        from resources.lib.api.sc import Sc
        records = self._expand_collection(Sc, person.get('source_url'), role=person.get('role'),
                                          person=person.get('name'))
        records.sort(key=lambda record: int((record.get('info') or {}).get('year') or 0), reverse=True)
        home_win.setProperty('MulenStream.person.role', person.get('role') or '')
        items = []
        for record in records:
            item = SCItem(record)
            if item.visible:
                items.append(item.get())
        FilmographyStore().mark_loaded(person['key'], len(items))
        _end(items, 'movies')

    def ms_library(self):
        summary = LibraryManager().summary()
        items = [
            _item('Filmy (%d celkem)' % summary['items'], None, url='/FMovies'),
            _item('Aktualizovat knihovnu', 'ms_library_scan', folder=False),
            _item('Umístění: %s' % summary['root'], 'ms_library_location', folder=False),
        ]
        _end(items)

    def ms_library_add(self):
        raw = params.args.get('ms_payload')
        try:
            item = json.loads(raw)
            path = LibraryManager().add(item)
            xbmcgui.Dialog().notification('MulenStream', 'Uloženo do knihovny', xbmcgui.NOTIFICATION_INFO)
        except Exception as exc:
            xbmcgui.Dialog().ok('MulenStream', 'Titul se nepodařilo uložit.\n%s' % exc)

    def ms_library_collection(self):
        raw = params.args.get('ms_payload')
        try:
            payload = json.loads(raw)
            from resources.lib.api.sc import Sc
            items = self._expand_collection(
                Sc, payload.get('url'), role=payload.get('person_role'), person=payload.get('title')
            )
            title = payload.get('title') or 'Kolekce'
            result = LibraryManager().add_many(items, {
                'key': payload.get('id') or title, 'title': title,
                'tag': 'MulenStream: %s' % title, 'source_url': payload.get('url'), 'follow': True,
                'role': payload.get('person_role'), 'person': payload.get('title'),
            })
            xbmcgui.Dialog().ok('MulenStream', 'Uloženo: %d\nChyby: %d' %
                                (len(result['written']), len(result['errors'])))
        except Exception as exc:
            xbmcgui.Dialog().ok('MulenStream', 'Kolekci se nepodařilo uložit.\n%s' % exc)

    def _expand_collection(self, api, root_url, max_depth=4, role=None, person=None):
        found = []
        visited = set()

        def visit(url, depth):
            if not url or url in visited or depth > max_depth:
                return
            visited.add(url)
            response = api.get(url) or {}
            for item in response.get('menu') or []:
                kind = (item.get('info') or {}).get('mediatype')
                if item.get('type') == 'video' and kind in ('movie', 'episode'):
                    if self._person_matches(item, role, person):
                        found.append(item)
                elif item.get('type') in ('dir', 'hpdir') and item.get('url'):
                    visit(item.get('url'), depth + 1)

        visit(root_url, 0)
        return found

    @staticmethod
    def _person_matches(item, role, person):
        if role not in ('director', 'actor') or not person:
            return True
        wanted = person.strip().casefold()
        if role == 'director':
            values = (item.get('info') or {}).get('director') or []
            if isinstance(values, str):
                values = [values]
            return any(str(value).strip().casefold() == wanted for value in values)
        values = [entry.get('name', '') if isinstance(entry, dict) else str(entry)
                  for entry in (item.get('cast') or [])]
        return any(str(value).strip().casefold() == wanted for value in values)

    def ms_library_scan(self):
        LibraryManager().scan()
        xbmcgui.Dialog().notification('MulenStream', 'Aktualizace knihovny spuštěna')

    def ms_library_location(self):
        current = LibraryManager().root
        selected = xbmcgui.Dialog().browseSingle(3, 'Umístění knihovny MulenStream', 'files', defaultt=current)
        if selected:
            set_setting('mulen.library.path', selected.rstrip('/'))
            from resources.lib.mulenstream.platform import platform_id
            set_setting('mulen.library.platform', platform_id())
            set_setting('mulen.library.initialized', 'true')
            LibraryManager().setup()
            xbmcgui.Dialog().notification('MulenStream', 'Umístění knihovny uloženo')

    def ms_rankings(self):
        items = []
        for provider in PROVIDERS:
            connected = RankingProvider(provider['id']).available()
            suffix = '' if connected else '  •  vyžaduje autorizovaný feed'
            items.append(_item(provider['label'] + suffix, 'ms_ranking_provider', provider=provider['id']))
        _end(items)

    def ms_settings_menu(self):
        _end([
            _item('Nastavení MulenStream', 'ms_settings', folder=False),
            _item('Titulky Subtrans', 'ms_subtrans', folder=False),
            _item('Účet kra.sk', 'ms_account', folder=False),
        ])

    def ms_ranking_provider(self):
        provider_id = params.args.get('provider')
        definition = provider_definition(provider_id)
        provider = RankingProvider(provider_id)
        if not definition:
            return
        if not provider.available():
            xbmcgui.Dialog().ok('MulenStream',
                '%s zatím nemá nastavený autorizovaný datový feed. Přímý scraping není záměrně použit.' % definition['label'])
            return
        items = []
        for label in definition['lists']:
            url = _url('ms_ranking_list', provider=provider_id, list_id=label)
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems([
                ('Uložit celý žebříček do knihovny', 'RunPlugin(%s)' %
                 _url('ms_ranking_save', provider=provider_id, list_id=label, follow='false')),
                ('Sledovat žebříček a uložit dostupné', 'RunPlugin(%s)' %
                 _url('ms_ranking_save', provider=provider_id, list_id=label, follow='true')),
            ])
            items.append((url, li, True))
        _end(items)

    def ms_ranking_list(self):
        provider_id = params.args.get('provider')
        list_id = params.args.get('list_id')
        try:
            records = RankingProvider(provider_id).fetch(list_id)
        except Exception as exc:
            xbmcgui.Dialog().ok('MulenStream', 'Žebříček se nepodařilo načíst.\n%s' % exc)
            return
        items = []
        for position, record in enumerate(records, 1):
            label = '%d. %s' % (position, record.get('title') or 'Bez názvu')
            if record.get('year'):
                label += ' (%s)' % record['year']
            li = xbmcgui.ListItem(label=label)
            li.setProperty('IsPlayable', 'true')
            if record.get('art'):
                li.setArt(record['art'])
            payload = json.dumps(record, ensure_ascii=False, separators=(',', ':'))
            li.addContextMenuItems([('Uložit do knihovny', 'RunPlugin(%s)' %
                                    _url('ms_library_add', ms_payload=payload))])
            items.append((_url('ms_ranking_open', ms_payload=payload), li, False))
        _end(items, 'movies')

    def ms_ranking_open(self):
        """Resolve one external ranking entry to a playable kra.sk item."""
        try:
            record = json.loads(params.args.get('ms_payload') or '{}')
            from resources.lib.api.sc import Sc
            candidate = self._match_catalog_record(Sc, record)
            if not candidate:
                xbmcgui.Dialog().notification('MulenStream', 'Titul není v katalogu kra.sk')
                _end([])
                return
            item = SCItem(candidate)
            path, _list_item, _folder = item.get()
            if not path:
                raise ValueError('Katalog nevrátil přehratelnou položku')
            xbmc.executebuiltin('PlayMedia(%s)' % path)
            xbmcplugin.endOfDirectory(params.handle, succeeded=True, cacheToDisc=False)
        except Exception as exc:
            xbmcgui.Dialog().ok('MulenStream', 'Titul se nepodařilo otevřít.\n%s' % exc)
            _end([])

    def ms_ranking_save(self):
        provider_id = params.args.get('provider')
        list_id = params.args.get('list_id')
        follow = params.args.get('follow') == 'true'
        definition = provider_definition(provider_id) or {'label': provider_id}
        progress = xbmcgui.DialogProgress()
        progress.create('MulenStream', 'Připravuji žebříček %s' % list_id)
        matched = []
        try:
            records = RankingProvider(provider_id).fetch(list_id)
            from resources.lib.api.sc import Sc
            total = max(1, len(records))
            for index, record in enumerate(records):
                if progress.iscanceled():
                    break
                progress.update(int(index * 100 / total), 'Páruji %s' % (record.get('title') or 'titul'))
                item = record if record.get('url') else self._match_catalog_record(Sc, record)
                if item:
                    matched.append(item)
            title = '%s – %s' % (definition['label'], list_id)
            result = LibraryManager().add_many(matched, {
                'key': 'ranking:%s:%s' % (provider_id, list_id), 'title': title,
                'tag': 'MulenStream: %s' % title,
                'source_url': _url('ms_ranking_list', provider=provider_id, list_id=list_id),
                'provider': provider_id, 'list_id': list_id, 'follow': follow,
            })
            progress.close()
            xbmcgui.Dialog().ok('MulenStream',
                'Nalezeno: %d z %d\nUloženo: %d\nChyby: %d' %
                (len(matched), len(records), len(result['written']), len(result['errors'])))
        except Exception as exc:
            progress.close()
            xbmcgui.Dialog().ok('MulenStream', 'Žebříček se nepodařilo uložit.\n%s' % exc)

    @staticmethod
    def _match_catalog_record(api, record):
        title = str(record.get('title') or '').strip()
        if not title:
            return None
        response = api.get('/Search/search-movies', params={'search': title, 'id': 'search-movies'}) or {}
        wanted_ids = record.get('unique_ids') or {}
        wanted_year = str((record.get('info') or {}).get('year') or record.get('year') or '')
        for candidate in response.get('menu') or []:
            if candidate.get('type') != 'video':
                continue
            ids = candidate.get('unique_ids') or {}
            if any(wanted_ids.get(key) and str(wanted_ids[key]) == str(ids.get(key))
                   for key in ('imdb', 'tmdb')):
                return candidate
            from resources.lib.mulenstream.model import title_for
            candidate_year = str((candidate.get('info') or {}).get('year') or '')
            if title_for(candidate).casefold() == title.casefold() and (not wanted_year or candidate_year == wanted_year):
                return candidate
        return None

    def ms_collections(self):
        manifest = LibraryManager().load_manifest()
        items = []
        for collection in manifest.get('collections', {}).values():
            label = '%s  •  %d titulů' % (collection.get('title'), collection.get('count', 0))
            source_url = collection.get('source_url') or '/'
            if source_url.startswith('plugin://'):
                li = xbmcgui.ListItem(label=label)
                items.append((source_url, li, True))
            else:
                items.append(_item(label, None, url=source_url))
        if not items:
            items.append(_item('Zatím nemáte sledovanou kolekci', 'ms_noop', folder=False))
        _end(items)

    def ms_subtrans(self):
        try:
            addon = xbmcaddon.Addon('service.subtitles.subtrans')
            xbmc.executebuiltin('Addon.OpenSettings(service.subtitles.subtrans)')
        except Exception:
            xbmcgui.Dialog().ok('MulenStream', 'Subtrans není nainstalovaný.')

    def ms_account(self):
        current_user = get_setting('kraska.user')
        try:
            legacy = xbmcaddon.Addon('plugin.video.stream-cinema')
            legacy_user = legacy.getSetting('kraska.user')
            if not current_user and legacy_user:
                approved = xbmcgui.Dialog().yesno(
                    'MulenStream',
                    'Převzít přihlašovací údaje a kompatibilní identitu zařízení '
                    'z nainstalovaného Stream Cinema?\n'
                    'Tokeny ani historii MulenStream kopírovat nebude.'
                )
                if approved:
                    set_setting('kraska.user', legacy_user)
                    set_setting('kraska.pass', legacy.getSetting('kraska.pass'))
                    set_setting('kraska.token', '')
                    set_setting('system.auth_token', '')
                    set_setting('system.uuid', legacy.getSetting('system.uuid'))
                    set_setting('mulen.account.identity_compatible', 'true')
                    xbmcgui.Dialog().notification('MulenStream', 'Účet byl převzat')
                    return
        except Exception:
            pass
        ADDON.openSettings()

    def ms_settings(self):
        ADDON.openSettings()

    def ms_noop(self):
        return
