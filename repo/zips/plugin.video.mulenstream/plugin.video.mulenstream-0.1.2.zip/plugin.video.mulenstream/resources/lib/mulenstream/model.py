# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import re
import unicodedata
from xml.sax.saxutils import escape


_KODI_MARKUP = re.compile(r'\[(?:/?(?:B|I|COLOR|UPPERCASE|LOWERCASE)(?:=[^\]]+)?)\]', re.I)
_LANG_SUFFIX = re.compile(r'\s+-\s+(?:CZ|SK|EN|HU|DE|FR|ES|IT|PL|RU|UA|JP|KO|ZH)(?:[^()]*)$', re.I)


def clean_text(value):
    text = _KODI_MARKUP.sub('', str(value or '')).strip()
    return re.sub(r'\s+', ' ', text)


def safe_name(value, fallback='Untitled'):
    text = clean_text(value) or fallback
    text = unicodedata.normalize('NFC', text)
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip(' .')
    return text[:180] or fallback


def localized_block(item, language='cs'):
    blocks = item.get('i18n_info') or {}
    return blocks.get(language) or blocks.get('cs') or blocks.get('sk') or blocks.get('en') or {}


def localized_art(item, language='cs'):
    blocks = item.get('i18n_art') or {}
    return blocks.get(language) or blocks.get('cs') or blocks.get('sk') or blocks.get('en') or item.get('art') or {}


def title_for(item, language='cs'):
    info = item.get('info') or {}
    block = localized_block(item, language)
    title = block.get('otitle') or info.get('title') or block.get('title') or item.get('title')
    title = clean_text(title)
    title = _LANG_SUFFIX.sub('', title)
    year = info.get('year') or block.get('year')
    if year:
        title = re.sub(r'\s*\(%s\)\s*$' % re.escape(str(year)), '', title)
    return title or 'Untitled'


def media_type(item):
    value = (item.get('info') or {}).get('mediatype') or item.get('mediatype') or item.get('type')
    if value in ('episode', 'tvshow', 'movie'):
        return value
    if (item.get('info') or {}).get('season') is not None:
        return 'episode'
    return 'movie'


def compact_payload(item, language='cs'):
    """Keep context-menu URLs short and free of credentials."""
    info = dict(item.get('info') or {})
    allowed_info = ('year', 'rating', 'plot', 'genre', 'country', 'director', 'duration',
                    'mediatype', 'season', 'episode', 'tvshowtitle', 'aired', 'premiered')
    info = {key: info[key] for key in allowed_info if key in info}
    block = localized_block(item, language)
    if not info.get('plot') and block.get('plot'):
        info['plot'] = block.get('plot')
    if not info.get('genre') and block.get('genre'):
        info['genre'] = block.get('genre')
    cast = []
    for person in (item.get('cast') or [])[:30]:
        if isinstance(person, dict):
            cast.append({'name': person.get('name', ''), 'role': person.get('role', '')})
        else:
            cast.append({'name': str(person), 'role': ''})
    return {
        'id': item.get('id'),
        'url': item.get('url'),
        'type': item.get('type'),
        'title': title_for(item, language),
        'info': info,
        'cast': cast,
        'unique_ids': dict(item.get('unique_ids') or {}),
        'art': localized_art(item, language),
    }


def canonical_key(item):
    ids = item.get('unique_ids') or {}
    for namespace in ('imdb', 'tmdb', 'tvdb', 'sc'):
        if ids.get(namespace):
            return '%s:%s' % (namespace, ids[namespace])
    return 'sc:%s' % (item.get('id') or item.get('url') or safe_name(title_for(item)))


def nfo_xml(item, tags=None, language='cs'):
    info = item.get('info') or {}
    kind = media_type(item)
    root = 'episodedetails' if kind == 'episode' else ('tvshow' if kind == 'tvshow' else 'movie')
    block = localized_block(item, language)
    title = title_for(item, language)
    original = clean_text(block.get('otitle') or title)
    fields = [
        ('title', title), ('originaltitle', original), ('year', info.get('year')),
        ('plot', info.get('plot') or block.get('plot')), ('rating', info.get('rating')),
        ('runtime', int(info.get('duration', 0) / 60) if info.get('duration') else None),
        ('season', info.get('season')), ('episode', info.get('episode')),
        ('aired', info.get('aired') or info.get('premiered')),
    ]
    lines = ['<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>', '<%s>' % root]
    for name, value in fields:
        if value not in (None, '', []):
            lines.append('  <%s>%s</%s>' % (name, escape(clean_text(value)), name))
    for genre in (info.get('genre') or block.get('genre') or []):
        lines.append('  <genre>%s</genre>' % escape(clean_text(genre)))
    directors = info.get('director') or []
    if isinstance(directors, str):
        directors = [directors]
    for director in directors:
        lines.append('  <director>%s</director>' % escape(clean_text(director)))
    for actor in (item.get('cast') or [])[:50]:
        if not isinstance(actor, dict) or not actor.get('name'):
            continue
        lines.extend(['  <actor>', '    <name>%s</name>' % escape(clean_text(actor.get('name')))])
        if actor.get('role'):
            lines.append('    <role>%s</role>' % escape(clean_text(actor.get('role'))))
        lines.append('  </actor>')
    for namespace, value in sorted((item.get('unique_ids') or {}).items()):
        if value:
            default = ' default="true"' if namespace == 'imdb' else ''
            lines.append('  <uniqueid type="%s"%s>%s</uniqueid>' %
                         (escape(namespace), default, escape(clean_text(value))))
    for tag in sorted(set(tags or [])):
        lines.append('  <tag>%s</tag>' % escape(clean_text(tag)))
    art = item.get('art') or localized_art(item, language)
    if art.get('poster'):
        lines.append('  <thumb aspect="poster">%s</thumb>' % escape(clean_text(art['poster'])))
    if art.get('fanart'):
        lines.append('  <fanart><thumb>%s</thumb></fanart>' % escape(clean_text(art['fanart'])))
    lines.append('</%s>' % root)
    return '\n'.join(lines) + '\n'

