# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
import re

try:
    from html import unescape
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

from resources.lib.kodiutils import get_setting
from resources.lib.system import Http


PROVIDERS = (
    {'id': 'tmdb', 'label': 'TMDb', 'lists': ('Popular', 'Top Rated')},
    {'id': 'imdb', 'label': 'IMDb', 'lists': ('Top 250', 'Popular', 'By decade')},
    {'id': 'trakt', 'label': 'Trakt', 'lists': ('Trending', 'Most watched', 'Anticipated')},
    {'id': 'letterboxd', 'label': 'Letterboxd', 'lists': ('Top films', 'Popular this week', 'Curated lists')},
    {'id': 'criterion', 'label': 'Criterion', 'lists': ('Collection', 'Directors', 'Countries', 'Decades')},
)


TMDB_LIST_URLS = {
    'Popular': 'https://www.themoviedb.org/movie',
    'Top Rated': 'https://www.themoviedb.org/movie/top-rated',
}
_TMDB_CARD = re.compile(
    r'<div id="[^"]+" class="comp:poster-card.*?(?=<div id="[^"]+" class="comp:poster-card|<script)',
    re.DOTALL)
_TMDB_LINK = re.compile(r'href="/movie/(\d+)[^"]*"', re.DOTALL)
_TMDB_TITLE = re.compile(r'<img alt="([^"]+)"', re.DOTALL)
_TMDB_POSTER = re.compile(r'<img[^>]+\ssrc="([^"]+)"', re.DOTALL)
_TMDB_YEAR = re.compile(r'class="subheader[^"]*">\d{2}\.\d{2}\.(\d{4})', re.DOTALL)


def _tmdb_records(list_id):
    url = TMDB_LIST_URLS.get(list_id)
    if not url:
        return []
    response = Http.get(url, headers={
        'Accept-Language': 'en-US,en;q=0.8',
        'User-Agent': 'MulenStream Kodi/0.1',
    }, timeout=15)
    response.raise_for_status()
    records = []
    seen = set()
    for card in _TMDB_CARD.findall(response.text):
        identifier = _TMDB_LINK.search(card)
        title = _TMDB_TITLE.search(card)
        if not identifier or not title or identifier.group(1) in seen:
            continue
        seen.add(identifier.group(1))
        poster = _TMDB_POSTER.search(card)
        year = _TMDB_YEAR.search(card)
        records.append({
            'title': unescape(title.group(1)).strip(),
            'year': int(year.group(1)) if year else None,
            'unique_ids': {'tmdb': identifier.group(1)},
            'art': {'poster': unescape(poster.group(1))} if poster else {},
        })
    return records


class RankingProvider(object):
    """Small, auditable JSON-feed adapter.

    Direct scraping is intentionally excluded.  Each source can be connected to
    an authorised feed returning {lists:[...]} or a list of catalogue-shaped
    items.  This keeps source terms and catalogue matching outside Kodi UI code.
    """
    def __init__(self, provider_id):
        self.provider_id = provider_id

    @property
    def feed_url(self):
        return get_setting('mulen.rankings.%s.url' % self.provider_id).strip()

    def available(self):
        return self.provider_id == 'tmdb' or bool(self.feed_url)

    def fetch(self, list_id=None):
        if self.provider_id == 'tmdb':
            return _tmdb_records(list_id)
        if not self.feed_url:
            return []
        response = Http.get(self.feed_url, params={'list': list_id} if list_id else None, timeout=12)
        response.raise_for_status()
        data = response.json()
        if isinstance(data, dict):
            return data.get('items') or data.get('lists') or []
        return data if isinstance(data, list) else []


def provider_definition(provider_id):
    return next((item for item in PROVIDERS if item['id'] == provider_id), None)
