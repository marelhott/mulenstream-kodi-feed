# MulenStream

MulenStream is a library-first Kodi video addon for macOS and Android TV
(including NVIDIA Shield). It uses the existing catalogue/playback protocol,
but owns its library, collections and ranking workflow.

## Library contract

- macOS default: `~/Movies/MulenStream Library`
- NVIDIA Shield / Android TV default: `special://profile/addon_data/plugin.video.mulenstream/library`
- Both may be overridden with a Kodi VFS path such as SMB or NFS. Each device
  stores its own location; generated plugin URLs remain portable.
- Movies: `Movies/Title (Year)/Title (Year).strm` plus matching `.nfo`
- Episodes: `TV Shows/Show/Season NN/Show - SxxExx.strm` plus matching `.nfo`
- Stable plugin URLs are stored; resolved media URLs and credentials never are.
- `.mulenstream.json` is the source-of-truth manifest.
- `sources.xml` receives separate Movies and TV Shows sources. Because Kodi
  exposes no JSON-RPC call for assigning source content, MulenStream performs
  one narrow schema-checked upsert of those two exact paths in the latest
  MyVideos database and assigns the built-in `metadata.local` scraper. It does
  not alter or delete media records.

## Ranking feed contract

Direct scraping is intentionally excluded. Each configured feed URL must return
either a JSON list or `{ "items": [...] }`. Every item must already be matched
to the catalogue shape used by the addon and contain at least:

```json
{
  "id": "71173",
  "url": "/Play/m_example",
  "title": "Example",
  "info": {"mediatype": "movie", "year": 2026},
  "unique_ids": {"imdb": "tt0000000", "sc": "71173"}
}
```

This boundary keeps source licensing, rate limits and ambiguous-title matching
out of the Kodi client.

## Subtrans

`service.subtitles.subtrans >= 0.8.2` is an optional dependency. MulenStream
preserves the `SC.play_item` playback metadata contract so Subtrans can rank
and translate subtitles without a Trakt account.
