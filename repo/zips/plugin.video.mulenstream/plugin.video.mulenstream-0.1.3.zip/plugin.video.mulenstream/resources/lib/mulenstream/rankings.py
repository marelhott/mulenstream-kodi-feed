# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
import re

try:
    from html import unescape
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

from resources.lib.kodiutils import get_setting
from resources.lib.system import Http


PROVIDERS = (
    {'id': 'imdb', 'label': 'IMDb', 'lists': (
        'IMDb Top 250 filmů všech dob',
        'IMDb Nejpopulárnější filmy',
        'IMDb Top anglicky mluvené filmy',
    )},
    {'id': 'tmdb', 'label': 'TMDb — filmy a žánry', 'lists': (
        'Nejlépe hodnocené', 'Populární', 'Právě v kinech', 'Připravované',
        'Akční', 'Animované', 'Dobrodružné', 'Dokumentární', 'Drama',
        'Fantasy', 'Historické', 'Horory', 'Komedie', 'Krimi', 'Mysteriózní',
        'Rodinné', 'Romantické', 'Sci-fi', 'Thrillery', 'Válečné', 'Westerny',
    )},
    {'id': 'trakt', 'label': 'Trakt', 'lists': ('Trending', 'Most watched', 'Anticipated')},
    {'id': 'letterboxd', 'label': 'Letterboxd', 'lists': ('Top films', 'Popular this week', 'Curated lists')},
    {'id': 'criterion', 'label': 'Criterion', 'lists': ('Collection', 'Directors', 'Countries', 'Decades')},
)


TMDB_LIST_URLS = {
    'Nejlépe hodnocené': 'https://www.themoviedb.org/movie/top-rated',
    'Populární': 'https://www.themoviedb.org/movie',
    'Právě v kinech': 'https://www.themoviedb.org/movie/now-playing',
    'Připravované': 'https://www.themoviedb.org/movie/upcoming',
    'Akční': 'https://www.themoviedb.org/genre/28-action/movie',
    'Animované': 'https://www.themoviedb.org/genre/16-animation/movie',
    'Dobrodružné': 'https://www.themoviedb.org/genre/12-adventure/movie',
    'Dokumentární': 'https://www.themoviedb.org/genre/99-documentary/movie',
    'Drama': 'https://www.themoviedb.org/genre/18-drama/movie',
    'Fantasy': 'https://www.themoviedb.org/genre/14-fantasy/movie',
    'Historické': 'https://www.themoviedb.org/genre/36-history/movie',
    'Horory': 'https://www.themoviedb.org/genre/27-horror/movie',
    'Komedie': 'https://www.themoviedb.org/genre/35-comedy/movie',
    'Krimi': 'https://www.themoviedb.org/genre/80-crime/movie',
    'Mysteriózní': 'https://www.themoviedb.org/genre/9648-mystery/movie',
    'Rodinné': 'https://www.themoviedb.org/genre/10751-family/movie',
    'Romantické': 'https://www.themoviedb.org/genre/10749-romance/movie',
    'Sci-fi': 'https://www.themoviedb.org/genre/878-science-fiction/movie',
    'Thrillery': 'https://www.themoviedb.org/genre/53-thriller/movie',
    'Válečné': 'https://www.themoviedb.org/genre/10752-war/movie',
    'Westerny': 'https://www.themoviedb.org/genre/37-western/movie',
}
IMDB_CHARTS = {
    'IMDb Top 250 filmů všech dob': 'TOP_RATED_MOVIES',
    'IMDb Nejpopulárnější filmy': 'MOST_POPULAR_MOVIES',
    'IMDb Top anglicky mluvené filmy': 'TOP_RATED_ENGLISH_MOVIES',
}
IMDB_GRAPHQL_URL = 'https://api.graphql.imdb.com/'
_TMDB_CARD = re.compile(
    r'<div id="[^"]+" class="comp:poster-card.*?(?=<div id="[^"]+" class="comp:poster-card|<script)',
    re.DOTALL)
_TMDB_LINK = re.compile(r'href="/movie/(\d+)[^"]*"', re.DOTALL)
_TMDB_TITLE = re.compile(r'<img alt="([^"]+)"', re.DOTALL)
_TMDB_POSTER = re.compile(r'<img[^>]+\ssrc="([^"]+)"', re.DOTALL)
_TMDB_YEAR = re.compile(r'class="subheader[^"]*">\d{2}\.\d{2}\.(\d{4})', re.DOTALL)


def _tmdb_records(list_id):
    url = TMDB_LIST_URLS.get(list_id)
    if not url:
        return []
    response = Http.get(url, headers={
        'Accept-Language': 'en-US,en;q=0.8',
        'User-Agent': 'MulenStream Kodi/0.1',
    }, timeout=15)
    response.raise_for_status()
    records = []
    seen = set()
    for card in _TMDB_CARD.findall(response.text):
        identifier = _TMDB_LINK.search(card)
        title = _TMDB_TITLE.search(card)
        if not identifier or not title or identifier.group(1) in seen:
            continue
        seen.add(identifier.group(1))
        poster = _TMDB_POSTER.search(card)
        year = _TMDB_YEAR.search(card)
        records.append({
            'title': unescape(title.group(1)).strip(),
            'year': int(year.group(1)) if year else None,
            'unique_ids': {'tmdb': identifier.group(1)},
            'art': {'poster': unescape(poster.group(1))} if poster else {},
        })
    return records


def _imdb_records(list_id):
    """Read IMDb's chart API, keeping only the metadata Kodi needs.

    This is deliberately limited to the public chart endpoint and is suitable
    for the owner's private, non-commercial installation.  It avoids brittle
    HTML scraping and, unlike title-only lists, supplies the exact IMDb ID for
    catalogue matching.
    """
    chart_type = IMDB_CHARTS.get(list_id)
    if not chart_type:
        return []
    query = ('query { chartTitles(first: 250, chart: { chartType: %s }) '
             '{ edges { node { id titleText { text } releaseYear { year } '
             'primaryImage { url } ratingsSummary { aggregateRating } } } } }') % chart_type
    response = Http.post(IMDB_GRAPHQL_URL, json={'query': query}, headers={
        'Content-Type': 'application/json',
        'Origin': 'https://www.imdb.com',
        'User-Agent': 'MulenStream Kodi/0.1 (private use)',
    }, timeout=20)
    response.raise_for_status()
    payload = response.json() or {}
    nodes = ((payload.get('data') or {}).get('chartTitles') or {}).get('edges') or []
    records = []
    for edge in nodes:
        node = (edge or {}).get('node') or {}
        identifier = str(node.get('id') or '')
        title = ((node.get('titleText') or {}).get('text') or '').strip()
        if not identifier.startswith('tt') or not title:
            continue
        release_year = (node.get('releaseYear') or {}).get('year')
        image = (node.get('primaryImage') or {}).get('url')
        rating = (node.get('ratingsSummary') or {}).get('aggregateRating')
        record = {
            'title': title,
            'year': int(release_year) if release_year else None,
            'unique_ids': {'imdb': identifier},
            'art': {'poster': image} if image else {},
        }
        if rating is not None:
            record['rating'] = rating
        records.append(record)
    return records


class RankingProvider(object):
    """Small, auditable JSON-feed adapter.

    Direct scraping is intentionally excluded.  Each source can be connected to
    an authorised feed returning {lists:[...]} or a list of catalogue-shaped
    items.  This keeps source terms and catalogue matching outside Kodi UI code.
    """
    def __init__(self, provider_id):
        self.provider_id = provider_id

    @property
    def feed_url(self):
        return get_setting('mulen.rankings.%s.url' % self.provider_id).strip()

    def available(self):
        return self.provider_id in ('tmdb', 'imdb') or bool(self.feed_url)

    def fetch(self, list_id=None):
        if self.provider_id == 'tmdb':
            return _tmdb_records(list_id)
        if self.provider_id == 'imdb':
            return _imdb_records(list_id)
        if not self.feed_url:
            return []
        response = Http.get(self.feed_url, params={'list': list_id} if list_id else None, timeout=12)
        response.raise_for_status()
        data = response.json()
        if isinstance(data, dict):
            return data.get('items') or data.get('lists') or []
        return data if isinstance(data, list) else []


def provider_definition(provider_id):
    return next((item for item in PROVIDERS if item['id'] == provider_id), None)
