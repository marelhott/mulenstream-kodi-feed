from __future__ import print_function, unicode_literals

import time
import traceback

import xbmcaddon

from resources.lib.api.kraska import getKraInstance
from resources.lib.common.logger import debug, info
from resources.lib.constants import ADDON, ADDON_ID, MEM_PROFILER_ENABLED, MEM_PROFILER_INTERVAL
from resources.lib.gui.dialog import dtextviewer, dnotify
from resources.lib.language import Strings
from resources.lib.kodiutils import set_setting, get_uuid, get_setting, exec_build_in, get_setting_as_bool, \
    clean_textures
from resources.lib.services.monitor import monitor
from resources.lib.services.player import player
from resources.lib.services.next_episodes import NextEp
from resources.lib.services.mem_profiler import mem_profiler


class Service:
    next_ep = None
    monitor = None
    player = None
    atv = None
    startup_time = None

    # Oneskorenie (v sekundách) pred kontrolou SC Helpera po štarte.
    # Beží v samostatnom threade, aby na slabších CPU neblokoval štart Kodi.
    HELPER_CHECK_STARTUP_DELAY = 30

    @staticmethod
    def _adopt_migrated_account_identity():
        """Pair a migrated kra.sk account with its existing SC device UUID.

        The account's authorization backup is shared by the two addons.  A
        fresh MulenStream UUID plus that existing token is rejected by the
        stream backend before kra.sk can resolve the item.
        """
        if get_setting('mulen.account.identity_compatible') == 'true':
            return
        try:
            legacy = xbmcaddon.Addon('plugin.video.stream-cinema')
            if (get_setting('kraska.user') and
                    get_setting('kraska.user') == legacy.getSetting('kraska.user') and
                    legacy.getSetting('system.uuid')):
                set_setting('system.uuid', legacy.getSetting('system.uuid'))
                info('MulenStream: migrated kra.sk device identity paired')
            set_setting('mulen.account.identity_compatible', 'true')
        except Exception:
            info('MulenStream: migrated account identity could not be checked')

    def __init__(self):
        set_setting('system.ver', ADDON.getAddonInfo('version'))
        self._adopt_migrated_account_identity()
        get_uuid()
        # Starý AndroidTv writer používal skryté odstraněné nastavení a přímé
        # zásahy do Kodi databáze. MulenStream má jednotný VFS LibraryManager.
        self.atv = None
        self.startup_time = time.time()

    def run(self):
        debug('START SERVICE....................................................................')
        if MEM_PROFILER_ENABLED:
            mem_profiler.start()
        _last_mem_log = 0
        last_changelog = get_setting('system.changelog')

        # MulenStream se distribuuje vlastním ZIP/repozitářem. Původní SC
        # updater vynucoval cizí repozitář a při každém startu zobrazoval modal.

        # Kraska prihlásenie + user_info presunuté do samostatného daemon vlákna.
        # Sieťový request na api.kra.sk môže pri DNS/SSL/sieťovom probléme uviaznuť
        # (aj napriek timeoutu) a NESMIE blokovať štart hlavnej service slučky
        # (NextEp, helper, mem profiler). Rovnaký vzor ako check_helper_on_startup.
        from threading import Thread
        kraska_thread = Thread(target=self.kraska_startup)
        kraska_thread.daemon = True
        kraska_thread.start()

        # Sledované filmografie a žebříčky se obnovují se zpožděním, aby start
        # Kodi na Shield TV neblokovaly síťové požadavky ani scan knihovny.
        collections_thread = Thread(target=self.update_mulenstream_collections)
        collections_thread.daemon = True
        collections_thread.start()

        library_thread = Thread(target=self.initialize_mulenstream_library)
        library_thread.daemon = True
        library_thread.start()

        debug('SERVICE init: kraska vlakno spustene, pokracujem')

        if last_changelog != ADDON.getAddonInfo('version'):
            debug('SYSTEM.CHANGELOG: {}'.format(ADDON.getAddonInfo('changelog')))
            set_setting('system.changelog', '{}'.format(ADDON.getAddonInfo('version')))
            dtextviewer('', ADDON.getAddonInfo('changelog'))
        debug('SERVICE init: changelog OK')

        if get_setting_as_bool('system.autoexec'):
            try:
                exec_build_in('ActivateWindow(videos,plugin://{})'.format(ADDON_ID))
            except Exception:
                pass
        debug('SERVICE init: autoexec OK')

        # POZN.: check_user() (volá user_info → sieť) presunuté do kraska_startup vlákna.

        # if get_setting_as_bool('system.ws.remote.enable'):
        #     ws = websocket.WS()
        #     ws.reconnect()

        self.next_ep = NextEp()
        debug('SERVICE init: NextEp OK')

        # clean_textures() presunuté do daemon vlákna — TexturesDb().clean() (SQLite) môže
        # visieť na DB zámku, keď UI thread práve číta artwork (navigácia používateľa),
        # a NESMIE blokovať štart hlavnej service slučky.
        ct = Thread(target=clean_textures)
        ct.daemon = True
        ct.start()
        debug('SERVICE init: clean_textures vo vlakne, vstupujem do hlavnej slucky')

        # MenuCacheServer sa inicializuje automaticky pri prvom použití (lazy loading)
        # Voliteľne: Preheat homepage cache pre lepší UX
        # try:
        #     debug('MenuCacheServer: Preheating homepage cache...')
        #     menu_cache_server.run()
        # except:
        #     debug('MenuCacheServer preheat error: {}'.format(traceback.format_exc()))
        #     pass

        # Spusti player thread
        w = Thread(target=player.run)
        w.start()

        # Kontrola SC Helpera po štarte - samostatný daemon thread s oneskorením,
        # aby na slabších CPU neblokoval/nespomaľoval štart Kodi
        h = Thread(target=self.check_helper_on_startup)
        h.daemon = True
        h.start()

        # Per-media_id cooldown — zabraňuje opakovanej ponuke pre ten istý stream
        _bug_offer_cooldown = set()

        # Cross-process dirty-marker gating (viz storage.mark_dirty/get_dirty) —
        # force-reload (load(True)) sa vykoná IBA pri zmene markera od poslednej
        # videnej hodnoty. None zaručuje 1 počiatočný load(True) hneď pri štarte
        # service (get_dirty vždy vráti hodnotu odlišnú od None, aj keď marker
        # ešte nikdy nebol nastavený). Per-cycle Storage(...) re-inštanciácia
        # (load(force=False) resync cez _storage_cache) OSTÁVA nedotknutá nižšie.
        _play_ts_last_dirty = None

        while not monitor.abortRequested():
            # 4.6: fail-timeout vyhodnotenie (fix #4) — v KAŽDOM cykle (nie periodical_check)
            # Musí bežať aj počas pokusu o štart (periodical_check early-returnuje)
            try:
                from resources.lib.common.storage import Storage, get_dirty
                from resources.lib.constants import SC
                _play_storage = Storage(SC.BUG_REPORT_PLAY_TS)
                _current_dirty = get_dirty(SC.BUG_REPORT_PLAY_TS)
                if _current_dirty != _play_ts_last_dirty:
                    _play_storage.load(True)
                    _play_ts_last_dirty = _current_dirty
                _ts = _play_storage.get('ts')
                if _ts is not None:
                    _elapsed = time.time() - float(_ts)
                    _media_id = _play_storage.get('media_id') or ''
                    if _elapsed > SC.BUG_REPORT_FAIL_TIMEOUT and _media_id not in _bug_offer_cooldown:
                        from resources.lib.gui.dialog import dnotify
                        from resources.lib.language import Strings
                        dnotify(
                            heading=Strings.txt(Strings.CONTEXT_BUG_REPORT),
                            message=Strings.txt(Strings.BUG_REPORT_OFFER),
                            sound=False,
                        )
                        _bug_offer_cooldown.add(_media_id)
                        _play_storage['ts'] = None
                        debug('BugReport: fail-timeout offer fired for media_id={}'.format(_media_id))
            except Exception:
                debug('bug report fail-timeout err: {}'.format(traceback.format_exc()))

            # 5.1: drain bug report inbox + spracuj frontu na pozadí
            try:
                from resources.lib.services.bug_report.queue import bug_report_queue_service
                bug_report_queue_service.drain_inbox()
                bug_report_queue_service.process_queue()
                bug_report_queue_service.process_deferred_queue()
            except Exception:
                debug('bug report queue err: {}'.format(traceback.format_exc()))

            try:
                self.periodical_check()
            except Exception:
                debug('error: {}'.format(traceback.format_exc()))

            # Pamäťový profiler — periodický výpis TOP alokácií + rastu (leak).
            # Aktívne len pri MEM_PROFILER_ENABLED, inak nulová réžia.
            if MEM_PROFILER_ENABLED and (time.time() - _last_mem_log) >= MEM_PROFILER_INTERVAL:
                _last_mem_log = time.time()
                try:
                    mem_profiler.log_top()
                    mem_profiler.log_growth()
                except Exception:
                    debug('mem profiler err: {}'.format(traceback.format_exc()))

            # Abort-aware čakanie namiesto chunkovaného sleep() - okamžité
            # ukončenie hlavnej slučky pri vypnutí Kodi (rovnaký monitor
            # objekt ako v podmienke while, žiadny duplicitný abort-check).
            if monitor.waitForAbort(5):
                break

    def kraska_startup(self):
        """Úvodné Kraska prihlásenie + user_info v samostatnom daemon vlákne.

        Sieťový request na api.kra.sk (get_token/user_info/login/check_user) môže pri
        DNS/SSL/sieťovom probléme uviaznuť aj napriek nastavenému timeoutu. V daemon
        vlákne to neblokuje štart hlavnej service slučky; vlákno sa ukončí s Kodi.
        """
        kr = getKraInstance()
        try:
            if kr.username and kr.password:
                kr.get_token()
                kr.user_info()
        except Exception:
            debug('Kraska login error: {}'.format(traceback.format_exc()))
            try:
                kr.login()
            except Exception:
                debug('Kraska re-login failed: {}'.format(traceback.format_exc()))

        if get_setting('kraska.user'):
            try:
                getKraInstance().check_user()
            except Exception:
                debug('check_user err: {}'.format(traceback.format_exc()))

    def check_helper_on_startup(self):
        """Skontroluje SC Helper po štarte; ak nebeží, skúsi ho reštartnúť.

        Beží v samostatnom daemon threade s oneskorením, aby kontrola
        nezaťažila štart Kodi na slabších CPU.
        """
        # Abort-aware čakanie - pri ukončení Kodi sa thread hneď skončí
        if monitor.waitForAbort(self.HELPER_CHECK_STARTUP_DELAY):
            return
        try:
            kr = getKraInstance()
            port = kr.check_and_restart_helper()
            if port:
                debug('startup check: sc.helper bezi na porte {}'.format(port))
            else:
                debug('startup check: sc.helper sa nepodarilo nastartovat')
                dnotify(Strings.txt(Strings.HELPER_ERROR_H1),
                        Strings.txt(Strings.HELPER_START_FAILED_L1))
        except Exception:
            debug('startup helper check err: {}'.format(traceback.format_exc()))

    def update_mulenstream_collections(self):
        if monitor.waitForAbort(60):
            return
        from resources.lib.mulenstream.updater import UPDATE_INTERVAL, update_followed_collections
        while not monitor.abortRequested():
            try:
                result = update_followed_collections()
                debug('MulenStream collections: {} updated, {} written'.format(
                    result.get('updated', 0), result.get('written', 0)))
            except Exception:
                debug('MulenStream collections update error: {}'.format(traceback.format_exc()))
            if monitor.waitForAbort(UPDATE_INTERVAL):
                return

    def initialize_mulenstream_library(self):
        # Source manager and MyVideos DB need a moment to finish Kodi startup.
        if monitor.waitForAbort(5):
            return
        try:
            from resources.lib.mulenstream.library import LibraryManager
            manager = LibraryManager()
            root = manager.setup()
            debug('MulenStream native Kodi library sources ready: {}'.format(root))
            # 0.2.3 doplnila tvshow.nfo/showtitle a sloucila jazykove varianty
            # do stabilnich adresaru. Uz ulozene serialy ale Kodi neuvidi,
            # dokud po startu neprobehne skutecny scan TV zdroje. Udelej ho
            # jednou uvnitr Kodi (sitovy EventServer/JSON-RPC muze byt vypnuty).
            if get_setting('mulen.library.tvshows_schema') != '1':
                import json
                response = json.loads(manager.scan(manager.shows_root) or '{}')
                if not response.get('error'):
                    set_setting('mulen.library.tvshows_schema', '1')
                    info('MulenStream: one-time stored TV show library scan started')
                else:
                    debug('MulenStream stored TV show scan rejected: {}'.format(response))
        except Exception:
            debug('MulenStream library source setup error: {}'.format(traceback.format_exc()))

    def periodical_check(self):
        if monitor.can_check():
            # try:
            #     player.periodical_check()
            # except:
            #     debug('player err: {}'.format(traceback.format_exc()))
            #     pass

            try:
                monitor.periodical_check()
            except Exception:
                debug('monitor err: {}'.format(traceback.format_exc()))
                pass

            try:
                if self.atv:
                    self.atv.run()
            except Exception:
                debug('android tv err: {}'.format(traceback.format_exc()))
                pass

            try:
                # NextEp používa TimerService API
                self.next_ep.start(monitor=monitor, player=player)
            except Exception:
                debug('nextep err: {}'.format(traceback.format_exc()))
                pass


service = Service()
