# -*- coding: utf-8 -*-
"""
TC resolver (Torrentio + Comet) pre MulenStream.

Vezme IMDb ID titulu (a pre serial aj sezonu/epizodu), zavola Torrentio
a Comet stream endpoint s nakonfigurovanym Real-Debrid klucom a vrati
zoznam streamov kompatibilnych s `strms[]` kontraktom SC backendu
(provider, quality, size, url, ...). Iba streamy s `url` (cached v RD)
sa pouzivaju — nehraaudio z ne-cached torrentov je pomale a neziaduce.
"""
from __future__ import unicode_literals

import re
import traceback

from resources.lib.common.logger import debug, info
from resources.lib.constants import SC
from resources.lib.kodiutils import get_setting, get_setting_as_bool
from resources.lib.system import Http


class TCException(Exception):
    pass


# Zoradovanie kvality (vyssie = lepsie) pre primarny fallback sort.
_QUALITY_RANK = {
    '4k': 5, '2160p': 5,
    '1080p': 4,
    '720p': 3,
    '480p': 2,
    'sd': 1,
}

# Torrentio interpretuje qualityfilter ako zoznam kvalit na VYLUCENIE, nie
# strop ("qualityfilter=1080p" teda znamena "bez 1080p", nie "najviac
# 1080p"). Pre kazdy strop treba poslat vsetky tokeny NAD nim.
_QUALITY_EXCLUDE_ABOVE = {
    '1080p': ('4k', '2160p'),
    '720p': ('4k', '2160p', '1080p'),
    '480p': ('4k', '2160p', '1080p', '720p'),
    'sd': ('4k', '2160p', '1080p', '720p', '480p'),
}
_SIZE_RE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|TB)', re.IGNORECASE)
_QUALITY_RE = re.compile(r'\b(2160p|1080p|720p|480p|4k)\b', re.IGNORECASE)


def _bytes_from_size_str(text):
    """Pretvori '4.2 GB' / '800 MB' na byty (int) alebo 0."""
    if not text:
        return 0
    m = _SIZE_RE.search(text)
    if not m:
        return 0
    val = float(m.group(1))
    unit = m.group(2).upper()
    if unit == 'TB':
        return int(val * 1024 ** 4)
    if unit == 'GB':
        return int(val * 1024 ** 3)
    if unit == 'MB':
        return int(val * 1024 ** 2)
    return 0


def _parse_quality(name):
    """Z nazvu releasu (napr. 'Movie.2024.1080p.BluRay.x264') vytiahne
    rozlisenie ako lowercase token ('1080p', '4k', ...)."""
    if not name:
        return ''
    m = _QUALITY_RE.search(name)
    if m:
        q = m.group(1).lower()
        return '4k' if q == '2160p' else q
    return ''


class TCResolver(object):
    """Resolver filmov/serialov cez Torrentio a Comet s RD klucom."""

    def __init__(self):
        self.torrentio_enabled = get_setting_as_bool('tc.torrentio.enabled')
        self.comet_enabled = get_setting_as_bool('tc.comet.enabled')
        self.torrentio_url = (get_setting('tc.torrentio.url') or
                              'https://torrentio.strem.fun').rstrip('/')
        self.comet_url = (get_setting('tc.comet.url') or
                          'https://comet.elfhosted.com').rstrip('/')
        self.providers = (get_setting('tc.providers') or '').strip()
        self.quality = (get_setting('tc.quality') or 'all').strip()
        if self.quality == '0' or not self.quality:
            self.quality = 'all'
        self.maxsize_gb = self._get_int('tc.maxsize', 0)
        self.sort_mode = (get_setting('tc.sort') or 'quality').strip()

        # Real-Debrid token (lazy)
        self._rd_token = None

    @staticmethod
    def _get_int(key, default=0):
        from resources.lib.kodiutils import get_setting_as_int
        v = get_setting_as_int(key)
        return v if v is not None else default

    def _rd_key(self):
        if self._rd_token is None:
            from resources.lib.api.realdebrid import getRDInstance
            self._rd_token = getRDInstance().get_token()
        return self._rd_token

    def is_configured(self):
        """Ci je aspon jeden resolver povoleny a mame RD token."""
        if not (self.torrentio_enabled or self.comet_enabled):
            return False
        return bool(self._rd_key())

    # ------------------------------------------------------------------
    # URL builder
    # ------------------------------------------------------------------
    def _config_segment(self, providers=None):
        """Posklada path segment s konfiguraciou podla nastavenia.
        Pre Torrentio: providers=...|qualityfilter=...|realdebrid=KEY
        Pre Comet sa parameter lisi — pozri _comet_url().

        `providers` prebije globalne nastavenie tc.providers — art sekcia
        tak moze sahat na ine trackery ako bezna TC sekcia.
        """
        parts = []
        active = providers if providers is not None else self.providers
        if active:
            parts.append('providers={}'.format(active))
        if self.quality and self.quality != 'all':
            exclude = _QUALITY_EXCLUDE_ABOVE.get(self.quality)
            if exclude:
                parts.append('qualityfilter={}'.format(','.join(exclude)))
        key = self._rd_key()
        if key:
            parts.append('realdebrid={}'.format(key))
        if not parts:
            return ''
        return '/' + '|'.join(parts)

    def _torrentio_stream_url(self, kind, imdb_id, season=None, episode=None, providers=None):
        """kind: 'movie' alebo 'series'."""
        seg = self._config_segment(providers)
        if kind == 'series':
            if not season or not episode:
                # Bez sezony/epizody nemozeme resolvovat serial.
                return None
            tail = 'stream/series/{}:{}:{}.json'.format(imdb_id, season, episode)
        else:
            tail = 'stream/movie/{}.json'.format(imdb_id)
        return '{}{}/{}'.format(self.torrentio_url, seg, tail)

    def _comet_stream_url(self, kind, imdb_id, season=None, episode=None):
        """Comet konfiguracny mechanismus sa lisi od Torrentia — Comet
        ocakava kluc a konfiguraciu typicky v query stringu alebo v
        per-instance konfiguracii. Pre jednoduchost podporujeme zakladny
        public ElfHosted pattern: /{key}/{type}/{id}.json.
        Comet stale potrebuje RD kluc v konfiguracii; tu predpokladame,
        ze uzivatel nakonfiguroval Comet instance (manifest) sam a my
        len volame stream endpoint s jeho base URL.

        Ak Comet URL neobsahuje konfiguracny segment (/public), volanie
        zlyha — Comet je volitelny fallback.
        """
        key = self._rd_key()
        # Comet obvykle: https://comet.elfhosted.com/userdata/{uuid}/stream/...
        # Zjednodusene pouzijeme base + /stream + cesta.
        if kind == 'series':
            if not season or not episode:
                return None
            tail = 'stream/series/{}:{}:{}.json'.format(imdb_id, season, episode)
        else:
            tail = 'stream/movie/{}.json'.format(imdb_id)
        # Comet public ElfHosted: niektore instancie podporuju ?debridType=realdebrid
        url = '{}/{}?debridType=realdebrid'.format(self.comet_url, tail)
        if key:
            url += '&debridApiKey={}'.format(key)
        return url

    # ------------------------------------------------------------------
    # Fetch
    # ------------------------------------------------------------------
    def _fetch(self, url, label):
        """Zavola JSON endpoint a vrati zoznam streamov (list) alebo []."""
        if not url:
            return []
        # RD kluc v URL — nenechavaj ho v debug logu v celom zneni.
        debug('TC[{}] request: {}'.format(label, self._safe_url(url)))
        try:
            resp = Http.get(url, timeout=20)
            if resp.status_code != 200:
                debug('TC[{}] HTTP {}'.format(label, resp.status_code))
                return []
            data = resp.json() or {}
            streams = data.get('streams') or []
            debug('TC[{}] returned {} streams'.format(label, len(streams)))
            return streams
        except Exception:
            debug('TC[{}] chyba: {}'.format(label, traceback.format_exc()))
            return []

    @staticmethod
    def _safe_url(url):
        """Maskuj debrid API kluc v URL pre debug log."""
        return re.sub(r'(realdebrid=|debridApiKey=)[^&|]+', r'\1***', url or '')

    # ------------------------------------------------------------------
    # Normalize to SC strms[] contract
    # ------------------------------------------------------------------
    def _to_sc_stream(self, stremio_stream, source):
        """Konvertuje Stremio stream objekt na SC strms[] dict.
        Vracia dict alebo None (ak stream nema 'url' — ne-cached)."""
        url = stremio_stream.get('url')
        # InfoHash-only streamy neumoznuju okamzite prehravanie bez P2P — preskoc.
        if not url:
            return None

        title = stremio_stream.get('title') or ''
        name = stremio_stream.get('name') or source
        # Extrahuj metadata z nazvu/titulu.
        quality = _parse_quality(title) or _parse_quality(name)
        size_bytes = _bytes_from_size_str(title)
        size_human = '{} GB'.format(round(size_bytes / 1024 ** 3, 1)) if size_bytes else ''

        # Filtr velkosti.
        if self.maxsize_gb and size_bytes and size_bytes > self.maxsize_gb * 1024 ** 3:
            return None
        # Filtr kvality (ak je nastaveny) — vyluc streamy nad dovolenou kvalitou
        # (napr. nastavene 1080p => 4K sa vynecha).
        if self.quality and self.quality != 'all' and quality:
            allowed_rank = _QUALITY_RANK.get(self.quality, 99)
            stream_rank = _QUALITY_RANK.get(quality, 0)
            if stream_rank > allowed_rank:
                return None

        # vinfo / ainfo heuristika z nazvu releasu.
        # Povodne alternacie (`\bHEVC|x265|h265\b`) mali `\b` naviazane len
        # na prvy/posledny clen — vsetko medzi nimi bolo bez hranice slova.
        # `DD+` navyse ako regex znamena "D nasledovane 1+ D", nie literal.
        vinfo = ''
        ainfo = ''
        if re.search(r'\b(?:HEVC|x265|h265)\b', title, re.I):
            vinfo = 'HEVC'
        elif re.search(r'\b(?:x264|h264)\b', title, re.I):
            vinfo = 'AVC'
        audio_match = re.search(r'\b(Atmos|DDP|EAC3|DD\+|AC3|DTS)\b', title, re.I)
        if audio_match:
            ainfo = audio_match.group(1).upper()

        return {
            SC.ITEM_ID: '{}-{}'.format(source, stremio_stream.get('infoHash', '') or url[-16:]),
            SC.ITEM_IDENT: url,
            SC.ITEM_LANG: 'EN',
            SC.ITEM_PROVIDER: SC.PROVIDER_TORRENTIO if source == 'torrentio' else SC.PROVIDER_COMET,
            SC.ITEM_QUALITY: quality or 'SD',
            SC.ITEM_SIZE: size_human,
            SC.ITEM_URL: url,
            SC.ITEM_VIDEO_INFO: vinfo,
            SC.ITEM_AUDIO_INFO: ainfo,
            # Internal metadata pre sort + UI.
            '_source': source,
            '_name': name,
            '_title': title,
            '_size_bytes': size_bytes,
            '_quality_rank': _QUALITY_RANK.get(quality, 0),
        }

    def _sort_streams(self, streams):
        """Zoradi streamy podla nastavenia."""
        if self.sort_mode == 'size':
            return sorted(streams, key=lambda s: s.get('_size_bytes', 0), reverse=True)
        if self.sort_mode == 'seeders':
            # Torrentio/Comet neposielaju seeders priamo — fallback na quality.
            return sorted(streams, key=lambda s: s.get('_quality_rank', 0), reverse=True)
        # default: quality (potom velkost)
        return sorted(streams, key=lambda s: (s.get('_quality_rank', 0),
                                              s.get('_size_bytes', 0)), reverse=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def resolve_movie(self, imdb_id, providers=None):
        """Vrati zoznam SC strms[] dictov pre film.

        `providers` prebije nastavenie tc.providers len pre toto volanie
        (art sekcia posiela vlastny zoznam trackerov)."""
        if not imdb_id:
            return []
        streams = []
        if self.torrentio_enabled:
            url = self._torrentio_stream_url('movie', imdb_id, providers=providers)
            streams.extend(self._normalize(self._fetch(url, 'torrentio'), 'torrentio'))
        if self.comet_enabled:
            url = self._comet_stream_url('movie', imdb_id)
            streams.extend(self._normalize(self._fetch(url, 'comet'), 'comet'))
        streams = self._dedupe(streams)
        streams = self._sort_streams(streams)
        info('TC resolve_movie {}: {} streamov'.format(imdb_id, len(streams)))
        return streams

    def resolve_series(self, imdb_id, season, episode):
        """Vrati zoznam SC strms[] dictov pre epizodu serialu."""
        if not imdb_id or not season or not episode:
            return []
        streams = []
        if self.torrentio_enabled:
            url = self._torrentio_stream_url('series', imdb_id, season, episode)
            streams.extend(self._normalize(self._fetch(url, 'torrentio'), 'torrentio'))
        if self.comet_enabled:
            url = self._comet_stream_url('series', imdb_id, season, episode)
            streams.extend(self._normalize(self._fetch(url, 'comet'), 'comet'))
        streams = self._dedupe(streams)
        streams = self._sort_streams(streams)
        info('TC resolve_series {} S{:02d}E{:02d}: {} streamov'.format(
            imdb_id, season, episode, len(streams)))
        return streams

    def _normalize(self, stremio_streams, source):
        out = []
        for ss in stremio_streams or []:
            sc = self._to_sc_stream(ss, source)
            if sc is not None:
                out.append(sc)
        return out

    def _dedupe(self, streams):
        """Odstran duplikaty podla URL."""
        seen = set()
        out = []
        for s in streams:
            u = s.get(SC.ITEM_URL)
            if u and u not in seen:
                seen.add(u)
                out.append(s)
        return out


_resolver_instance = None


def getTCResolver():
    """Singleton — instancia sa znovu vytvori pri zmene nastavenia."""
    global _resolver_instance
    # Vzdy precitaj nastavenia nanovo (settings sa mozu menit bez restartu).
    _resolver_instance = TCResolver()
    return _resolver_instance
