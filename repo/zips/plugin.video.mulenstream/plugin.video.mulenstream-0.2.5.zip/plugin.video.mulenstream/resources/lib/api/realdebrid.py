# -*- coding: utf-8 -*-
"""
Real-Debrid klient pre MulenStream TC sekciu.

Implementuje OAuth2 device flow (QR / PIN prihlasenie) a zakladne
volania potrebne pre TC resolver (overenie ucet, instant availability).

Inspirovane strukturou kraska.py: singleton, get_setting/set_setting,
Http wrapper z system.py, lokalizacia cez Strings.
"""
from __future__ import unicode_literals

import os
import threading
import time
import traceback

import xbmc
import xbmcgui

from resources.lib.common.logger import debug, info
from resources.lib.constants import ADDON
from resources.lib.gui.dialog import dok, dnotify
from resources.lib.kodiutils import get_setting, set_setting, translate_path
from resources.lib.language import Strings
from resources.lib.system import Http

# Real-Debrid API
BASE_API = 'https://api.real-debrid.com'
BASE_OAUTH = 'https://api.real-debrid.com/oauth/v2'
DEVICE_URL = 'https://real-debrid.com/device'

# QR obrazok sa generuje lokalne cez script.module.pyqrcode (BSD-3,
# oficialny Kodi repo addon, cisty Python bez PIL/pypng zavislosti) —
# autorizacna URL sa tak nikam neposiela, cely device flow ostava medzi
# tymto klientom a api.real-debrid.com. Ak generovanie zlyha (napr.
# addon nie je nainstalovany), flow funguje aj bez QR obrazku — kod aj
# URL su vzdy zobrazene aj ako text na rucne zadanie.
QR_SCALE = 6

# Verejny client_id pre nezavisle / opensource klientov (rovnaky pouziva
# Umbrella, Seren, Fenom a ine Kodi addony). Umoznuje spustit OAuth2
# device flow bez manualnej registracie aplikacie u RD. Real-Debrid moze
# tento zdielany client_id kedykolvek zablokovat/zrusit — preto kazdy
# krok device flow, ktory zlyha, ponukne manualny fallback (API token
# zadany rucne z real-debrid.com/apitoken), nie len chybovu hlasku.
PUBLIC_CLIENT_ID = 'X245A4XAIBGVM'

GRANT_DEVICE = 'http://oauth.net/grant_type/device/1.0'


class RDException(Exception):
    pass


class RealDebrid:
    """Real-Debrid API klient s QR device loginom a token managementom."""

    instance = None

    def __init__(self):
        self._token = None
        self._client = None  # {'client_id': ..., 'client_secret': ...}

    # ------------------------------------------------------------------
    # Singleton
    # ------------------------------------------------------------------
    @classmethod
    def get_instance(cls):
        if cls.instance is None:
            cls.instance = RealDebrid()
        return cls.instance

    # ------------------------------------------------------------------
    # Token management
    # ------------------------------------------------------------------
    def get_token(self):
        """Vrati ulozeny API token alebo None."""
        if self._token is not None:
            return self._token
        token = get_setting('realdebrid.api_key') or ''
        if token and token not in ('None', 'false', 'False'):
            self._token = token
            return token
        return None

    def is_logged_in(self):
        return self.get_token() is not None

    def _store_token(self, token):
        self._token = token or None
        set_setting('realdebrid.api_key', token or '')
        if token:
            set_setting('realdebrid.status', '1')
        else:
            set_setting('realdebrid.status', '0')

    def _store_tokens(self, access_token, refresh_token=None, expires_in=None):
        """Ulozi access_token a (ak su k dispozicii) aj refresh_token +
        vypocitany cas expiracie, aby sa dal token neskor obnovit bez
        opakovania cele device flow."""
        self._store_token(access_token)
        if refresh_token:
            set_setting('realdebrid.refresh_token', refresh_token)
        if expires_in:
            try:
                expiry = int(time.time()) + int(expires_in)
                set_setting('realdebrid.token_expires', str(expiry))
            except (TypeError, ValueError):
                pass

    def logout(self):
        """Zmaze token, refresh token aj client credentials."""
        self._token = None
        self._client = None
        set_setting('realdebrid.api_key', '')
        set_setting('realdebrid.status', '0')
        set_setting('realdebrid.user', '')
        set_setting('realdebrid.client_id', '')
        set_setting('realdebrid.client_secret', '')
        set_setting('realdebrid.refresh_token', '')
        set_setting('realdebrid.token_expires', '')
        dnotify('Real-Debrid', Strings.txt(Strings.RD_LOGGED_OUT))

    # ------------------------------------------------------------------
    # Client credentials (per-zariadenie client_id/secret, ziskane po
    # autorizacii device flow). Ulozene cez rovnaky addon-settings
    # mechanizmus ako access token — Kodi neposkytuje addonom pristup k
    # OS keychain / sifrovanemu ulozisku, takze "bezpecnejsie" ulozenie
    # tu realne neexistuje. Aspon to ale nie je samostatny nechraneny
    # JSON subor v userdata, ale rovnaka cesta ako zvysok prihlasenia.
    # ------------------------------------------------------------------
    def _load_client(self):
        if self._client is not None:
            return self._client
        client_id = get_setting('realdebrid.client_id')
        client_secret = get_setting('realdebrid.client_secret')
        if client_id and client_secret:
            self._client = {'client_id': client_id, 'client_secret': client_secret}
        return self._client

    def _save_client(self, client):
        self._client = client
        set_setting('realdebrid.client_id', client.get('client_id') or '')
        set_setting('realdebrid.client_secret', client.get('client_secret') or '')

    # ------------------------------------------------------------------
    # HTTP helper
    # ------------------------------------------------------------------
    def _get(self, url, params=None):
        debug('RD GET: {}'.format(url))
        resp = Http.get(url, params=params, timeout=20)
        return resp

    def _post(self, url, data=None):
        debug('RD POST: {}'.format(url))
        resp = Http.post(url, data=data, timeout=20)
        return resp

    # ------------------------------------------------------------------
    # QR / Device login
    # ------------------------------------------------------------------
    def device_login(self):
        """Spusti OAuth2 device flow (QR + PIN, ako Umbrella/Seren).

        Postup:
          1. GET /device/code?client_id=<PUBLIC>&new_credentials=yes
             -> device_code, user_code, direct_verification_url, interval, expires_in
          2. Zobrazi okno s QR (direct_verification_url), PIN kodom a
             stavom pollingu naraz — polling bezi hned, nie az po
             zatvoreni obrazku.
          3. Polling /device/credentials?client_id=<PUBLIC>&code=<device_code>
             -> po autorizacii uzivatelom: client_id, client_secret (per-zariadenie)
          4. POST /token s grant_type=device -> access_token + refresh_token.

        Ak ktorykolvek krok zlyha (napr. verejny client_id bol medzitym
        zruseny na strane RD), ponukne sa manualne zadanie API tokenu
        namiesto tvrdeho zlyhania.
        """
        try:
            code_resp = self._get(
                '{}/device/code'.format(BASE_OAUTH),
                params={'client_id': PUBLIC_CLIENT_ID, 'new_credentials': 'yes'}
            ).json()

            device_code = code_resp.get('device_code')
            user_code = code_resp.get('user_code')
            verification_url = code_resp.get('verification_url') or DEVICE_URL
            direct_url = code_resp.get('direct_verification_url') or verification_url
            interval = int(code_resp.get('interval', 5))
            expires_in = int(code_resp.get('expires_in', 900))

            if not device_code or not user_code:
                debug('RD /device/code neocakavana odpoved (mozno zruseny client_id): {}'.format(code_resp))
                return self._offer_manual_login()

            client = self._poll_for_credentials(
                user_code, direct_url, verification_url, device_code, interval, expires_in)
            if not client:
                return False  # timeout/zrusenie uz oznamene v _poll_for_credentials

            if self._exchange_token(client, device_code):
                return True
            return self._offer_manual_login()
        except RDException as e:
            debug('RD login chyba: {}'.format(e))
            return self._offer_manual_login()
        except Exception:
            debug('RD login neocakavana chyba: {}'.format(traceback.format_exc()))
            return self._offer_manual_login()

    def _poll_for_credentials(self, user_code, direct_url, verification_url, device_code, interval, expires_in):
        """Zobrazi RDLoginWindow (QR + PIN + stav) a polluje
        /device/credentials, kym uzivatel neautorizuje zariadenie,
        nezrusi okno alebo nevyprsi cas. Vrati dict
        {'client_id', 'client_secret'} alebo None."""
        from resources.lib.gui.rd_login_dialog import RDLoginWindow

        minutes = max(1, expires_in // 60)
        qr_path = self._make_qr_image(direct_url)
        instructions = Strings.txt(Strings.RD_LOGIN_DIALOG).format(
            verification_url, user_code, minutes)

        window = RDLoginWindow('RDLogin.xml', ADDON.getAddonInfo('path'), 'default', '1080i')
        window.qr_path = qr_path or ''
        window.instructions = instructions
        window.status = Strings.txt(Strings.RD_LOGIN_WAITING)

        # doModal() blokuje, takze polling musi bezat vo vlastnom vlakne.
        state = {'client': None}
        stop = threading.Event()
        close_lock = threading.Lock()
        closed = {'done': False}
        ready = threading.Event()
        window.ready = ready

        def _close_once():
            with close_lock:
                if closed['done']:
                    return
                closed['done'] = True
            try:
                window.close()
            except (RuntimeError, SystemError):
                pass

        def _poll():
            # Pockaj, kym je okno naozaj otvorene (onInit). Ak sa
            # neotvori, nemame co zatvarat ani aktualizovat.
            if not ready.wait(15):
                debug('RD login: okno sa neotvorilo, polling nespusteny')
                return
            deadline = time.time() + expires_in
            while not stop.is_set() and time.time() < deadline:
                try:
                    resp = self._get(
                        '{}/device/credentials'.format(BASE_OAUTH),
                        params={'client_id': PUBLIC_CLIENT_ID, 'code': device_code}
                    )
                    data = resp.json() or {}
                    if data.get('client_id') and data.get('client_secret'):
                        self._save_client({
                            'client_id': data['client_id'],
                            'client_secret': data['client_secret'],
                        })
                        info('RD: ziskane per-zariadenie client credentials')
                        state['client'] = self._client
                        break
                    # Inak: pending autorizacia — pokracujeme v pollingu.
                except Exception:
                    debug('RD credentials polling chyba: {}'.format(traceback.format_exc()))

                remaining_min = max(0, int((deadline - time.time()) // 60))
                window.set_status('{} ({} min)'.format(
                    Strings.txt(Strings.RD_LOGIN_WAITING_LINE2), remaining_min))
                stop.wait(max(1, interval))
            _close_once()

        poller = threading.Thread(target=_poll)
        poller.daemon = True
        poller.start()
        try:
            window.doModal()
        finally:
            # Okno je uz zavrete (uzivatelom alebo pollerom) — oznac to
            # skor, nez zastavime vlakno, aby _close_once nesiahal na
            # zaniknute okno.
            with close_lock:
                closed['done'] = True
            stop.set()
            poller.join(10)
            canceled = window.canceled
            # Zamerne ziadne `del window`: polling vlakno na okno drzi
            # closure, takze ak by este dobiehalo (napr. visiaci HTTP
            # request), odstranenie mena by mu zhodilo vlakno na
            # NameError. Lokalna premenna aj tak zanika navratom.

        result = state['client']

        if canceled and not result:
            debug('RD credentials polling: uzivatel zrusil')
            return None
        if not result:
            dok('Real-Debrid', Strings.txt(Strings.RD_LOGIN_TIMEOUT))
        return result

    def _exchange_token(self, client, device_code):
        """Vymeni device_code za access_token + refresh_token cez POST /token."""
        try:
            resp = self._post('{}/token'.format(BASE_OAUTH), data={
                'client_id': client['client_id'],
                'client_secret': client['client_secret'],
                'code': device_code,
                'grant_type': GRANT_DEVICE,
            })
            data = resp.json() or {}
            token = data.get('access_token')
            if not token:
                debug('RD /token chyba: {}'.format(data))
                return False
            self._store_tokens(token, data.get('refresh_token'), data.get('expires_in'))
            # Nacitaj info o uzivatelovi pre zobrazenie v nastaveniach.
            try:
                self.get_user_info()
            except Exception:
                debug('RD login: get_user_info zlyhalo (nezavazne)')
            dnotify('Real-Debrid', Strings.txt(Strings.RD_LOGIN_SUCCESS))
            info('RD login uspesny')
            return True
        except Exception:
            debug('RD /token chyba: {}'.format(traceback.format_exc()))
            return False

    def _refresh_token_if_needed(self, force=False):
        """Ak mame refresh_token, obnov access_token — proaktivne tesne
        pred expiraciou, alebo vzdy ak force=True (napr. po 401).

        Real-Debrid nema standardny OAuth2 grant_type=refresh_token —
        refresh sa robi cez ten isty device grant, len s
        code=refresh_token miesto code=device_code (zdokumentovane
        v RD OAuth2 flow a takto implementovane vo vsetkych bezne
        pouzivanych open-source RD klientoch pre Kodi)."""
        refresh_token = get_setting('realdebrid.refresh_token')
        if not refresh_token:
            return False

        if not force:
            expires_raw = get_setting('realdebrid.token_expires')
            try:
                expires_at = int(expires_raw) if expires_raw else 0
            except ValueError:
                expires_at = 0
            if expires_at and time.time() < expires_at - 60:
                return False  # token este dost dlho plati

        client = self._load_client()
        if not client or not client.get('client_id') or not client.get('client_secret'):
            return False

        try:
            resp = self._post('{}/token'.format(BASE_OAUTH), data={
                'client_id': client['client_id'],
                'client_secret': client['client_secret'],
                'code': refresh_token,
                'grant_type': GRANT_DEVICE,
            })
            data = resp.json() or {}
            new_token = data.get('access_token')
            if new_token:
                self._store_tokens(new_token, data.get('refresh_token') or refresh_token, data.get('expires_in'))
                info('RD: access_token obnoveny cez refresh_token')
                return True
            debug('RD refresh token chyba: {}'.format(data))
        except Exception:
            debug('RD refresh token neocakavana chyba: {}'.format(traceback.format_exc()))
        return False

    def _offer_manual_login(self):
        """Zaloha: ponuknime manualne zadanie API tokenu.
        Uzivatel ho ziska z real-debrid.com/apitoken."""
        msg = ('Prihlasenie cez QR/PIN zlyhalo (moze byt docasne, alebo bol '
               'zdielany client_id medzicasom obmedzeny na strane Real-Debrid).\n\n'
               '1. Otvor v prehliadaci: https://real-debrid.com/apitoken\n'
               '2. Prihlas sa a skopiruj svoj API token.\n'
               '3. Vloz ho sem.\n\n'
               'Chces pokracovat?')
        if not xbmcgui.Dialog().yesno('Real-Debrid', msg,
                                      yeslabel='Zadat API token',
                                      nolabel=xbmc.getLocalizedString(106)):
            return False
        return self.manual_login()

    def manual_login(self):
        """Necha uzivatela zadat API token manualne a overi ho."""
        token = xbmcgui.Dialog().input('Real-Debrid API token', type=xbmcgui.INPUT_ALPHANUM)
        if not token or not token.strip():
            return False
        token = token.strip()
        self._token = token  # docasne pre _api_get
        try:
            data = self._api_get('/rest/1.0/user')
            if isinstance(data, dict):
                self._store_token(token)
                set_setting('realdebrid.user', data.get('email') or data.get('username') or '')
                set_setting('realdebrid.expires', str(data.get('expiration', '')))
                dnotify('Real-Debrid', Strings.txt(Strings.RD_LOGIN_SUCCESS))
                info('RD manual login uspesny')
                return True
        except Exception as e:
            debug('RD manual login neplatny token: {}'.format(e))
            dok('Real-Debrid', 'API token je neplatny alebo expiroval.')
        self._token = None
        return False

    def _make_qr_image(self, data_url):
        """Vygeneruje QR PNG lokalne (script.module.pyqrcode) a ulozi
        do userdata. Vrati cestu alebo None pri zlyhani (flow pokracuje
        aj bez QR obrazku, kod aj URL su vzdy zobrazene aj ako text)."""
        try:
            import pyqrcode
            data_dir = translate_path('special://userdata/addon_data/plugin.video.mulenstream')
            if not os.path.exists(data_dir):
                os.makedirs(data_dir)
            path = os.path.join(data_dir, 'rd_qr.png')
            qr = pyqrcode.create(data_url, error='M')
            qr.png(path, scale=QR_SCALE)
            return path
        except Exception:
            debug('RD QR generacia zlyhala: {}'.format(traceback.format_exc()))
            return None

    # ------------------------------------------------------------------
    # User info
    # ------------------------------------------------------------------
    def get_user_info(self):
        """Vrati dict s informaciou o uzivatelovi alebo None."""
        if not self.get_token():
            return None
        try:
            data = self._api_get('/rest/1.0/user')
            if isinstance(data, dict):
                set_setting('realdebrid.user', data.get('email') or data.get('username') or '')
                set_setting('realdebrid.expires', str(data.get('expiration', '')))
                return data
        except Exception:
            debug('RD get_user_info chyba: {}'.format(traceback.format_exc()))
        return None

    def _api_get(self, path, params=None, _retried=False):
        """Autorizovany GET na REST API. Pred volanim sa access token
        proaktivne obnovi, ak je blizko expiracie a mame refresh_token;
        na 401 sa navyse skusi jednorazovy vynúteny refresh + retry."""
        token = self.get_token()
        if not token:
            raise RDException('Nie je prihlaseny k Real-Debrid')
        if not _retried:
            self._refresh_token_if_needed()
            token = self.get_token()
        headers = {'Authorization': 'Bearer {}'.format(token)}
        url = '{}{}'.format(BASE_API, path)
        resp = Http.get(url, params=params, headers=headers, timeout=20)
        if resp.status_code == 401:
            if not _retried and self._refresh_token_if_needed(force=True):
                return self._api_get(path, params=params, _retried=True)
            # Token expiroval / neplatny a nedal sa obnovit
            debug('RD 401 — token neplatny')
            self._store_token(None)
            raise RDException('Real-Debrid token je neplatny alebo expiroval')
        resp.raise_for_status()
        try:
            return resp.json()
        except Exception:
            return None

    def is_valid(self):
        """Overi platnost tokenu (zavola /user). Vrati bool."""
        if not self.get_token():
            return False
        try:
            data = self._api_get('/rest/1.0/user')
            return isinstance(data, dict) and data.get('premium', 0) > 0
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Helpers pre TC resolver (volitelne — Torrentio riesi cache sam)
    # ------------------------------------------------------------------
    def instant_availability(self, infohash):
        """Overi, ci je torrent s danym hashom v RD cache.
        Vracia list file-dict alebo prazdny list."""
        hashes = [h.lower() for h in infohash] if isinstance(infohash, (list, tuple)) \
            else [infohash.lower()]
        try:
            # RD odpoved je keyovana KAZDYM jednotlivym (lowercase) hashom,
            # nie spojenym retazcom poslanym v ceste — aj pri viacerych
            # hashoch naraz vrati samostatny kluc pre kazdy z nich.
            data = self._api_get(
                '/rest/1.0/torrents/instantAvailability/{}'.format(','.join(hashes)))
            if not isinstance(data, dict):
                return []
            result = []
            for h in hashes:
                entry = data.get(h) or {}
                for rd in entry.get('rd') or []:
                    if isinstance(rd, list):
                        result.extend(rd)
            return result
        except Exception:
            debug('RD instantAvailability chyba: {}'.format(traceback.format_exc()))
            return []

    def check_status(self):
        """Stav prihlasenia pre UI (account menu). Vrati dict."""
        if not self.get_token():
            return {'logged_in': False}
        info = self.get_user_info() or {}
        return {
            'logged_in': True,
            'email': info.get('email') or get_setting('realdebrid.user') or '',
            'premium': info.get('premium', 0),
            'expires': info.get('expiration', ''),
        }


def getRDInstance():
    """Singleton accessor analogicky k getKraInstance."""
    return RealDebrid.get_instance()
