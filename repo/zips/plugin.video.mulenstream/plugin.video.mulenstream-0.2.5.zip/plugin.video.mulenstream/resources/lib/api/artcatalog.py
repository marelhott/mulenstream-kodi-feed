# -*- coding: utf-8 -*-
"""
Art katalog klient pre MulenStream.

Zdroj kurátorovaných zoznamov artových / autorských filmov. Streamy k nim
sa dohladavaju cez TCResolver (Torrentio + Comet) tak ako v TC sekcii.

Zdrojom je IMDb GraphQL (advancedTitleSearch), rovnaky endpoint aky uz
pouziva rankings.py pre IMDb rebricky. Oproti povodnemu HTML scrapingu
TMDb ma dve podstatne vyhody:

  1. Vracia priamo IMDb ID, ktore TC resolver (Torrentio/Comet) potrebuje.
     Povodna implementacia dohladavala IMDb ID scrapovanim TMDb stranky
     filmu, lenze ta uz ziadny odkaz na IMDb neobsahuje — prehratie preto
     vzdy skoncilo na "Nepodarilo sa získať IMDb ID".
  2. Nezavisi na HTML markupe, ktory sa meni. TMDb medzitym premenoval
     triedy kariet aj ID keywordov, takze vsetky povodne zoznamy vracali
     nula titulov.

Vsetky dotazy su postavene len na schema-backed constraints (zaner, jazyk,
ocenenia, pocet hlasov) — nie na ID pouzivatelskych zoznamov, ktore moze
ich autor kedykolvek zmazat.
"""
from __future__ import unicode_literals

import json
import os
import time
import traceback

from resources.lib.common.logger import debug, info
from resources.lib.kodiutils import translate_path
from resources.lib.system import Http

IMDB_GRAPHQL_URL = 'https://api.graphql.imdb.com/'

# Spolocne casti constraintov
_MOVIES = 'titleTypeConstraint: { anyTitleTypeIds: ["movie"] }'


def _min_votes(count):
    """Odfiltruje tituly s malym poctom hlasov — bez toho sa v zoradeni
    podla hodnotenia vyplavu na vrch nezname filmy s par hlasmi."""
    return 'userRatingsConstraint: { ratingsCountRange: { min: %d } }' % count


def _festival(event_id):
    """Tituly ocenene na danom festivale (IMDb event ID)."""
    return ('awardConstraint: { allEventNominations: '
            '[{ eventId: "%s", winnerFilter: WINNER_ONLY }] }' % event_id)


# Definicie art zoznamov. 'constraints' ide priamo do GraphQL dotazu.
ART_LISTS = (
    {
        'id': 'world',
        'label': 'Světová kinematografie',
        'constraints': '%s, %s, languageConstraint: { excludePrimaryLanguages: ["en"] }' % (
            _MOVIES, _min_votes(50000)),
    },
    {
        'id': 'cannes',
        'label': 'Cannes — oceněné filmy',
        'constraints': '%s, %s' % (_MOVIES, _festival('ev0000147')),
    },
    {
        'id': 'venice',
        'label': 'Benátky — oceněné filmy',
        'constraints': '%s, %s' % (_MOVIES, _festival('ev0000681')),
    },
    {
        'id': 'berlin',
        'label': 'Berlinale — oceněné filmy',
        'constraints': '%s, %s' % (_MOVIES, _festival('ev0000091')),
    },
    {
        'id': 'foreign_oscar',
        'label': 'Oscar — nejlepší cizojazyčný film',
        'constraints': '%s, %s, languageConstraint: { excludePrimaryLanguages: ["en"] }' % (
            _MOVIES, _festival('ev0000003')),
    },
)

# Kolko titulov nacitat na zoznam (IMDb zvlada aj 250 naraz).
LIST_SIZE = 200

# Trackery, na ktore sa pytame pri art tituloch. Vyber je overeny meranim
# na starsich / neanglickych filmoch (Harakiri 1962, High and Low 1963,
# Shoah 1985, City of God 2002) — nie odhadom:
#
#   thepiratebay, 1337x   najsirsie pokrytie starej a svetovej kinematografie
#   rarbg                 stabilne vysledky naprieC celym vzorkom
#   rutracker, rutor      ruske trackery, najlepsie na europsku/sovietsku
#                         klasiku a tituly, ktore inde vobec nie su
#   ilcorsaronero         taliansky, torrent9 francuzsky — narodna kinematografia
#   torrentgalaxy         doplnok k 1337x
#
# YTS/YIFY tu zamerne NIE JE: v merani mal na artovych tituloch takmer
# nulove pokrytie (Harakiri 0, Pulp Fiction 0, High and Low 1). Zameriava
# sa na mainstreamove filmy v malych enkodoch, nie na svetovu klasiku.
DEFAULT_ART_PROVIDERS = ('thepiratebay,1337x,rarbg,rutracker,rutor,'
                         'ilcorsaronero,torrent9,torrentgalaxy')


def art_providers():
    """Zoznam trackerov pre art sekciu (nastavenie tc.art.providers,
    inak overeny default). Prazdny retazec = bez filtra, vsetky."""
    from resources.lib.kodiutils import get_setting
    configured = (get_setting('tc.art.providers') or '').strip()
    if configured:
        return configured
    return DEFAULT_ART_PROVIDERS

CACHE_TTL = 7 * 24 * 3600  # 7 dní


def _cache_dir():
    d = translate_path('special://userdata/addon_data/plugin.video.mulenstream/art_cache')
    try:
        if not os.path.exists(d):
            os.makedirs(d)
    except Exception:
        pass
    return d


def _cache_path(list_id):
    return os.path.join(_cache_dir(), '%s.json' % list_id)


def _load_cache(list_id):
    try:
        path = _cache_path(list_id)
        if not os.path.exists(path):
            return None
        if time.time() - os.path.getmtime(path) > CACHE_TTL:
            debug('Art cache %s expirovan' % list_id)
            return None
        with open(path, 'r') as fh:
            return json.load(fh)
    except Exception:
        return None


def _save_cache(list_id, records):
    try:
        with open(_cache_path(list_id), 'w') as fh:
            json.dump(records, fh)
    except Exception:
        debug('Art cache save zlyhal: %s' % traceback.format_exc())


def _imdb_records(constraints, limit=LIST_SIZE):
    """Spusti advancedTitleSearch a prelozi odpoved na zoznam recordov."""
    query = (
        'query { advancedTitleSearch(first: %d, constraints: { %s }, '
        'sort: { sortBy: USER_RATING, sortOrder: DESC }) { edges { node { title { '
        'id titleText { text } releaseYear { year } primaryImage { url } '
        'ratingsSummary { aggregateRating } } } } } }'
    ) % (limit, constraints)

    response = Http.post(IMDB_GRAPHQL_URL, json={'query': query}, headers={
        'Content-Type': 'application/json',
        'Origin': 'https://www.imdb.com',
        'User-Agent': 'MulenStream Kodi/0.1 (private use)',
    }, timeout=25)
    response.raise_for_status()
    payload = response.json() or {}

    if payload.get('errors'):
        message = (payload['errors'][0] or {}).get('message', 'unknown')
        raise ValueError('IMDb GraphQL: %s' % message)

    edges = ((payload.get('data') or {}).get('advancedTitleSearch') or {}).get('edges') or []
    records = []
    for edge in edges:
        title = ((edge or {}).get('node') or {}).get('title') or {}
        identifier = str(title.get('id') or '')
        name = ((title.get('titleText') or {}).get('text') or '').strip()
        if not identifier.startswith('tt') or not name:
            continue
        release_year = (title.get('releaseYear') or {}).get('year')
        image = (title.get('primaryImage') or {}).get('url')
        rating = (title.get('ratingsSummary') or {}).get('aggregateRating')
        record = {
            'title': name,
            'year': int(release_year) if release_year else None,
            'unique_ids': {'imdb': identifier},
            'art': {'poster': image} if image else {},
        }
        if rating is not None:
            record['rating'] = rating
        records.append(record)
    return records


def fetch_list(list_id, force_refresh=False):
    """Hlavný vstup — vráti zoznam recordov pre daný art list.
    Používa cache (TTL 7 dní) okrem force_refresh."""
    if not force_refresh:
        cached = _load_cache(list_id)
        if cached is not None:
            debug('Art list %s: %d titulov z cache' % (list_id, len(cached)))
            return cached

    definition = next((d for d in ART_LISTS if d['id'] == list_id), None)
    if not definition:
        debug('Art list %s neexistuje' % list_id)
        return []

    try:
        debug('Art fetch %s' % list_id)
        records = _imdb_records(definition['constraints'])
        if not records:
            raise ValueError('IMDb vratil prazdny zoznam')
        info('Art list %s: %d titulov z IMDb' % (list_id, len(records)))
        _save_cache(list_id, records)
        return records
    except Exception:
        debug('Art fetch %s chyba: %s' % (list_id, traceback.format_exc()))
        # Fallback na starú cache aj keď expirovaná
        try:
            with open(_cache_path(list_id), 'r') as fh:
                return json.load(fh)
        except Exception:
            return []


def list_definitions():
    """Vráti definície dostupných art listov pre menu."""
    return [{'id': d['id'], 'label': d['label']} for d in ART_LISTS]
