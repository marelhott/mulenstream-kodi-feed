# -*- coding: utf-8 -*-
"""
Cinemeta klient — vlastny katalog pre TC sekciu.

TC sekcia predtym listovala katalog kra.sk (Sc.get('/FMovies')) a len
prepisala play path na TC resolver. Vysledok bol, ze Filmy/Serialy TC
zobrazovali presne to iste co Filmy/Serialy SC — dva vstupy do jedneho
a toho isteho obsahu, lisiace sa len tym, odkial sa pusti stream.

Cinemeta je oficialny metadatovy addon Stremia a je spravnym partnerom
pre Torrentio/Comet: indexuje svetovy katalog podla IMDb ID, teda presne
toho identifikatora, ktory TC resolver potrebuje. TC sekcia tak ponuka
naozaj iny obsah ako kra.sk, nie jeho kopiu.
"""
from __future__ import unicode_literals

import time

from resources.lib.common.logger import debug
from resources.lib.constants import SC
from resources.lib.system import Http

BASE = 'https://v3-cinemeta.strem.io'

# Cinemeta vracia okno cca 50 poloziek na dotaz — overene tym, ze
# skip=0/50/100/150 sa navzajom neprekryvaju, zatial co skip=25 sa s
# prvou stranou prekryva z polovice.
PAGE_SIZE = 50

# Katalogy, ktore Cinemeta ponuka pre movie aj series (podla manifestu).
CATALOGS = (
    {'id': 'top', 'label': 'Populární'},
    {'id': 'imdbRating', 'label': 'Nejlépe hodnocené'},
    {'id': 'year', 'label': 'Nejnovější'},
)

_GENRE_CACHE = {'stamp': 0, 'data': {}}
_GENRE_TTL = 24 * 3600


def _get(path):
    url = '{}/{}'.format(BASE, path.lstrip('/'))
    debug('Cinemeta GET: {}'.format(url))
    resp = Http.get(url, timeout=20)
    resp.raise_for_status()
    return resp.json() or {}


def catalogs():
    """Definicie katalogov pre menu."""
    return [dict(c) for c in CATALOGS]


def genres(kind):
    """Zoznam zanrov pre dany typ ('movie' / 'series') z manifestu."""
    now = time.time()
    if _GENRE_CACHE['data'] and now - _GENRE_CACHE['stamp'] < _GENRE_TTL:
        return _GENRE_CACHE['data'].get(kind, [])
    try:
        manifest = _get('manifest.json')
        found = {}
        for catalog in manifest.get('catalogs') or []:
            if catalog.get('id') != 'top':
                continue
            for extra in catalog.get('extra') or []:
                if extra.get('name') == 'genre' and extra.get('options'):
                    found[catalog.get('type')] = list(extra['options'])
        _GENRE_CACHE['data'] = found
        _GENRE_CACHE['stamp'] = now
    except Exception as exc:
        debug('Cinemeta genres chyba: {}'.format(exc))
        return _GENRE_CACHE['data'].get(kind, [])
    return _GENRE_CACHE['data'].get(kind, [])


def _catalog_path(kind, catalog_id, genre=None, skip=0, search=None):
    """Poskladá Stremio catalog cestu. Extra parametre idu do posledneho
    segmentu ako `key=value` oddelene '&', pred '.json'."""
    extras = []
    if search:
        extras.append('search={}'.format(_quote(search)))
    if genre:
        extras.append('genre={}'.format(_quote(genre)))
    if skip:
        extras.append('skip={}'.format(int(skip)))
    tail = '/' + '&'.join(extras) if extras else ''
    return 'catalog/{}/{}{}.json'.format(kind, catalog_id, tail)


def _quote(value):
    try:
        from urllib.parse import quote
    except ImportError:  # Python 2 fallback
        from urllib import quote
    return quote(str(value), safe='')


def _record(meta, kind):
    """Prelozi Cinemeta meta na zaznam v tvare, aky uz ocakava
    ms_tc_play (unique_ids.imdb + SC.ITEM_INFO)."""
    imdb_id = meta.get('imdb_id') or meta.get('id') or ''
    if not str(imdb_id).startswith('tt'):
        return None
    year = meta.get('year') or meta.get('releaseInfo') or ''
    # releaseInfo byva '2022' alebo '2022–' alebo '2019–2023'
    year_num = None
    for chunk in str(year).replace('–', '-').split('-'):
        if chunk.strip().isdigit():
            year_num = int(chunk.strip())
            break
    rating = meta.get('imdbRating')
    try:
        rating = float(rating) if rating else None
    except (TypeError, ValueError):
        rating = None
    runtime = str(meta.get('runtime') or '')
    minutes = None
    if runtime:
        digits = ''.join(ch for ch in runtime if ch.isdigit())
        if digits:
            minutes = int(digits)

    return {
        SC.ITEM_TYPE: SC.ITEM_VIDEO,
        SC.ITEM_TITLE: meta.get('name') or '',
        'unique_ids': {'imdb': str(imdb_id)},
        SC.ITEM_INFO: {
            'title': meta.get('name') or '',
            'plot': meta.get('description') or '',
            'year': year_num,
            'rating': rating,
            'duration': minutes * 60 if minutes else None,
            'mediatype': 'movie' if kind == 'movie' else 'tvshow',
            'genre': meta.get('genres') or meta.get('genre') or [],
            'cast': meta.get('cast') or [],
            'director': meta.get('director') or [],
            'country': meta.get('country') or '',
        },
        'art': build_art(
            poster=meta.get('poster'),
            fanart=meta.get('background'),
            clearlogo=meta.get('logo'),
        ),
    }


def build_art(poster=None, fanart=None, clearlogo=None, thumb=None):
    """Poskladá art dict bez prazdnych hodnot.

    Prazdny retazec poslany do ListItem.setArt() sposobi, ze Kodi zobrazi
    prazdny ramcek namiesto toho, aby siahol po nahradnej ikone skinu.
    Poster sa zaroven kopiruje do 'thumb' aj 'icon' — cast skinov berie
    nahlad v zozname prave odtial, nie z 'poster'.
    """
    art = {}
    image = thumb or poster
    if image:
        art['thumb'] = image
        art['icon'] = image
    if poster:
        art['poster'] = poster
    if fanart:
        art['fanart'] = fanart
    if clearlogo:
        art['clearlogo'] = clearlogo
    return art


def fetch_catalog(kind, catalog_id, genre=None, skip=0, search=None):
    """Vrati zoznam zaznamov pre dany katalog."""
    data = _get(_catalog_path(kind, catalog_id, genre, skip, search))
    records = []
    for meta in data.get('metas') or []:
        record = _record(meta, kind)
        if record:
            records.append(record)
    return records


def meta(kind, imdb_id):
    """Detail titulu vratane zoznamu epizod (pre serialy)."""
    data = _get('meta/{}/{}.json'.format(kind, imdb_id))
    return data.get('meta') or {}


def seasons(series_meta):
    """Zoradene cisla sezon zo serialoveho meta (bez specialov = sezona 0)."""
    found = set()
    for video in series_meta.get('videos') or []:
        season = video.get('season')
        if season:
            found.add(int(season))
    return sorted(found)


def episodes(series_meta, season):
    """Epizody danej sezony, zoradene podla cisla epizody."""
    out = []
    for video in series_meta.get('videos') or []:
        if int(video.get('season') or 0) != int(season):
            continue
        if not video.get('episode'):
            continue
        out.append(video)
    return sorted(out, key=lambda v: int(v.get('episode') or 0))
