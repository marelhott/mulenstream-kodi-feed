# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import time

from resources.lib.api.sc import Sc
from resources.lib.common.logger import debug
from resources.lib.kodiutils import get_setting, set_setting
from resources.lib.mulenstream.controller import MulenController
from resources.lib.mulenstream.library import LibraryManager
from resources.lib.mulenstream.rankings import RankingProvider


UPDATE_INTERVAL = 6 * 60 * 60


def update_followed_collections(force=False):
    if get_setting('mulen.library.follow') == 'false':
        return {'updated': 0, 'written': 0}
    now = int(time.time())
    last = int(get_setting('mulen.library.last_update') or 0)
    if not force and now - last < UPDATE_INTERVAL:
        return {'updated': 0, 'written': 0}

    manager = LibraryManager()
    manifest = manager.load_manifest()
    controller = MulenController()
    updated = 0
    written = 0
    for collection in list(manifest.get('collections', {}).values()):
        if not collection.get('follow'):
            continue
        try:
            if collection.get('provider'):
                records = RankingProvider(collection['provider']).fetch(collection.get('list_id'))
                items = []
                for record in records:
                    matched = record if record.get('url') else controller._match_catalog_record(Sc, record)
                    if matched:
                        items.append(matched)
            else:
                items = controller._expand_collection(
                    Sc, collection.get('source_url'), role=collection.get('role'),
                    person=collection.get('person')
                )
            result = manager.add_many(items, collection, scan=False)
            written += len(result.get('written') or [])
            updated += 1
        except Exception as exc:
            debug('MulenStream collection update failed: {}'.format(exc))
    if written:
        manager.scan(manager.root)
    set_setting('mulen.library.last_update', str(now))
    return {'updated': updated, 'written': written}

