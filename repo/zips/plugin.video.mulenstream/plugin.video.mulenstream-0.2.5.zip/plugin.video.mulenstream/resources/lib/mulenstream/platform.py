# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import os

import xbmc

from resources.lib.constants import ADDON_ID


def platform_id():
    if xbmc.getCondVisibility('system.platform.osx'):
        return 'macos'
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android-tv'
    return 'other'


def default_library_root():
    current = platform_id()
    if current == 'macos':
        return os.path.expanduser('~/Movies/MulenStream Library')
    # Shield storage mount names and scoped-storage permissions vary. Kodi's
    # profile VFS is the only zero-configuration writable location guaranteed
    # by the addon API; users may override it with SMB/NFS/external storage.
    return 'special://profile/addon_data/%s/library' % ADDON_ID

