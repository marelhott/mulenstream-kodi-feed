# -*- coding: utf-8 -*-
"""MulenStream product layer.

The legacy Stream Cinema client remains an implementation detail used for
catalogue browsing and playback.  Everything in this package is owned by
MulenStream: library materialisation, collections, rankings and navigation.
"""

PRODUCT_NAME = 'MulenStream'
LIBRARY_SCHEMA_VERSION = 1

