# -*- coding: utf-8 -*-
"""Persistent subscriptions to people, independent from Kodi's media library."""
from __future__ import unicode_literals

import json
import time

import xbmcvfs

from resources.lib.constants import ADDON
from resources.lib.mulenstream.model import safe_name


def _read(path):
    try:
        handle = xbmcvfs.File(path)
        value = handle.read()
        handle.close()
        return value
    except Exception:
        return ''


def _write(path, value):
    parent = path.rsplit('/', 1)[0]
    xbmcvfs.mkdirs(parent)
    temporary = path + '.tmp'
    handle = xbmcvfs.File(temporary, 'w')
    handle.write(value)
    handle.close()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)
    if not xbmcvfs.rename(temporary, path):
        raise IOError('Cannot save filmography subscriptions')


class FilmographyStore(object):
    """Stores only a person and their catalogue URL; never writes STRM/NFO."""
    def __init__(self):
        self.path = ADDON.getAddonInfo('profile').rstrip('/') + '/filmographies.json'

    def load(self):
        try:
            data = json.loads(_read(self.path) or '{}')
            if isinstance(data, dict):
                data.setdefault('people', {})
                return data
        except Exception:
            pass
        return {'schema': 1, 'people': {}}

    def save(self, data):
        data['updated_at'] = int(time.time())
        _write(self.path, json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))

    @staticmethod
    def key(role, name, source_url):
        return '%s:%s' % (role or 'person', safe_name(name or source_url).casefold())

    def follow(self, role, name, source_url):
        if role not in ('director', 'actor') or not name or not source_url:
            raise ValueError('Chybí osoba nebo odkaz na filmografii')
        data = self.load()
        key = self.key(role, name, source_url)
        old = data['people'].get(key, {})
        data['people'][key] = dict(old, key=key, role=role, name=name,
                                   source_url=source_url, followed_at=int(time.time()))
        self.save(data)
        return data['people'][key]

    def get(self, key):
        return self.load().get('people', {}).get(key)

    def all(self):
        return sorted(self.load().get('people', {}).values(),
                      key=lambda person: (person.get('name') or '').casefold())

    def remove(self, key):
        data = self.load()
        if key in data.get('people', {}):
            del data['people'][key]
            self.save(data)

    def mark_loaded(self, key, count):
        data = self.load()
        person = data.get('people', {}).get(key)
        if person is not None:
            person['count'] = int(count)
            person['last_loaded_at'] = int(time.time())
            self.save(data)
