# -*- coding: utf-8 -*-
"""
Okno pre Real-Debrid QR/PIN device-login (RDLogin.xml).

Preco WindowXMLDialog + doModal() a nie programove okno cez show():
tlacidlo prihlasenia je akcia v DialogAddonSettings, ktory po spusteni
RunPlugin() ostava otvoreny a drzi si modalny fokus. Okno otvorene cez
show() sa vykresli pod nim (uzivatel nevidi nic) a nasilne zatvaranie
nastaveni cez Dialog.Close(addonsettings) zhodi cele Kodi, lebo ide o
dialog, ktory prave bezaci plugin sam spustil. doModal() tento problem
nema — modalny dialog sa korektne naskladá nad nastavenia.

Polling /device/credentials bezi vo vlakne (doModal blokuje), ktore
priebezne aktualizuje stavovy riadok cez set_status() a po ziskani
credentials okno zavrie. Pattern instanciacie kopiruje gui/skip.py.
"""
from __future__ import unicode_literals

import xbmcgui

# Control ID zhodne s RDLogin.xml
CTRL_QR = 5001
CTRL_INSTRUCTIONS = 5002
CTRL_STATUS = 5003
CTRL_CANCEL = 5004

# Kodi action ID
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92


class RDLoginWindow(xbmcgui.WindowXMLDialog):
    """QR + PIN + zivy stav pollingu, s tlacidlom na zrusenie.

    Obsah sa nastavuje cez atributy (qr_path, instructions, status) este
    pred doModal() — konstruktor zamerne neberie vlastne kwargs, aby sa
    nemiesali so skin argumentmi, ktore spracuva samotne Kodi.
    """

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        self.canceled = False
        self.qr_path = ''
        self.instructions = ''
        self.status = ''
        # threading.Event, ktoru okno nastavi az ked je naozaj otvorene.
        # Polling vlakno na nu caka, aby nemohlo zavriet okno skor, nez
        # doModal() vobec zacne (to by Kodi nechalo visiet).
        self.ready = None

    # ------------------------------------------------------------------
    # WindowXMLDialog callbacks
    # ------------------------------------------------------------------
    def onInit(self):  # type: () -> None
        if self.qr_path:
            self.getControl(CTRL_QR).setImage(self.qr_path)
        self.getControl(CTRL_INSTRUCTIONS).setText(self.instructions)
        self.getControl(CTRL_STATUS).setLabel(self.status)
        self.setFocus(self.getControl(CTRL_CANCEL))
        if self.ready is not None:
            self.ready.set()

    def onClick(self, control_id):  # type: (int) -> None
        if control_id == CTRL_CANCEL:
            self.canceled = True
            self.close()

    def onAction(self, action):  # type: (xbmcgui.Action) -> None
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.canceled = True
            self.close()

    # ------------------------------------------------------------------
    # Volane z polling vlakna
    # ------------------------------------------------------------------
    def set_status(self, text):
        """Aktualizuje stavovy riadok. Volane z ineho vlakna, takze okno
        uz medzitym mohlo byt zatvorene — vtedy len ticho neurobi nic."""
        self.status = text
        try:
            self.getControl(CTRL_STATUS).setLabel(text)
        except (RuntimeError, SystemError):
            pass
