# Notices

MulenStream contains a compatibility layer derived from
`plugin.video.stream-cinema`, originally published under GNU GPL v3 by its
contributors. The inherited `LICENSE` applies to the combined addon.

The MulenStream-specific library, collection and ranking modules are located
under `resources/lib/mulenstream/` and are distributed under the same GPL v3
terms as the combined work.

MulenStream does not distribute media. Catalogue and storage accounts must be
used in accordance with their providers' terms and applicable law.

