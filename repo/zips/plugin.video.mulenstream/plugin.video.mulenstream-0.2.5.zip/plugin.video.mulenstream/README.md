# MulenStream

MulenStream is a library-first Kodi video addon for macOS and Android TV
(including NVIDIA Shield). It uses the existing catalogue/playback protocol,
but owns its library, collections and ranking workflow.

## Library contract

- macOS default: `~/Movies/MulenStream Library`
- NVIDIA Shield / Android TV default: `special://profile/addon_data/plugin.video.mulenstream/library`
- Both may be overridden with a Kodi VFS path such as SMB or NFS. Each device
  stores its own location; generated plugin URLs remain portable.
- Movies: `Movies/Title (Year)/Title (Year).strm` plus matching `.nfo`
- Episodes: `TV Shows/Show/Season NN/Show - SxxExx.strm` plus matching `.nfo`
- Stable plugin URLs are stored; resolved media URLs and credentials never are.
- `.mulenstream.json` is the source-of-truth manifest.
- `sources.xml` receives separate Movies and TV Shows sources. Because Kodi
  exposes no JSON-RPC call for assigning source content, MulenStream performs
  one narrow schema-checked upsert of those two exact paths in the latest
  MyVideos database and assigns the built-in `metadata.local` scraper. It does
  not alter or delete media records.

## Ranking feed contract

Direct scraping is intentionally excluded. Each configured feed URL must return
either a JSON list or `{ "items": [...] }`. Every item must already be matched
to the catalogue shape used by the addon and contain at least:

```json
{
  "id": "71173",
  "url": "/Play/m_example",
  "title": "Example",
  "info": {"mediatype": "movie", "year": 2026},
  "unique_ids": {"imdb": "tt0000000", "sc": "71173"}
}
```

This boundary keeps source licensing, rate limits and ambiguous-title matching
out of the Kodi client.

## Subtrans

`service.subtitles.subtrans >= 0.8.2` is an optional dependency. MulenStream
preserves the `SC.play_item` playback metadata contract so Subtrans can rank
and translate subtitles without a Trakt account.

## TC section (Torrentio + Comet via Real-Debrid)

MulenStream 0.2.0 adds a parallel content layer that resolves streams through
debrid services instead of the kra.sk file host. It is entirely separate from
the SC backend and does not touch kra.sk playback.

- **Root menu**: the original `Filmy` / `Seriály` folders are renamed to
  `Filmy SC` / `Seriály SC` (kra.sk, unchanged). New `Filmy TC` / `Seriály TC`
  folders use the SC catalogue for browsing but resolve playback through
  Torrentio (+ optionally Comet) against a configured Real-Debrid account.
- **Real-Debrid login**: open *Settings → Real-Debrid → Login via QR code*.
  The addon runs the OAuth2 device flow, shows a PIN + QR (generated via the
  public qrserver API), and polls `/token` until authorization completes. The
  token is stored in `realdebrid.api_key`; logout clears it.
- **Resolver contract**: TC stream objects are emitted in the same `strms[]`
  shape as kra.sk streams (`provider`, `quality`, `size`, `url`, …). Only
  cached debrid entries (objects with a direct `url`) are returned; raw
  `infoHash`/P2P entries are skipped so playback stays instant.
- **Catalogue key**: SC items already carry `unique_ids.imdb`, which is the
  join key for Torrentio's `/stream/movie|series/{imdb}[:s:e].json` endpoint.
- Comet is disabled by default because the public ElfHosted instance requires
  a pre-configured profile UUID; enable it only if you self-host Comet and
  point `tc.comet.url` at your instance.

### Art films

`Art films` is a curated catalogue (Criterion Collection, art-house / foreign
cinema lists from TMDb). Titles are scraped from TMDb's public web pages — no
TMDb API key is required. IMDb IDs are looked up per title on demand (TMDb
movie page → IMDb link) and resolution then reuses the TC resolver. Results are
cached for 7 days under `addon_data/plugin.video.mulenstream/art_cache/`.

