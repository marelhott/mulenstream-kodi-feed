# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
import os
import re
import sqlite3
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

from resources.lib.kodiutils import create_plugin_url, get_setting, set_setting
from resources.lib.mulenstream import LIBRARY_SCHEMA_VERSION
from resources.lib.mulenstream.model import canonical_key, compact_payload, media_type, nfo_xml, safe_name, title_for
from resources.lib.mulenstream.platform import default_library_root, platform_id


def _join(*parts):
    values = [str(part) for part in parts if part not in (None, '')]
    if not values:
        return ''
    head = values[0].rstrip('/\\')
    tail = [value.strip('/\\') for value in values[1:]]
    return '/'.join([head] + tail)


def _read(path, default=''):
    try:
        handle = xbmcvfs.File(path)
        value = handle.read()
        handle.close()
        return value
    except Exception:
        return default


def _write_atomic(path, value):
    parent = path.rsplit('/', 1)[0]
    xbmcvfs.mkdirs(parent)
    temp = path + '.tmp'
    handle = xbmcvfs.File(temp, 'w')
    handle.write(value)
    handle.close()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)
    if not xbmcvfs.rename(temp, path):
        raise IOError('Cannot commit %s' % path)


class LibraryManager(object):
    def __init__(self, root=None):
        initialized = get_setting('mulen.library.initialized') == 'true'
        configured = root or (get_setting('mulen.library.path') if initialized else '') or default_library_root()
        self.root = configured.rstrip('/')
        self.movies_root = _join(self.root, 'Movies')
        self.shows_root = _join(self.root, 'TV Shows')
        self.manifest_path = _join(self.root, '.mulenstream.json')
        self.playlists_root = 'special://profile/playlists/video'

    def setup(self):
        for path in (self.root, self.movies_root, self.shows_root, self.playlists_root):
            xbmcvfs.mkdirs(path)
        if get_setting('mulen.library.initialized') != 'true':
            set_setting('mulen.library.path', self.root)
            set_setting('mulen.library.platform', platform_id())
            set_setting('mulen.library.initialized', 'true')
        manifest = self.load_manifest()
        self.save_manifest(manifest)
        self.ensure_kodi_sources()
        self.ensure_kodi_content_types()
        return self.root

    def ensure_kodi_sources(self):
        """Register the tiny STRM/NFO roots without touching Kodi's SQLite DB."""
        path = 'special://profile/sources.xml'
        raw = _read(path, '').strip()
        if raw:
            try:
                root = ET.fromstring(raw)
            except Exception as exc:
                raise ValueError('Existing sources.xml is invalid: %s' % exc)
        else:
            root = ET.Element('sources')
        video = root.find('video')
        if video is None:
            video = ET.SubElement(root, 'video')
        changed = False
        existing = {}
        for source in video.findall('source'):
            name = source.findtext('name')
            if name:
                existing[name] = source
        for name, source_path in (('MulenStream Movies', self.movies_root),
                                  ('MulenStream TV Shows', self.shows_root)):
            source = existing.get(name)
            if source is None:
                source = ET.SubElement(video, 'source')
                ET.SubElement(source, 'name').text = name
                ET.SubElement(source, 'path', {'pathversion': '1'}).text = source_path + '/'
                ET.SubElement(source, 'allowsharing').text = 'true'
                changed = True
            elif source.findtext('path') != source_path + '/':
                source.find('path').text = source_path + '/'
                changed = True
        if changed or not raw:
            xml = ET.tostring(root, encoding='unicode')
            _write_atomic(path, '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n' + xml + '\n')
        return changed

    def ensure_kodi_content_types(self):
        """Assign native Movies/TV Shows content to both registered sources.

        Kodi exposes source listing and scans over JSON-RPC, but no supported
        method for assigning scraper/content to a source. We therefore perform
        a narrow schema-checked upsert into the latest MyVideos DB: no media
        rows are touched or deleted, and unknown schemas are rejected.
        """
        database_dir = xbmcvfs.translatePath('special://profile/Database')
        try:
            names = os.listdir(database_dir)
        except OSError:
            return False
        versions = []
        for name in names:
            match = re.match(r'^MyVideos(\d+)\.db$', name)
            if match:
                versions.append((int(match.group(1)), name))
        if not versions:
            return False
        database_path = os.path.join(database_dir, max(versions)[1])
        required = {'strPath', 'strContent', 'strScraper', 'scanRecursive',
                    'useFolderNames', 'noUpdate', 'exclude'}
        connection = sqlite3.connect(database_path, timeout=10)
        try:
            connection.execute('PRAGMA busy_timeout=10000')
            columns = {row[1] for row in connection.execute('PRAGMA table_info(path)').fetchall()}
            if not required.issubset(columns):
                raise RuntimeError('Unsupported Kodi video database schema')
            for source_path, content, recursive, folders in (
                    (self.movies_root, 'movies', 1, 1),
                    (self.shows_root, 'tvshows', 0, 0)):
                normalized = self._database_path(source_path)
                # 0.1.0 development builds briefly stripped the leading slash
                # from macOS paths. Remove only those exact MulenStream-owned
                # rows before writing the corrected absolute source.
                if normalized.startswith('/'):
                    connection.execute(
                        'DELETE FROM path WHERE strPath=? AND strContent=? AND strScraper=?',
                        (normalized.lstrip('/'), content, 'metadata.local')
                    )
                found = connection.execute('SELECT idPath FROM path WHERE strPath=?', (normalized,)).fetchone()
                if found is None:
                    connection.execute(
                        'INSERT INTO path(strPath,strContent,strScraper,scanRecursive,useFolderNames,noUpdate,exclude) '
                        'VALUES(?,?,?,?,?,?,?)',
                        (normalized, content, 'metadata.local', recursive, folders, 0, 0)
                    )
                else:
                    connection.execute(
                        'UPDATE path SET strContent=?,strScraper=?,scanRecursive=?,useFolderNames=?,noUpdate=0,exclude=0 '
                        'WHERE idPath=?',
                        (content, 'metadata.local', recursive, folders, found[0])
                    )
            connection.commit()
            return True
        finally:
            connection.close()

    @staticmethod
    def _database_path(path):
        translated = xbmcvfs.translatePath(path)
        value = translated or path
        return value.rstrip('/\\') + '/'

    def load_manifest(self):
        raw = _read(self.manifest_path, '')
        if raw:
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    parsed.setdefault('items', {})
                    parsed.setdefault('collections', {})
                    return parsed
            except Exception:
                pass
        return {'schema': LIBRARY_SCHEMA_VERSION, 'items': {}, 'collections': {}, 'updated_at': 0}

    def save_manifest(self, manifest):
        manifest['schema'] = LIBRARY_SCHEMA_VERSION
        manifest['updated_at'] = int(time.time())
        _write_atomic(self.manifest_path, json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))

    def contains(self, item):
        return canonical_key(item) in self.load_manifest().get('items', {})

    def add(self, raw_item, tags=None, scan=True):
        self.setup()
        item = compact_payload(raw_item) if 'title' not in raw_item else raw_item
        kind = media_type(item)
        if kind == 'tvshow':
            raise ValueError('TV show requires expanded episode data')
        path = self._write_media(item, tags or [])
        manifest = self.load_manifest()
        manifest['items'][canonical_key(item)] = {
            'title': title_for(item), 'type': kind, 'path': path, 'url': item.get('url'),
            'tags': sorted(set(tags or [])), 'updated_at': int(time.time())
        }
        self.save_manifest(manifest)
        if scan and get_setting('mulen.library.scan') != 'false':
            self.scan(path.rsplit('/', 2)[0])
        return path

    def add_many(self, items, collection=None, scan=True):
        self.setup()
        manifest = self.load_manifest()
        written = []
        errors = []
        tag = collection.get('tag') if collection else None
        for raw in items:
            try:
                item = compact_payload(raw) if 'title' not in raw else raw
                if media_type(item) == 'tvshow':
                    continue
                tags = [tag] if tag else []
                path = self._write_media(item, tags)
                manifest['items'][canonical_key(item)] = {
                    'title': title_for(item), 'type': media_type(item), 'path': path,
                    'url': item.get('url'), 'tags': tags, 'updated_at': int(time.time())
                }
                written.append(path)
            except Exception as exc:
                errors.append(str(exc))
        if collection:
            key = collection.get('key') or safe_name(collection.get('tag', 'collection'))
            manifest['collections'][key] = dict(collection, count=len(written), updated_at=int(time.time()))
            self.write_playlist(collection.get('tag'), collection.get('title') or collection.get('tag'))
        self.save_manifest(manifest)
        if written and scan and get_setting('mulen.library.scan') != 'false':
            self.scan(self.root)
        return {'written': written, 'errors': errors}

    def _write_media(self, item, tags):
        info = item.get('info') or {}
        kind = media_type(item)
        year = info.get('year')
        title = safe_name(title_for(item))
        display = '%s (%s)' % (title, year) if year else title
        if kind == 'episode':
            show = safe_name(info.get('tvshowtitle') or item.get('tvshowtitle') or title)
            season = int(info.get('season') or 0)
            episode = int(info.get('episode') or 0)
            folder = _join(self.shows_root, show, 'Season %02d' % season)
            base = '%s - S%02dE%02d' % (show, season, episode)
        else:
            folder = _join(self.movies_root, display)
            base = display
        xbmcvfs.mkdirs(folder)
        plugin_url = create_plugin_url({'url': item.get('url'), 'id': item.get('id')})
        if not item.get('url'):
            raise ValueError('Missing stable catalogue URL for %s' % title)
        strm = _join(folder, safe_name(base) + '.strm')
        nfo = _join(folder, safe_name(base) + '.nfo')
        _write_atomic(strm, plugin_url + '\n')
        _write_atomic(nfo, nfo_xml(item, tags=tags))
        return strm

    def write_playlist(self, tag, title):
        if not tag:
            return None
        safe = safe_name(title)
        xml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
               '<smartplaylist type="movies">\n'
               '  <name>%s</name>\n'
               '  <match>all</match>\n'
               '  <rule field="tag" operator="is"><value>%s</value></rule>\n'
               '</smartplaylist>\n') % (safe, tag)
        path = _join(self.playlists_root, safe + '.xsp')
        _write_atomic(path, xml)
        return path

    def scan(self, directory=None):
        payload = {'jsonrpc': '2.0', 'method': 'VideoLibrary.Scan',
                   'params': {'directory': directory or self.root, 'showdialogs': False}, 'id': 1}
        return xbmc.executeJSONRPC(json.dumps(payload))

    def summary(self):
        manifest = self.load_manifest()
        return {'root': self.root, 'items': len(manifest.get('items', {})),
                'collections': len(manifest.get('collections', {}))}
