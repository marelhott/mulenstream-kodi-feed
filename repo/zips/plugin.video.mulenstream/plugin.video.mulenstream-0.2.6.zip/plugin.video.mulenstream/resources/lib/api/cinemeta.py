# -*- coding: utf-8 -*-
"""
Cinemeta klient — epizodne data serialov pre TC sekciu.

Rebricky a katalogy TC sekcie stavia tccatalog.py na IMDb GraphQL,
lebo Cinemeta zoznamy nie su radene ('Najlepsie hodnotene' vracalo
tituly s hodnotenim od 5.3). Cinemeta si tu ponechava to, co IMDb
GraphQL v tejto podobe neposkytuje — rozpis sezon a epizod serialu —
a pomocnik na skladanie artworku.
"""
from __future__ import unicode_literals

from resources.lib.common.logger import debug
from resources.lib.system import Http

BASE = 'https://v3-cinemeta.strem.io'


def _get(path):
    url = '{}/{}'.format(BASE, path.lstrip('/'))
    debug('Cinemeta GET: {}'.format(url))
    resp = Http.get(url, timeout=20)
    resp.raise_for_status()
    return resp.json() or {}


def build_art(poster=None, fanart=None, clearlogo=None, thumb=None):
    """Poskladá art dict bez prazdnych hodnot.

    Prazdny retazec poslany do ListItem.setArt() sposobi, ze Kodi zobrazi
    prazdny ramcek namiesto toho, aby siahol po nahradnej ikone skinu.
    Poster sa zaroven kopiruje do 'thumb' aj 'icon' — cast skinov berie
    nahlad v zozname prave odtial, nie z 'poster'.
    """
    art = {}
    image = thumb or poster
    if image:
        art['thumb'] = image
        art['icon'] = image
    if poster:
        art['poster'] = poster
    if fanart:
        art['fanart'] = fanart
    if clearlogo:
        art['clearlogo'] = clearlogo
    return art


def meta(kind, imdb_id):
    """Detail titulu vratane zoznamu epizod (pre serialy)."""
    data = _get('meta/{}/{}.json'.format(kind, imdb_id))
    return data.get('meta') or {}


def seasons(series_meta):
    """Zoradene cisla sezon zo serialoveho meta (bez specialov = sezona 0)."""
    found = set()
    for video in series_meta.get('videos') or []:
        season = video.get('season')
        if season:
            found.add(int(season))
    return sorted(found)


def episodes(series_meta, season):
    """Epizody danej sezony, zoradene podla cisla epizody."""
    out = []
    for video in series_meta.get('videos') or []:
        if int(video.get('season') or 0) != int(season):
            continue
        if not video.get('episode'):
            continue
        out.append(video)
    return sorted(out, key=lambda v: int(v.get('episode') or 0))
