# -*- coding: utf-8 -*-
"""
Katalog TC sekcie postaveny na IMDb GraphQL (advancedTitleSearch).

Predtym sa TC katalog bral z Cinemety, lenze jej zoznamy 'top',
'imdbRating' a 'year' nie su rebricky — 'Najlepsie hodnotene' vracalo
tituly z rokov 2024-2026 s hodnotenim od 5.3 a 'Najnovsie' obsahovalo
film z roku 1998. Nazvy teda tvrdili nieco ine, nez zoznam skutocne bol.

IMDb advancedTitleSearch vie radit podla popularity, hodnotenia aj
datumu vydania a filtrovat podla poctu hlasov, takze rebricky su naozaj
rebricky. Zaroven vracia priamo IMDb ID, ktore TC resolver potrebuje,
a plagat, takze odpada dopytovanie sa dalsej sluzby.

Cinemeta zostava zdrojom epizod serialov (meta endpoint) — to IMDb
GraphQL v tejto podobe neposkytuje.
"""
from __future__ import unicode_literals

import datetime
import json

from resources.lib.common.logger import debug
from resources.lib.constants import SC
from resources.lib.system import Http

GRAPHQL_URL = 'https://api.graphql.imdb.com/'

# IMDb typ titulu podla sekcie
TITLE_TYPE = {'movie': 'movie', 'series': 'tvSeries'}

PAGE_SIZE = 50

# Prah poctu hlasov. Bez neho sa pri razeni podla hodnotenia vyplavia
# na vrch nezname tituly s hrstkou hlasov a 10/10.
MIN_VOTES_TOP = 25000
MIN_VOTES_NEW = 500

CATALOGS = (
    {'id': 'popular', 'label': 'Populární'},
    {'id': 'top_rated', 'label': 'Nejlépe hodnocené'},
    {'id': 'newest', 'label': 'Nejnovější'},
    {'id': 'upcoming', 'label': 'Připravované'},
)

# Zanre podla IMDb (genreConstraint.allGenreIds ocakava tieto identifikatory).
GENRES = (
    'Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime',
    'Documentary', 'Drama', 'Family', 'Fantasy', 'Film-Noir', 'History',
    'Horror', 'Music', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Sport',
    'Thriller', 'War', 'Western',
)

_NODE = (
    'id titleText { text } originalTitleText { text } '
    'releaseYear { year } releaseDate { year month day } '
    'primaryImage { url } runtime { seconds } '
    'ratingsSummary { aggregateRating voteCount } '
    'titleGenres { genres { genre { text } } } '
    'plot { plotText { plainText } }'
)


def catalogs():
    return [dict(c) for c in CATALOGS]


def genres():
    return list(GENRES)


def _today():
    return datetime.date.today().isoformat()


def _constraints(kind, catalog_id, genre=None, search=None):
    """Poskladá constraints + razenie pre dany katalog."""
    parts = ['titleTypeConstraint: { anyTitleTypeIds: ["%s"] }' % TITLE_TYPE.get(kind, 'movie')]
    if genre:
        parts.append('genreConstraint: { allGenreIds: ["%s"] }' % genre)

    if search:
        parts.append('titleTextConstraint: { searchTerm: %s }' % json.dumps(search))
        return ', '.join(parts), 'POPULARITY', 'ASC'

    if catalog_id == 'top_rated':
        parts.append('userRatingsConstraint: { ratingsCountRange: { min: %d } }' % MIN_VOTES_TOP)
        return ', '.join(parts), 'USER_RATING', 'DESC'

    if catalog_id == 'newest':
        # Uz vydane tituly, od najnovsieho. Prah hlasov drzi vonku
        # polozky bez akehokolvek ohlasu.
        parts.append('releaseDateConstraint: { releaseDateRange: { end: "%s" } }' % _today())
        parts.append('userRatingsConstraint: { ratingsCountRange: { min: %d } }' % MIN_VOTES_NEW)
        return ', '.join(parts), 'RELEASE_DATE', 'DESC'

    if catalog_id == 'upcoming':
        # Este nevydane — nemaju hodnotenie, preto ziadny prah hlasov;
        # radime podla ocakavanosti (popularity).
        parts.append('releaseDateConstraint: { releaseDateRange: { start: "%s" } }' % _today())
        return ', '.join(parts), 'POPULARITY', 'ASC'

    # popular (predvolene)
    return ', '.join(parts), 'POPULARITY', 'ASC'


def _query(kind, catalog_id, genre, search, cursor, limit):
    constraints, sort_by, order = _constraints(kind, catalog_id, genre, search)
    after = ', after: %s' % json.dumps(cursor) if cursor else ''
    return (
        'query { advancedTitleSearch(first: %d%s, constraints: { %s }, '
        'sort: { sortBy: %s, sortOrder: %s }) '
        '{ pageInfo { hasNextPage endCursor } edges { node { title { %s } } } } }'
    ) % (limit, after, constraints, sort_by, order, _NODE)


def _record(title, kind):
    imdb_id = str(title.get('id') or '')
    name = ((title.get('titleText') or {}).get('text') or '').strip()
    if not imdb_id.startswith('tt') or not name:
        return None

    release = title.get('releaseDate') or {}
    year = release.get('year') or (title.get('releaseYear') or {}).get('year')
    rating = (title.get('ratingsSummary') or {}).get('aggregateRating')
    seconds = (title.get('runtime') or {}).get('seconds')
    poster = (title.get('primaryImage') or {}).get('url')
    plot = ((title.get('plot') or {}).get('plotText') or {}).get('plainText') or ''
    genre_names = [
        ((entry or {}).get('genre') or {}).get('text')
        for entry in ((title.get('titleGenres') or {}).get('genres') or [])
    ]
    genre_names = [g for g in genre_names if g]

    aired = ''
    if release.get('year') and release.get('month') and release.get('day'):
        aired = '%04d-%02d-%02d' % (release['year'], release['month'], release['day'])

    from resources.lib.api.cinemeta import build_art
    return {
        SC.ITEM_TYPE: SC.ITEM_VIDEO,
        SC.ITEM_TITLE: name,
        'unique_ids': {'imdb': imdb_id},
        SC.ITEM_INFO: {
            'title': name,
            'plot': plot,
            'year': int(year) if year else None,
            'rating': float(rating) if rating else None,
            'duration': int(seconds) if seconds else None,
            'mediatype': 'movie' if kind == 'movie' else 'tvshow',
            'genre': genre_names,
            'premiered': aired,
        },
        'art': build_art(poster=poster),
    }


def fetch(kind, catalog_id='popular', genre=None, search=None, cursor=None, limit=PAGE_SIZE):
    """Vrati (zoznam zaznamov, dalsi kurzor alebo None)."""
    query = _query(kind, catalog_id, genre, search, cursor, limit)
    response = Http.post(GRAPHQL_URL, json={'query': query}, headers={
        'Content-Type': 'application/json',
        'Origin': 'https://www.imdb.com',
    }, timeout=25)
    response.raise_for_status()
    payload = response.json() or {}
    if payload.get('errors'):
        raise ValueError('IMDb GraphQL: %s' % (payload['errors'][0] or {}).get('message', 'unknown'))

    search_block = (payload.get('data') or {}).get('advancedTitleSearch') or {}
    records = []
    for edge in search_block.get('edges') or []:
        record = _record(((edge or {}).get('node') or {}).get('title') or {}, kind)
        if record:
            records.append(record)

    page = search_block.get('pageInfo') or {}
    next_cursor = page.get('endCursor') if page.get('hasNextPage') else None
    debug('TC katalog %s/%s: %d zaznamov' % (kind, catalog_id, len(records)))
    return records, next_cursor
