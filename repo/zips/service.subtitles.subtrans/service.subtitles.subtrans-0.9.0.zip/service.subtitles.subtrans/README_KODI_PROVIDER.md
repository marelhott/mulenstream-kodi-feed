# Subtrans Kodi Subtitle Provider

This addon is a **Kodi subtitle provider** (`xbmc.python.subtitles`).
It should appear in the subtitle services list (e.g. where OpenSubtitles/Titulky providers appear).

## What it does
- In the subtitle search dialog, it offers translation into the selected language
- Uses currently active/external subtitles (or stream subtitle temp files) as source
- Translates the subtitle text through the Subtrans backend and returns a translated `.srt` to Kodi
- Timing stays unchanged

## Setup
1. Install ZIP in Kodi
2. Open addon settings and verify the backend URL and Kodi shared secret
3. In Kodi subtitle settings, enable this provider
4. During playback open subtitle search/download dialog and choose this provider result

## Notes
- Best with external `.srt`
- Streams may work when subtitle addons cache `.srt` files into Kodi temp folder
- Embedded subtitles in MKV are not extracted by this addon
