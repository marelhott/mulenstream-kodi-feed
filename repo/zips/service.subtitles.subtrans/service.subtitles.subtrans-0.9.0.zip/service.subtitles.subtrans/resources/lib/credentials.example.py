# -*- coding: utf-8 -*-
"""Baked-in credentials for a private build.

Copy this file to `credentials.py` next to it and fill in the values. On first
run the private values are copied into the addon's persistent Kodi profile, so
later public updates can replace the install directory without losing them.
Any empty Kodi setting falls back to the persistent private value.

    cp resources/lib/credentials.example.py resources/lib/credentials.py

`credentials.py` remains git-ignored so the plain source values do not enter
normal text diffs. This personal repository intentionally includes the file
inside its release ZIP to provision Kodi without manual TV input.

Kodi settings always win when they are filled in, so you can still override
any of this per device without touching the file.
"""

CREDENTIALS = {
    # OpenSubtitles.com -- the API key comes from your account page,
    # section "API consumers". Username and password are the normal login.
    'osdb_api_key': '',
    'osdb_username': '',
    'osdb_password': '',

    # Titulky.com -- no API key exists; these are the site login.
    'titulky_username': '',
    'titulky_password': '',

    # Backend shared secret, if you do not want it in the settings dialog.
    'backend_secret': '',
}
