import os
import re
import time
import json
import urllib.parse
import xml.etree.ElementTree as ET

try:
    import xbmc  # type: ignore
except ImportError:
    xbmc = None

try:
    import xbmcgui  # type: ignore
except ImportError:
    xbmcgui = None

from .models import VideoIdentity


TOKEN_RE = re.compile(r'[A-Za-z0-9]+')
YEAR_RE = re.compile(r'\b(19|20)\d{2}\b')
EPISODE_RE = re.compile(r'\b[sS](\d{1,2})[ ._-]?[eE](\d{1,2})\b')


def tokenize_text(value):
    tokens = []
    for token in TOKEN_RE.findall(str(value or '').lower()):
        if len(token) < 2:
            continue
        if token in ('web', 'dl', 'rip', 'bluray', 'brrip', 'x264', 'x265', 'h264', 'h265', 'hevc', 'aac'):
            continue
        tokens.append(token)
    return tokens


def _shared_token_count(a, b):
    return len(set(tokenize_text(a)) & set(tokenize_text(b)))


def _looks_like_reliable_title(label, video_path):
    label = str(label or '').strip()
    if not label:
        return False
    stem = os.path.splitext(os.path.basename(video_path or ''))[0]
    if not stem:
        return True
    stem_lower = stem.lower()
    if stem_lower.startswith('temp') or stem_lower.startswith('stream'):
        return True
    if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', stem_lower):
        return True
    if re.match(r'^[0-9a-f]{24,}$', stem_lower):
        return True
    if re.match(r'^[0-9a-z_-]{24,}$', stem_lower) and len(tokenize_text(stem_lower)) <= 2:
        return True
    if label.lower() == stem.lower():
        return True
    stem_tokens = set(tokenize_text(stem))
    label_tokens = set(tokenize_text(label))
    if not stem_tokens or not label_tokens:
        return False
    shared = len(stem_tokens & label_tokens)
    return shared >= max(1, min(2, len(stem_tokens)))


def _get_info_label(key):
    try:
        return (xbmc.getInfoLabel(key) if xbmc else '') or ''
    except Exception:
        return ''


def _get_home_property(key):
    try:
        return (xbmcgui.Window(10000).getProperty(key) if xbmcgui else '') or ''
    except Exception:
        return ''


def _umbrella_metadata():
    if _get_home_property('SC.play_item').strip():
        return {}
    out = {}
    raw_meta = _get_home_property('plugin.video.umbrella.container.meta')
    if raw_meta:
        try:
            meta = json.loads(urllib.parse.unquote(raw_meta.replace('%22', '\\"')))
            if isinstance(meta, dict):
                for src_key, dst_key in (
                    ('title', 'title'),
                    ('originaltitle', 'title'),
                    ('tvshowtitle', 'tvshowtitle'),
                    ('year', 'year'),
                    ('imdb', 'imdb'),
                    ('imdbnumber', 'imdb'),
                    ('season', 'season'),
                    ('episode', 'episode'),
                ):
                    value = str(meta.get(src_key) or '').strip()
                    if value and not out.get(dst_key):
                        out[dst_key] = value
        except Exception:
            pass
    for prop_key, dst_key in (
        ('plugin.video.umbrella.container.title', 'title'),
        ('plugin.video.umbrella.container.imdb', 'imdb'),
        ('plugin.video.umbrella.container.season', 'season'),
        ('plugin.video.umbrella.container.episode', 'episode'),
    ):
        value = _get_home_property(prop_key).strip()
        if value and not out.get(dst_key):
            out[dst_key] = value
    if out.get('tvshowtitle'):
        out['title'] = out.get('tvshowtitle') or out.get('title')
    return out


def _stream_cinema_metadata():
    out = {}
    raw = _get_home_property('SC.play_item')
    if not raw:
        return out
    try:
        data = json.loads(raw)
    except Exception:
        return out
    if not isinstance(data, dict):
        return out
    selected = data.get('strms') if isinstance(data.get('strms'), dict) else {}
    for source in (data, selected):
        if not isinstance(source, dict):
            continue
        for src_key, dst_key in (
            ('title', 'title'),
            ('originaltitle', 'title'),
            ('original_title', 'title'),
            ('name', 'title'),
            ('year', 'year'),
            ('imdb', 'imdb'),
            ('imdbnumber', 'imdb'),
            ('season', 'season'),
            ('episode', 'episode'),
        ):
            value = str(source.get(src_key) or '').strip()
            if value and not out.get(dst_key):
                out[dst_key] = value
    return out


def _parse_int(value):
    try:
        parsed = int(str(value or '').strip())
        return parsed if parsed > 0 else None
    except Exception:
        return None


def _extract_year(*values):
    for value in values:
        match = YEAR_RE.search(str(value or ''))
        if match:
            return int(match.group(0))
    return None


def _extract_episode(path, *values):
    for value in (path,) + values:
        match = EPISODE_RE.search(str(value or ''))
        if match:
            return int(match.group(1)), int(match.group(2))
    return None, None


def _extract_imdb_id(*values):
    for value in values:
        txt = str(value or '').strip()
        if txt.startswith('tt') and txt[2:].isdigit():
            return txt
    return ''


def _read_imdb_from_nfo(video_path):
    if not video_path or '://' in video_path:
        return ''
    folder = os.path.dirname(video_path)
    stem = os.path.splitext(os.path.basename(video_path))[0]
    candidates = [
        os.path.join(folder, stem + '.nfo'),
        os.path.join(folder, 'movie.nfo'),
        os.path.join(folder, 'tvshow.nfo'),
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            root = ET.parse(path).getroot()
        except Exception:
            continue
        for node in root.findall('.//uniqueid'):
            imdb_type = str(node.attrib.get('type') or '').lower()
            txt = str(node.text or '').strip()
            if imdb_type == 'imdb' and txt.startswith('tt'):
                return txt
        for tag in ('imdbid', 'imdb_id'):
            node = root.find('.//%s' % tag)
            if node is not None:
                txt = str(node.text or '').strip()
                if txt.startswith('tt'):
                    return txt
    return ''


def detect_mode(identity):
    if identity.season is not None and identity.episode is not None:
        return 'episode'
    return 'movie'


def build_video_identity(video_path, playback_started_at=None, params=None):
    params = params or {}
    playback_started_at = playback_started_at or time.time()
    stream_cinema_meta = _stream_cinema_metadata()
    umbrella_meta = _umbrella_metadata()
    title = ''
    if stream_cinema_meta.get('title'):
        title = stream_cinema_meta.get('title')
    elif umbrella_meta.get('title'):
        title = umbrella_meta.get('title')
    for key in (
        'VideoPlayer.OriginalTitle',
        'VideoPlayer.Title',
        'Player.Title',
        'ListItem.OriginalTitle',
        'ListItem.Title',
    ):
        if title:
            break
        candidate = _get_info_label(key)
        if _looks_like_reliable_title(candidate, video_path):
            title = candidate
            break
    if not title:
        title = os.path.splitext(os.path.basename(video_path or ''))[0]
    season = _parse_int(_get_info_label('VideoPlayer.Season'))
    episode = _parse_int(_get_info_label('VideoPlayer.Episode'))
    season = season if season is not None else _parse_int(stream_cinema_meta.get('season'))
    episode = episode if episode is not None else _parse_int(stream_cinema_meta.get('episode'))
    season = season if season is not None else _parse_int(umbrella_meta.get('season'))
    episode = episode if episode is not None else _parse_int(umbrella_meta.get('episode'))
    if season is None or episode is None:
        parsed_season, parsed_episode = _extract_episode(
            video_path,
            _get_info_label('VideoPlayer.Filename'),
            _get_info_label('Player.Filename'),
            params.get('searchstring'),
            params.get('query'),
            params.get('title'),
        )
        season = season if season is not None else parsed_season
        episode = episode if episode is not None else parsed_episode

    year = _parse_int(_get_info_label('VideoPlayer.Year')) or _extract_year(
        stream_cinema_meta.get('year'),
        umbrella_meta.get('year'),
        _get_info_label('VideoPlayer.Title'),
        _get_info_label('VideoPlayer.OriginalTitle'),
        video_path,
        params.get('searchstring'),
        params.get('query'),
        params.get('title'),
    )
    imdb_id = _extract_imdb_id(
        stream_cinema_meta.get('imdb'),
        umbrella_meta.get('imdb'),
        _get_info_label('VideoPlayer.IMDBNumber'),
        _get_info_label('ListItem.IMDBNumber'),
        params.get('imdbnumber'),
        params.get('imdb_id'),
    )
    if not imdb_id:
        imdb_id = _read_imdb_from_nfo(video_path)
    filename_stem = os.path.splitext(os.path.basename(video_path or ''))[0]
    folder = os.path.dirname(video_path) if video_path and '://' not in video_path else ''
    return VideoIdentity(
        path=video_path or '',
        title=title.strip() or filename_stem,
        year=year,
        season=season,
        episode=episode,
        imdb_id=imdb_id,
        is_stream=bool(video_path and '://' in video_path and not video_path.startswith('file://')),
        playback_started_at=playback_started_at,
        title_tokens=set(tokenize_text(title)),
        path_tokens=set(tokenize_text(filename_stem)),
        folder=folder,
        filename_stem=filename_stem,
    )
