"""OpenSubtitles moviehash computation.

OS uses a deterministic hash of the first and last 64 KiB of the video file
plus the file size, summed as little-endian uint64 values. Subtitles uploaded
against the same file produce the same hash, so a hash-based search returns
subtitles guaranteed to be in sync with the exact release being played.

Two backends:
- HTTP URLs (Stream Cinema / Umbrella / direct links): HEAD for size, then
  two Range GETs (first 64 KiB + last 64 KiB).
- Local / Kodi VFS paths (smb://, nfs://, local files): xbmcvfs.File.

Returns (hash_hex_lowercase_16, size_int) or (None, None) on any failure.
Never raises: hashing is best-effort, callers fall back to text search.
"""

from __future__ import annotations

import struct
import urllib.error
import urllib.request

CHUNK = 64 * 1024
UINT64_MASK = 0xFFFFFFFFFFFFFFFF


def compute_for_path(path, head_timeout=8, read_timeout=15, user_agent='SubtransKodi'):
    if not path or not isinstance(path, str):
        return None, None
    if path.startswith(('http://', 'https://')):
        return _compute_http(path, head_timeout, read_timeout, user_agent)
    return _compute_xbmcvfs(path)


def _finalize(data: bytes, size: int):
    if not data or len(data) < 16 or size <= 0:
        return None, None
    h = size & UINT64_MASK
    usable = len(data) - (len(data) % 8)
    for i in range(0, usable, 8):
        h = (h + struct.unpack_from('<Q', data, i)[0]) & UINT64_MASK
    return format(h, '016x'), size


def _compute_http(url, head_timeout, read_timeout, ua):
    try:
        req = urllib.request.Request(url, method='HEAD', headers={'User-Agent': ua})
        with urllib.request.urlopen(req, timeout=head_timeout) as resp:
            size = int(resp.headers.get('Content-Length') or 0)
        if size < CHUNK * 2:
            return None, None
        ranges = [(0, CHUNK - 1), (size - CHUNK, size - 1)]
        data = bytearray()
        for start, end in ranges:
            r = urllib.request.Request(
                url,
                headers={'User-Agent': ua, 'Range': 'bytes=%d-%d' % (start, end)},
            )
            with urllib.request.urlopen(r, timeout=read_timeout) as resp:
                chunk = resp.read()
            if not chunk:
                return None, None
            data.extend(chunk)
        return _finalize(bytes(data), size)
    except Exception:
        return None, None


def _compute_xbmcvfs(path):
    try:
        import xbmcvfs  # type: ignore
    except Exception:
        return None, None
    try:
        stat = xbmcvfs.Stat(path)
        size = int(stat.st_size())
    except Exception:
        try:
            f = xbmcvfs.File(path)
            try:
                size = int(f.size())
            finally:
                f.close()
        except Exception:
            return None, None
    if size < CHUNK * 2:
        return None, None
    try:
        f = xbmcvfs.File(path)
        try:
            head = f.readBytes(CHUNK)
            f.seek(size - CHUNK)
            tail = f.readBytes(CHUNK)
        finally:
            f.close()
    except Exception:
        return None, None
    if not head or not tail:
        return None, None
    return _finalize(bytes(head) + bytes(tail), size)
