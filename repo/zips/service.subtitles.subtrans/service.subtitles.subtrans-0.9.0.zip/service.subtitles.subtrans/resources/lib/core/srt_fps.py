"""Detect and repair subtitle/video FPS mismatch via duration-ratio analysis.

Common case: a 25 fps PAL TV rip played back at 23.976 fps cinema rate (or
vice versa) causes subtitles to drift linearly — about 4 % over a 90-minute
movie. The SRT itself has no FPS metadata, so we infer mismatch by comparing
the subtitle's last timestamp to the video duration. If the ratio matches a
canonical FPS mismatch band (PAL speedup, 24↔25, etc.), all timestamps are
rescaled by the inverse ratio.

This is intentionally conservative: only well-known ratios are touched.
Random offsets (different cut, missing scenes) are left for the manual
adjust dialog and per-file offset memory.
"""

from __future__ import annotations

import re

_TS_RE = re.compile(r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{3})')


FPS_MISMATCH_BANDS = (
    (0.956, 0.975),
    (1.025, 1.045),
    (0.960, 0.985),
    (1.015, 1.040),
)


def detect_scale_factor(sub_duration_sec, video_duration_sec):
    """Return timestamp multiplier (sub_time *= factor), or 1.0 if no action.

    Math: if subs were timed against an FPS_A master but the actual video is
    FPS_B, every subtitle event at original time T appears at video time
    T * (FPS_A / FPS_B). Since the video plays at the actual rate, the video
    duration is master_duration * (FPS_A / FPS_B), so the multiplier equals
    video_duration / sub_duration. We accept only ratios that fall inside
    canonical FPS mismatch bands to avoid touching random cut differences.
    """
    if not sub_duration_sec or not video_duration_sec:
        return 1.0
    try:
        sub = float(sub_duration_sec)
        vid = float(video_duration_sec)
    except (TypeError, ValueError):
        return 1.0
    if sub < 60 or vid < 60:
        return 1.0
    ratio = vid / sub
    for lo, hi in FPS_MISMATCH_BANDS:
        if lo <= ratio <= hi:
            return ratio
    return 1.0


def parse_srt_end_time(srt_text):
    """Return last subtitle end timestamp in seconds, or None."""
    if not srt_text:
        return None
    last_end = 0.0
    found = False
    for m in _TS_RE.finditer(srt_text):
        h = int(m.group(1))
        mn = int(m.group(2))
        s = int(m.group(3))
        ms = int(m.group(4))
        end = h * 3600 + mn * 60 + s + ms / 1000.0
        if end > last_end:
            last_end = end
            found = True
    return last_end if found else None


def _format_timestamp(secs):
    secs = max(0.0, float(secs))
    total_ms = int(round(secs * 1000))
    h, total_ms = divmod(total_ms, 3600 * 1000)
    mn, total_ms = divmod(total_ms, 60 * 1000)
    s, ms = divmod(total_ms, 1000)
    return '%02d:%02d:%02d,%03d' % (h, mn, s, ms)


def rescale_timestamps(srt_text, scale):
    """Multiply every SRT timestamp by `scale`. Returns new SRT text."""
    if abs(scale - 1.0) < 1e-6 or not srt_text:
        return srt_text

    def repl(m):
        h = int(m.group(1))
        mn = int(m.group(2))
        s = int(m.group(3))
        ms = int(m.group(4))
        secs = h * 3600 + mn * 60 + s + ms / 1000.0
        return _format_timestamp(secs * scale)

    return _TS_RE.sub(repl, srt_text)


def adjust_srt_for_video_duration(srt_text, video_duration_sec):
    """If SRT duration vs video duration matches a known FPS mismatch band,
    rescale all timestamps. Returns (new_srt, scale_applied)."""
    if not srt_text or not video_duration_sec:
        return srt_text, 1.0
    sub_dur = parse_srt_end_time(srt_text)
    if not sub_dur:
        return srt_text, 1.0
    scale = detect_scale_factor(sub_dur, video_duration_sec)
    if abs(scale - 1.0) < 1e-6:
        return srt_text, 1.0
    return rescale_timestamps(srt_text, scale), scale
