"""Per-video subtitle offset memory.

Stores a single subtitle delay (in milliseconds) per video, keyed by a stable
identifier (OS hash when available, otherwise a path-derived key). The addon
restores the offset automatically when a subtitle is applied to the same video
and offers a small adjust dialog to update it.

JSON layout in addon_data/subtitle_offsets.json:
    {
        "<video_key>": {
            "offset_ms": 5000,
            "updated_at": 1719700000,
            "label": "Movie Title (2024)"
        },
        ...
    }
"""

from __future__ import annotations

import json
import os
import time

FILENAME = 'subtitle_offsets.json'


def _path(profile_dir):
    return os.path.join(profile_dir, FILENAME)


def _load(profile_dir):
    try:
        with open(_path(profile_dir), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _save(profile_dir, data):
    p = _path(profile_dir)
    os.makedirs(os.path.dirname(p) or '.', exist_ok=True)
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(tmp, p)


def get_offset(profile_dir, video_key):
    if not video_key:
        return None
    entry = _load(profile_dir).get(video_key)
    if not isinstance(entry, dict):
        return None
    try:
        return int(entry.get('offset_ms'))
    except Exception:
        return None


def get_meta(profile_dir, video_key):
    if not video_key:
        return None
    entry = _load(profile_dir).get(video_key)
    if isinstance(entry, dict):
        return entry
    return None


def set_offset(profile_dir, video_key, offset_ms, label=''):
    if not video_key:
        return
    data = _load(profile_dir)
    data[video_key] = {
        'offset_ms': int(offset_ms),
        'updated_at': int(time.time()),
        'label': label or data.get(video_key, {}).get('label', ''),
    }
    _save(profile_dir, data)


def clear_offset(profile_dir, video_key):
    if not video_key:
        return
    data = _load(profile_dir)
    if video_key in data:
        del data[video_key]
        _save(profile_dir, data)


def prune_older_than(profile_dir, max_age_sec):
    cutoff = time.time() - max_age_sec
    data = _load(profile_dir)
    changed = False
    for key in list(data.keys()):
        try:
            if int(data[key].get('updated_at', 0)) < cutoff:
                del data[key]
                changed = True
        except Exception:
            del data[key]
            changed = True
    if changed:
        _save(profile_dir, data)


def _remote_request(backend_request_fn, path, payload, timeout=5):
    """Call backend /api/kodi/offsets/*. Returns parsed dict or {} on failure."""
    if not callable(backend_request_fn):
        return {}
    try:
        return backend_request_fn(path, payload, timeout=timeout) or {}
    except Exception:
        return {}


def get_remote_offset(backend_request_fn, video_key):
    """Fetch offset from backend store. Returns (offset_ms, label) or (None, None)."""
    if not video_key:
        return None, None
    data = _remote_request(backend_request_fn, '/api/kodi/offsets/get', {'key': video_key})
    if not data.get('ok'):
        return None, None
    val = data.get('offsetMs')
    if val is None:
        return None, None
    try:
        return int(val), (data.get('label') or '')
    except Exception:
        return None, None


def set_remote_offset(backend_request_fn, video_key, offset_ms, label=''):
    if not video_key:
        return False
    data = _remote_request(backend_request_fn, '/api/kodi/offsets/set', {
        'key': video_key,
        'offsetMs': int(offset_ms),
        'label': label or '',
    })
    return bool(data.get('ok'))


def clear_remote_offset(backend_request_fn, video_key):
    if not video_key:
        return False
    data = _remote_request(backend_request_fn, '/api/kodi/offsets/clear', {'key': video_key})
    return bool(data.get('ok'))
