import os
import re
import time

from .models import SubtitleCandidate
from .video_identity import detect_mode, tokenize_text


GENERIC_TEMP_NAMES = ('subtitle', 'subtitles', 'tempsubtitle', 'temp')
RELEASE_HINTS = ('web', 'webdl', 'webrip', 'bluray', 'brrip', 'remux', 'x264', 'x265', 'h264', 'h265', 'hevc', 'nf', 'amzn', 'dsnp')


def _tier(confidence):
    if confidence >= 75:
        return 'high'
    if confidence >= 40:
        return 'medium'
    return 'low'


def _release_tokens(value):
    txt = str(value or '').lower()
    return {hint for hint in RELEASE_HINTS if hint in txt}


def _looks_opaque_stream_identity(identity):
    filename = str(getattr(identity, 'filename_stem', '') or '').lower()
    title = str(getattr(identity, 'title', '') or '').lower()
    if not filename:
        return False
    if filename.startswith('temp') or filename.startswith('stream'):
        return True
    if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', filename):
        return True
    if re.match(r'^[0-9a-f]{24,}$', filename):
        return True
    if re.match(r'^[0-9a-z_-]{24,}$', filename) and len(tokenize_text(filename)) <= 2:
        return True
    return bool(title and title == filename)


def score_candidate(path, source, identity, metadata=None, now=None):
    metadata = metadata or {}
    now = now or time.time()
    name = os.path.basename(path or '')
    stem = os.path.splitext(name)[0]
    lower_name = name.lower()
    cand_tokens = set(tokenize_text(stem))
    reasons = []
    score = 0

    if metadata.get('preferred'):
        score += 80
        reasons.append('active subtitle')

    if identity.folder and os.path.dirname(path) == identity.folder:
        score += 20
        reasons.append('same folder')

    if identity.filename_stem:
        video_stem = identity.filename_stem.lower()
        if stem.lower() == video_stem:
            score += 50
            reasons.append('exact basename')
        elif stem.lower().startswith(video_stem + '.') or stem.lower().startswith(video_stem + ' '):
            score += 30
            reasons.append('basename prefix')

    shared_tokens = cand_tokens & identity.all_tokens
    if shared_tokens:
        token_bonus = min(30, len(shared_tokens) * 5)
        score += token_bonus
        reasons.append('token overlap')
        if 0 < len(identity.all_tokens) <= 2 and identity.all_tokens.issubset(cand_tokens):
            score += 20
            reasons.append('exact short title')

    year_str = str(identity.year) if identity.year else ''
    if year_str and year_str in stem:
        score += 30
        reasons.append('year match')

    mode = detect_mode(identity)
    episode_tag = ''
    if identity.season is not None and identity.episode is not None:
        episode_tag = 's%02de%02d' % (identity.season, identity.episode)
    if mode == 'episode':
        if episode_tag and episode_tag in lower_name:
            score += 60
            reasons.append('episode match')
        else:
            score -= 40
            reasons.append('missing episode match')

    if any(tok in lower_name for tok in ('.en.', '.eng.', 'english')):
        score += 10
        reasons.append('english source hint')

    release_overlap = _release_tokens(stem) & (_release_tokens(identity.filename_stem) | _release_tokens(identity.title))
    if release_overlap:
        score += min(30, len(release_overlap) * 10)
        reasons.append('release overlap')

    entry_count = int(metadata.get('entry_count') or 0)
    if metadata.get('valid'):
        score += 5
        reasons.append('valid srt')
    if entry_count >= 50:
        score += 10
        reasons.append('healthy subtitle length')
    elif metadata.get('valid') and entry_count < 10:
        score -= 25
        reasons.append('very short subtitle')

    if '.subtrans.' in lower_name or stem.lower().endswith('.subtrans'):
        score -= 200
        reasons.append('already translated')

    if metadata.get('is_forced'):
        score -= 50
        reasons.append('forced subtitle')
    if metadata.get('is_hearing_impaired'):
        score -= 15
        reasons.append('hearing impaired variant')

    if source == 'temp':
        age_sec = None
        delta = None
        try:
            age_sec = max(0, now - os.path.getmtime(path))
        except Exception:
            age_sec = None
        if age_sec is not None and identity.playback_started_at:
            delta = abs(os.path.getmtime(path) - identity.playback_started_at)
            if delta <= 120:
                score += 25
                reasons.append('recent temp file')
            elif delta <= 300:
                score += 10
                reasons.append('temp file near playback start')
        generic_hit = any(token == stem.lower() or token in stem.lower() for token in GENERIC_TEMP_NAMES)
        if generic_hit:
            score -= 15
            reasons.append('generic temp name')
        if (
            _looks_opaque_stream_identity(identity)
            and metadata.get('valid')
            and entry_count >= 50
            and (metadata.get('preferred') or (delta is not None and delta <= 300))
            and score < 45
        ):
            score = 45
            reasons.append('opaque stream temp fallback')

    confidence = max(0, min(100, score))
    return SubtitleCandidate(
        path=path,
        source=source,
        confidence=confidence,
        tier=_tier(confidence),
        reasons=reasons,
        is_valid=bool(metadata.get('valid')),
        entry_count=entry_count,
        is_forced=bool(metadata.get('is_forced')),
        is_hearing_impaired=bool(metadata.get('is_hearing_impaired')),
    )


def score_osdb_item(item, identity, release_hint=''):
    release_label = str(item.get('label') or '')
    file_name = str(item.get('file_name') or item.get('fileName') or '')
    combined = '%s %s %s' % (
        release_label,
        file_name,
        release_hint or '',
    )
    txt = combined.lower()
    file_txt = file_name.lower()
    score = 20
    reasons = []
    hash_match = bool(item.get('hashMatch') or item.get('hash_match'))
    if hash_match:
        score = 100
        reasons = ['exact file hash match']
        return max(0, min(100, score)), reasons
    shared_tokens = set(tokenize_text(txt)) & identity.all_tokens
    if shared_tokens:
        score += min(25, len(shared_tokens) * 5)
        reasons.append('title overlap')
    file_shared_tokens = set(tokenize_text(file_txt)) & identity.all_tokens if file_txt else set()
    if file_shared_tokens:
        score += min(35, len(file_shared_tokens) * 7)
        reasons.append('filename overlap')
    elif file_txt:
        score -= 30
        reasons.append('filename title mismatch')
    if identity.year and str(identity.year) in txt:
        score += 20
        reasons.append('year match')
    release_overlap = _release_tokens(txt) & (_release_tokens(identity.filename_stem) | _release_tokens(release_hint))
    if release_overlap:
        score += min(30, len(release_overlap) * 10)
        reasons.append('release overlap')
    try:
        score += min(20, int(item.get('confidence') or 0) // 5)
    except Exception:
        pass
    if 'forced' in txt or 'foreign' in txt or 'foreignparts' in txt or 'foreign-parts' in txt:
        score -= 50
        reasons.append('forced/foreign subtitle')
    if any(tok in txt for tok in ('sdh', 'closed-caption', 'closedcaption', 'hearing-impaired', 'hearingimpaired')):
        score -= 25
        reasons.append('hearing impaired variant')
    elif re.search(r'(^|[._-])cc([._-]|$)', txt):
        score -= 15
        reasons.append('closed-caption variant')
    return max(0, min(100, score)), reasons
