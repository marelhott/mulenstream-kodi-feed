import os
import re

from .video_identity import tokenize_text

try:
    import xbmcvfs  # type: ignore
except Exception:  # pragma: no cover - outside Kodi runtime
    xbmcvfs = None


SRT_BLOCK_RE = re.compile(
    r'(?ms)^\s*(\d+)\s*\n'
    r'([0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3})\s*-->\s*([0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3})\s*\n'
    r'(.*?)(?=\n\s*\n|\Z)'
)


def _read_text(path):
    raw = None
    try:
        with open(path, 'rb') as handle:
            raw = handle.read()
    except Exception:
        if xbmcvfs is not None:
            try:
                handle = xbmcvfs.File(path)
                if hasattr(handle, 'readBytes'):
                    raw = handle.readBytes()
                else:
                    raw = handle.read()
                try:
                    handle.close()
                except Exception:
                    pass
            except Exception:
                raw = None
    if raw is None:
        raise ValueError('read failed')
    raw = bytes(raw)
    for encoding in ('utf-8-sig', 'utf-8', 'cp1250', 'cp1252', 'latin-1'):
        try:
            return raw.decode(encoding)
        except Exception:
            continue
    raise ValueError('decode failed')


def inspect_subtitle_file(path):
    name = os.path.basename(path or '').lower()
    info = {
        'valid': False,
        'entry_count': 0,
        'is_forced': 'forced' in name,
        'is_hearing_impaired': any(token in name for token in ('sdh', 'hearing', 'hi')),
        'tokens': set(tokenize_text(os.path.splitext(name)[0])),
    }
    if not path:
        return info
    try:
        if not os.path.isfile(path):
            if xbmcvfs is None or not xbmcvfs.exists(path):
                return info
    except Exception:
        if xbmcvfs is None or not xbmcvfs.exists(path):
            return info
    try:
        text = _read_text(path)
    except Exception:
        return info
    matches = list(SRT_BLOCK_RE.finditer(text.replace('\r\n', '\n').replace('\r', '\n')))
    info['entry_count'] = len(matches)
    info['valid'] = len(matches) > 0
    sample_text = ' '.join((m.group(4) or '').strip() for m in matches[:5]).lower()
    czech_chars = sum(sample_text.count(ch) for ch in 'ěščřžýáíéúůóďťňľĺ')
    info['looks_non_english'] = czech_chars >= 2
    return info
