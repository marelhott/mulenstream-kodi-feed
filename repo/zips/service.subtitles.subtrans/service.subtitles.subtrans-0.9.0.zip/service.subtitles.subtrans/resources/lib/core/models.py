from dataclasses import dataclass, field
from typing import List, Optional, Set


@dataclass
class VideoIdentity:
    path: str
    title: str
    year: Optional[int]
    season: Optional[int]
    episode: Optional[int]
    imdb_id: str
    is_stream: bool
    playback_started_at: float
    title_tokens: Set[str] = field(default_factory=set)
    path_tokens: Set[str] = field(default_factory=set)
    folder: str = ''
    filename_stem: str = ''

    @property
    def all_tokens(self):
        return set(self.title_tokens) | set(self.path_tokens)


@dataclass
class SubtitleCandidate:
    path: str
    source: str
    confidence: int
    tier: str
    reasons: List[str] = field(default_factory=list)
    is_valid: bool = False
    entry_count: int = 0
    is_forced: bool = False
    is_hearing_impaired: bool = False

