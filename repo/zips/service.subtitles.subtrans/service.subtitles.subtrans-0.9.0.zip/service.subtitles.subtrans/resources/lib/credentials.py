# -*- coding: utf-8 -*-
"""Private credentials for the user's personal Subtrans build.

This file is intentionally ignored by git and excluded from the public
repository ZIP. A separate private ZIP may include it for sideloading.
"""

CREDENTIALS = {
    'osdb_api_key': 'QH2Oz4NfI3mfbjX9E8ZzM9zPC3XoZhem',
    'osdb_username': 'oret',
    'osdb_password': 'Maho1505',
    'titulky_username': 'oret',
    'titulky_password': 'albert1505',
    'backend_secret': '0660be1588ae861fbcaff45c23e4ca1a9e94f3447ba2e464bb621d363a8b9a72',
}
