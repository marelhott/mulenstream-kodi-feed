# -*- coding: utf-8 -*-
"""Release matching, shared by every provider.

The point of the aggregator is that a titulky.com row and an OpenSubtitles row
are scored on the same scale, so they can be ranked against each other inside
one group. Scoring here is deliberately source-agnostic: it looks at the
release string, the year, and the hash flag, and nothing else. Per-source
popularity is only ever used as a tie-break, because download counts are not
comparable between services.
"""

import re
import unicodedata

from .base import LANG_EN, normalize_release

_RES_TOKENS = ('2160p', '1080p', '720p', '480p')

_STRUCTURAL_TOKENS = set([
    '2160p', '1080p', '720p', '480p', '4k', 'uhd', 'hdr', 'hdr10', 'sdr',
    'web', 'webdl', 'web-dl', 'webrip', 'bluray', 'bdrip', 'brrip', 'remux',
    'dvdrip', 'hdtv', 'x264', 'x265', 'h264', 'h265', 'hevc', 'avc',
    'aac', 'ac3', 'eac3', 'ddp', 'dd5', 'dts', 'atmos', 'truehd', 'flac',
    'proper', 'repack', 'internal', 'extended', 'unrated', 'multi', 'dual',
    'eng', 'english', 'cz', 'cze', 'czech', 'sk', 'slo', 'subs', 'subtitles',
    'titulky', 'forced', 'sdh', 'cc',
])

_FORCED_RE = re.compile(r'\b(forced|foreign[\s._-]?only)\b', re.IGNORECASE)
_SDH_RE = re.compile(r'\b(sdh|hearing[\s._-]?impaired|hi)\b', re.IGNORECASE)
_YEAR_RE = re.compile(r'\b(19|20)\d{2}\b')
_EPISODE_RE = re.compile(r'\bS\d{1,2}\s*E\d{1,3}\b|\b\d{1,2}x\d{1,3}\b', re.IGNORECASE)
_LEADING_ARTICLES = set(('a', 'an', 'the'))
MIN_MATCH_SCORE = 25


def looks_forced(*values):
    return any(_FORCED_RE.search(str(v or '')) for v in values)


def looks_sdh(*values):
    return any(_SDH_RE.search(str(v or '')) for v in values)


def looks_episodic(*values):
    """True when the text names a season/episode."""
    return any(_EPISODE_RE.search(str(v or '')) for v in values)


def profile(value):
    """Pull the structural fingerprint out of a release string."""
    text = normalize_release(value)
    tokens = set(t for t in text.split(' ') if t)
    out = {
        'resolution': '',
        'source': '',
        'codec': '',
        'audio': '',
        'hdr': '',
        'group': '',
        'tokens': set(),
    }
    for token in _RES_TOKENS:
        if token in tokens:
            out['resolution'] = token
            break
    if '4k' in tokens or 'uhd' in tokens:
        out['resolution'] = out['resolution'] or '2160p'

    if 'remux' in tokens:
        out['source'] = 'remux'
    elif 'bluray' in tokens or 'bdrip' in tokens or 'brrip' in tokens:
        out['source'] = 'bluray'
    elif 'webrip' in tokens:
        out['source'] = 'webrip'
    elif 'webdl' in tokens or 'web' in tokens:
        out['source'] = 'webdl'
    elif 'hdtv' in tokens:
        out['source'] = 'hdtv'
    elif 'dvdrip' in tokens:
        out['source'] = 'dvdrip'

    if tokens & set(['x265', 'h265', 'hevc']):
        out['codec'] = 'x265'
    elif tokens & set(['x264', 'h264', 'avc']):
        out['codec'] = 'x264'

    if 'atmos' in tokens:
        out['audio'] = 'atmos'
    elif 'truehd' in tokens:
        out['audio'] = 'truehd'
    elif tokens & set(['ddp', 'eac3']):
        out['audio'] = 'ddp'
    elif 'dts' in tokens:
        out['audio'] = 'dts'
    elif tokens & set(['aac', 'ac3']):
        out['audio'] = 'aac'

    if 'dv' in tokens or 'dovi' in tokens:
        out['hdr'] = 'dv'
    elif 'hdr10' in tokens or 'hdr' in tokens:
        out['hdr'] = 'hdr'

    # Release group: the trailing word of a scene name, once the structural
    # vocabulary is stripped. Noisy, but a group match is the single strongest
    # signal that two files are the same encode.
    meaningful = [t for t in text.split(' ') if t and t not in _STRUCTURAL_TOKENS]
    if meaningful:
        tail = meaningful[-1]
        if 2 <= len(tail) <= 15 and not tail.isdigit():
            out['group'] = tail

    out['tokens'] = set(
        t for t in meaningful
        if 2 <= len(t) <= 15 and not re.match(r'^(19|20)\d{2}$', t)
    )
    return out


def normalize_title(value):
    """ASCII-ish title normalization used only for identity matching."""
    text = unicodedata.normalize('NFKD', str(value or '').lower())
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    tokens = re.sub(r'[^a-z0-9]+', ' ', text).split()
    while tokens and tokens[0] in _LEADING_ARTICLES:
        tokens.pop(0)
    return ' '.join(tokens)


def title_match_score(request_title, candidate_title, candidate_release=''):
    """Return a strong identity signal and whether the titles are plausible.

    Short one-word titles are deliberately strict: a fulltext result for
    "Up" must actually be that title, not "Knuckle Up" or a random row from
    the search page. A release name beginning with the title is accepted so a
    localized display title can still match an original scene release.
    """
    query = normalize_title(request_title)
    title = normalize_title(candidate_title)
    release = normalize_title(candidate_release)
    if not query:
        return 0, True, []
    if title == query:
        return 34, True, ['název']
    if release == query or release.startswith(query + ' '):
        return 30, True, ['název releasu']

    query_tokens = query.split()
    candidate_tokens = set((title + ' ' + release).split())
    if len(query_tokens) == 1 and len(query_tokens[0]) <= 4:
        return -90, False, ['jiný název']

    overlap = sum(1 for token in query_tokens if token in candidate_tokens)
    ratio = overlap / float(len(query_tokens) or 1)
    if ratio >= 0.8:
        return 24, True, ['shoda názvu']
    if ratio >= 0.5 and overlap >= 2:
        return 10, True, ['částečný název']
    return -90, False, ['jiný název']


def release_score(candidate_text, hint_text):
    """Compare a candidate release string against what is actually playing.

    Returns a roughly -100..100 signal. Absent information is neutral: a
    candidate that simply does not mention its codec is not punished, only one
    that mentions a *different* codec is.
    """
    hint = profile(hint_text)
    cand = profile(candidate_text)
    if not hint['tokens'] and not hint['group'] and not hint['resolution']:
        return 0, []

    score = 0
    reasons = []

    def compare(field, hit, miss, label):
        nonlocal score
        if not hint[field]:
            return
        if cand[field] == hint[field]:
            score += hit
            reasons.append(label)
        elif cand[field]:
            score -= miss

    compare('group', 34, 26, 'group')
    compare('source', 22, 16, 'source')
    compare('resolution', 18, 14, 'res')
    compare('codec', 10, 8, 'codec')
    compare('audio', 10, 6, 'audio')
    compare('hdr', 10, 8, 'hdr')

    shared = hint['tokens'] & cand['tokens']
    if shared:
        score += min(30, len(shared) * 8)
        reasons.append('%d tokenů' % len(shared))
    return score, reasons


def score_candidate(candidate, request):
    """Assign candidate.match_score / .match_reasons in place.

    Score is capped into 0..100 so it can be shown as a percentage next to
    each row without needing a second scale.
    """
    raw = 0
    reasons = []

    title_signal, title_ok, title_reasons = title_match_score(
        request.title, candidate.title, candidate.release
    )
    # An OpenSubtitles query constrained by IMDb/TMDb already has strong
    # identity even when the returned display title is localized.
    if not title_ok and candidate.provider == 'opensubtitles' and (request.imdb_id or request.tmdb_id):
        title_signal, title_ok, title_reasons = 26, True, ['ID filmu']
    raw += title_signal
    reasons.extend(title_reasons)

    if candidate.hash_match:
        raw += 55
        reasons.append('přesná shoda souboru')

    rel_score, rel_reasons = release_score(
        candidate.release or candidate.title, request.release_hint
    )
    raw += rel_score
    reasons.extend(rel_reasons)

    if request.year and candidate.year:
        if str(candidate.year) == str(request.year):
            raw += 12
            reasons.append('rok')
        else:
            raw -= 30
            reasons.append('jiný rok')

    if candidate.size_mb and request.movie_size:
        actual_mb = request.movie_size / (1024.0 * 1024.0)
        if abs(actual_mb - candidate.size_mb) <= max(1.0, actual_mb * 0.005):
            raw += 10
            reasons.append('velikost')

    if candidate.forced:
        raw -= 45
        reasons.append('forced')
    if candidate.hearing_impaired:
        raw -= 8
        reasons.append('SDH')

    # Popularity is a tie-break only, and is damped hard so it can never
    # outweigh an actual release match.
    if candidate.download_count > 0:
        raw += min(6, candidate.download_count / 2000.0)

    candidate.match_score = int(max(0, min(100, 50 + raw)))
    candidate.match_reasons = reasons
    return candidate


def sort_key(candidate):
    """Ranking inside one usage group."""
    return (
        candidate.match_score,
        1 if candidate.hash_match else 0,
        candidate.download_count,
    )


def rank(candidates, request):
    """Score, drop obvious mismatches, dedupe and sort."""
    scored = []
    for candidate in candidates or []:
        score_candidate(candidate, request)
        _signal, title_ok, _reasons = title_match_score(
            request.title, candidate.title, candidate.release
        )
        if not title_ok and not candidate.hash_match:
            if not (candidate.provider == 'opensubtitles' and (request.imdb_id or request.tmdb_id)):
                continue
        if candidate.match_score < MIN_MATCH_SCORE and not candidate.hash_match:
            continue
        scored.append(candidate)
    scored.sort(key=sort_key, reverse=True)
    deduped = []
    seen = set()
    for candidate in scored:
        key = candidate.dedupe_key()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(candidate)
    return deduped


def drop_forced_when_possible(candidates):
    """Forced tracks only carry foreign-dialogue lines. Keep them out of the
    way when a full subtitle exists in the same language."""
    languages_with_full = set(c.language for c in candidates if not c.forced)
    return [c for c in candidates if not c.forced or c.language not in languages_with_full]


def split_by_usage(candidates):
    """Return (ready_cs, ready_sk, translate_en) preserving rank order."""
    ready_cs, ready_sk, translate = [], [], []
    for candidate in candidates:
        if candidate.language == LANG_EN:
            translate.append(candidate)
        elif candidate.language == 'sk':
            ready_sk.append(candidate)
        else:
            ready_cs.append(candidate)
    return ready_cs, ready_sk, translate
