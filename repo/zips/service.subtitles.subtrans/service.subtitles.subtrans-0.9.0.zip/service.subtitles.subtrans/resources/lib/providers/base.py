# -*- coding: utf-8 -*-
"""Shared provider vocabulary.

Nothing in this package may import xbmc: providers are plain HTTP + parsing
code so they can be exercised from a normal Python interpreter. Everything
Kodi-specific (settings, dialogs, notifications) is injected by service.py
through the ProviderContext.
"""

import re

# Usage classes. These drive the grouping in the Kodi list: a candidate is
# either something we can hand to the player as-is, or something that has to
# go through translation first.
USE_READY = 'ready'          # finished subtitle in the user's language
USE_TRANSLATE = 'translate'  # foreign source, needs the translation backend

# Language buckets we care about. Anything else is dropped at search time.
LANG_CS = 'cs'
LANG_SK = 'sk'
LANG_EN = 'en'

_LANG_ALIASES = {
    'cs': LANG_CS, 'cz': LANG_CS, 'cze': LANG_CS, 'ces': LANG_CS, 'czech': LANG_CS,
    'sk': LANG_SK, 'slo': LANG_SK, 'slk': LANG_SK, 'slovak': LANG_SK,
    'en': LANG_EN, 'eng': LANG_EN, 'english': LANG_EN,
}

LANG_LABELS = {LANG_CS: 'CZ', LANG_SK: 'SK', LANG_EN: 'EN'}


def normalize_language(value):
    """Map whatever a source calls a language onto cs/sk/en, or None."""
    token = str(value or '').strip().lower()
    if not token:
        return None
    return _LANG_ALIASES.get(token)


class ProviderError(Exception):
    """Raised for an expected, reportable provider failure.

    The message is shown to the user, so it must be readable Czech-ish text
    rather than a stack fragment. Unexpected exceptions are caught by the
    orchestrator and reported generically instead.
    """

    def __init__(self, message, provider=''):
        super(ProviderError, self).__init__(message)
        self.provider = provider


class Candidate(object):
    """One offered subtitle, before anything has been downloaded.

    `handle` is the provider-specific payload needed to fetch this subtitle
    later. It must be JSON-serializable and must never contain credentials or
    session cookies, because it is round-tripped through the Kodi plugin URL
    and the short-lived search cache.
    """

    __slots__ = (
        'provider', 'provider_id', 'language', 'release', 'title', 'year',
        'season', 'episode', 'hash_match', 'hearing_impaired', 'forced',
        'fps', 'download_count', 'size_mb', 'author', 'handle',
        'match_score', 'match_reasons',
    )

    def __init__(self, provider, provider_id, language, release='', title='',
                 year=None, season=None, episode=None, hash_match=False,
                 hearing_impaired=False, forced=False, fps=None,
                 download_count=0, size_mb=None, author='', handle=None):
        self.provider = provider
        self.provider_id = str(provider_id)
        self.language = language
        self.release = release or ''
        self.title = title or ''
        self.year = year
        self.season = season
        self.episode = episode
        self.hash_match = bool(hash_match)
        self.hearing_impaired = bool(hearing_impaired)
        self.forced = bool(forced)
        self.fps = fps
        self.download_count = int(download_count or 0)
        self.size_mb = size_mb
        self.author = author or ''
        self.handle = handle or {}
        self.match_score = 0
        self.match_reasons = []

    @property
    def usage(self):
        return USE_TRANSLATE if self.language == LANG_EN else USE_READY

    @property
    def needs_translation(self):
        return self.usage == USE_TRANSLATE

    @property
    def lang_label(self):
        return LANG_LABELS.get(self.language, (self.language or '??').upper())

    def describe(self):
        """Short human label for the second column of the Kodi list."""
        parts = []
        if self.release:
            parts.append(self.release)
        elif self.title:
            parts.append(self.title)
        if self.author:
            parts.append('by %s' % self.author)
        return ' · '.join(parts)

    def dedupe_key(self):
        """Collapse the same language/release even when two providers carry it.

        The highest-ranked source remains visible. The download handle stays
        attached to that winner, so provenance is not lost.
        """
        return (self.language, normalize_release(self.release or self.title))

    def to_dict(self):
        return {slot: getattr(self, slot) for slot in self.__slots__}

    @classmethod
    def from_dict(cls, data):
        """Rebuild a candidate from the search cache.

        Unknown or missing keys are tolerated: a cache written by an older
        version of the addon should degrade into a fresh search, not a crash.
        """
        if not isinstance(data, dict) or not data.get('provider'):
            return None
        candidate = cls(
            provider=data.get('provider'),
            provider_id=data.get('provider_id') or '',
            language=data.get('language'),
            release=data.get('release') or '',
            title=data.get('title') or '',
            year=data.get('year'),
            season=data.get('season'),
            episode=data.get('episode'),
            hash_match=data.get('hash_match'),
            hearing_impaired=data.get('hearing_impaired'),
            forced=data.get('forced'),
            fps=data.get('fps'),
            download_count=data.get('download_count') or 0,
            size_mb=data.get('size_mb'),
            author=data.get('author') or '',
            handle=data.get('handle') or {},
        )
        candidate.match_score = int(data.get('match_score') or 0)
        candidate.match_reasons = list(data.get('match_reasons') or [])
        return candidate

    def __repr__(self):
        return '<Candidate %s/%s %s %r score=%s>' % (
            self.provider, self.provider_id, self.language, self.release, self.match_score
        )


def normalize_release(value):
    """Lowercase, strip separators and collapse whitespace, for comparisons."""
    text = re.sub(r'[^a-z0-9]+', ' ', str(value or '').lower())
    return re.sub(r'\s+', ' ', text).strip()


class ProviderContext(object):
    """Everything a provider needs from its host, injected rather than imported.

    settings   -- callable(key, default) returning a setting value
    log        -- callable(message)
    cache_dir  -- writable directory for session/state files
    ask_text   -- callable(prompt, image_path) -> str or None, used for the
                  titulky.com control image. The user reads the image and types
                  the code; we never attempt to solve it programmatically.
    notify     -- callable(message), transient user-visible message
    """

    def __init__(self, settings, log, cache_dir, ask_text=None, notify=None):
        self.settings = settings
        self.log = log
        self.cache_dir = cache_dir
        self.ask_text = ask_text
        self.notify = notify or (lambda _msg: None)

    def get(self, key, default=None):
        return self.settings(key, default)

    def get_bool(self, key, default=False):
        value = self.settings(key, default)
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ('true', '1', 'yes', 'on')

    def get_int(self, key, default=0):
        try:
            return int(str(self.settings(key, default)).strip())
        except (TypeError, ValueError):
            return default

    def get_str(self, key, default=''):
        return str(self.settings(key, default) or '').strip()


class SearchRequest(object):
    """Normalized description of what the user is watching.

    Built once by service.py from Kodi metadata and handed to every provider,
    so providers never poke at Kodi info labels themselves.
    """

    def __init__(self, title='', year='', imdb_id='', tmdb_id='',
                 release_hint='', movie_hash='', movie_size=0, languages=None,
                 video_path='', media_type='movie', season=None, episode=None):
        self.title = str(title or '').strip()
        self.year = str(year or '').strip()
        self.imdb_id = str(imdb_id or '').strip()
        self.tmdb_id = str(tmdb_id or '').strip()
        self.release_hint = str(release_hint or '').strip()
        self.movie_hash = str(movie_hash or '').strip()
        self.movie_size = int(movie_size or 0)
        self.languages = list(languages or [LANG_CS, LANG_SK, LANG_EN])
        self.video_path = str(video_path or '')
        self.media_type = 'episode' if str(media_type or '').lower() == 'episode' else 'movie'
        self.season = _optional_int(season)
        self.episode = _optional_int(episode)

    @property
    def has_identity(self):
        return bool(self.title or self.imdb_id or self.tmdb_id)

    @property
    def is_episode(self):
        return self.media_type == 'episode' or self.season is not None or self.episode is not None

    def __repr__(self):
        return '<SearchRequest %r type=%s year=%s imdb=%s langs=%s>' % (
            self.title, self.media_type, self.year, self.imdb_id, ','.join(self.languages)
        )


def _optional_int(value):
    try:
        return int(value) if value not in (None, '') else None
    except (TypeError, ValueError):
        return None
