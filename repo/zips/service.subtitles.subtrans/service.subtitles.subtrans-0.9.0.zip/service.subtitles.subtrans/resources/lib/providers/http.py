# -*- coding: utf-8 -*-
"""A minimal per-provider HTTP session.

Deliberately *not* urllib's global opener: installing an opener process-wide
would change HTTP behaviour for every other addon sharing the Python
interpreter inside Kodi. Each provider owns its own cookie jar and opener, and
nothing leaks between them.
"""

import gzip
import io
import http.cookiejar
import urllib.error
import urllib.parse
import urllib.request

DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0 Safari/537.36'
)


class HttpError(Exception):
    def __init__(self, message, status=None, body=''):
        super(HttpError, self).__init__(message)
        self.status = status
        self.body = body


class Session(object):
    def __init__(self, user_agent=DEFAULT_UA, timeout=10):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar)
        )
        self.user_agent = user_agent
        self.timeout = timeout

    def _headers(self, extra=None):
        headers = {
            'User-Agent': self.user_agent,
            'Accept-Language': 'cs,sk;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip',
        }
        if extra:
            headers.update(extra)
        return headers

    def request(self, url, data=None, headers=None, timeout=None, method=None):
        """Perform one request and return (body_bytes, response).

        `data` may be a dict (form-encoded) or raw bytes.
        """
        if isinstance(data, dict):
            data = urllib.parse.urlencode(data).encode('utf-8')
            headers = dict(headers or {})
            headers.setdefault('Content-Type', 'application/x-www-form-urlencoded')

        request = urllib.request.Request(
            url, data=data, headers=self._headers(headers), method=method
        )
        try:
            response = self.opener.open(request, timeout=timeout or self.timeout)
        except urllib.error.HTTPError as exc:
            body = exc.read() or b''
            raise HttpError(
                'HTTP %s pro %s' % (exc.code, _short_url(url)),
                status=exc.code,
                body=body.decode('utf-8', errors='replace')[:400],
            )
        except urllib.error.URLError as exc:
            raise HttpError('Nedostupný server %s: %s' % (_short_url(url), exc.reason))

        raw = response.read()
        if response.headers.get('Content-Encoding') == 'gzip':
            try:
                raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
            except OSError:
                pass
        return raw, response

    def get_bytes(self, url, headers=None, timeout=None):
        raw, _response = self.request(url, headers=headers, timeout=timeout)
        return raw

    def get_text(self, url, headers=None, timeout=None, encoding='utf-8'):
        raw, response = self.request(url, headers=headers, timeout=timeout)
        return _decode(raw, response, encoding)

    def post_text(self, url, data, headers=None, timeout=None, encoding='utf-8'):
        raw, response = self.request(url, data=data, headers=headers, timeout=timeout)
        return _decode(raw, response, encoding)

    def cookie_values(self):
        return {cookie.name: cookie.value for cookie in self.jar}

    def has_cookie(self, name):
        return any(cookie.name == name for cookie in self.jar)

    def load_cookies(self, mapping, domain):
        """Restore a cached session. Only names we put there ourselves."""
        for name, value in (mapping or {}).items():
            self.jar.set_cookie(http.cookiejar.Cookie(
                version=0, name=name, value=value, port=None, port_specified=False,
                domain=domain, domain_specified=True, domain_initial_dot=domain.startswith('.'),
                path='/', path_specified=True, secure=True, expires=None, discard=False,
                comment=None, comment_url=None, rest={}, rfc2109=False,
            ))


def _decode(raw, response, fallback):
    charset = None
    content_type = response.headers.get('Content-Type') or ''
    if 'charset=' in content_type:
        charset = content_type.split('charset=', 1)[1].strip().strip('"; ')
    for encoding in filter(None, (charset, fallback, 'cp1250')):
        try:
            return raw.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode('utf-8', errors='replace')


def _short_url(url):
    parsed = urllib.parse.urlparse(url)
    return parsed.netloc + parsed.path
