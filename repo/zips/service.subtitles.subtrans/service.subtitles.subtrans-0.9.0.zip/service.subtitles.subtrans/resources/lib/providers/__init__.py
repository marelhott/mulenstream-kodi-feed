# -*- coding: utf-8 -*-
"""Subtitle sources for the Subtrans aggregator.

Import nothing from xbmc in this package. Providers are plain HTTP and parsing
code so the whole search path can be exercised from a normal interpreter; the
host injects Kodi behaviour through ProviderContext.
"""

from .base import (
    LANG_CS,
    LANG_EN,
    LANG_SK,
    USE_READY,
    USE_TRANSLATE,
    Candidate,
    ProviderContext,
    ProviderError,
    SearchRequest,
    normalize_language,
)
from .opensubtitles import OpenSubtitlesProvider
from .titulky import TitulkyProvider
from . import archive, matching, orchestrator

__all__ = [
    'LANG_CS', 'LANG_SK', 'LANG_EN', 'USE_READY', 'USE_TRANSLATE',
    'Candidate', 'ProviderContext', 'ProviderError', 'SearchRequest',
    'normalize_language', 'OpenSubtitlesProvider', 'TitulkyProvider',
    'archive', 'matching', 'orchestrator', 'build_providers',
]


def build_providers(context):
    """Every provider, in a stable order. Each decides for itself whether it
    is configured; the orchestrator skips the ones that are not."""
    return [
        OpenSubtitlesProvider(context),
        TitulkyProvider(context),
    ]
