# -*- coding: utf-8 -*-
"""titulky.com provider.

Written from the observed HTTP behaviour of the site, not derived from the
existing community addon (which ships without a license, so its code cannot be
reused). Structure, parsing and error handling here are our own.

Shape of the service, and why the provider is split the way it is:

* Search is anonymous. No login, no cookies, no rate-limited resource is
  touched, so it is safe to run on every subtitle dialog and safe to run in
  parallel with the other providers.
* Everything expensive happens at download time: login, an optional control
  image the *user* reads, and a server-imposed countdown. That is exactly the
  lazy-download split the aggregator is built around.

The site returns a plain HTML table. We parse it into rows and read cells by
position, but unlike a regex over the whole document a parse failure here is
localized: one malformed row is skipped and the rest still work.
"""

import html
import html.parser
import json
import os
import re
import time

from . import archive
from .base import Candidate, ProviderError, normalize_language
from .http import HttpError, Session
from .matching import looks_episodic, looks_forced, looks_sdh

PROVIDER = 'titulky'
BASE_URL = 'https://www.titulky.com'
SESSION_FILE = 'titulky_session.json'
SESSION_TTL_SEC = 6 * 60 * 60

# Column order of the search results table.
COL_TITLE = 0
COL_VERSION = 1
COL_EPISODE = 2
COL_YEAR = 3
COL_DOWNLOADS = 4
COL_LANGUAGE = 5
COL_DISCS = 6
COL_SIZE = 7
COL_AUTHOR = 8

_ID_RE = re.compile(r'-(\d+)\.htm', re.IGNORECASE)
_NUM_RE = re.compile(r'\d+(?:[.,]\d+)?')
_COUNTDOWN_RE = re.compile(r'CountDown\s*\(\s*(\d+)\s*\)', re.IGNORECASE)
_DOWNLINK_RE = re.compile(
    r'<a[^>]+id=["\']downlink["\'][^>]+href=["\']([^"\']+)["\']', re.IGNORECASE
)
_CAPTCHA_RE = re.compile(r'["\'.]{0,2}(/?captcha/captcha\.php[^"\']*)', re.IGNORECASE)
_BAD_LOGIN_RE = re.compile(r'BadLogin', re.IGNORECASE)
_VIP_RE = re.compile(r'id=["\']userNickName["\'][^>]*title=["\']\s*TOP', re.IGNORECASE)


class _ResultTableParser(html.parser.HTMLParser):
    """Collect the search result rows.

    Result rows carry a class starting with "r" (alternating row striping).
    For each we keep the cell texts plus the first link, which is where the
    subtitle id lives.
    """

    def __init__(self):
        html.parser.HTMLParser.__init__(self, convert_charrefs=True)
        self.rows = []
        self._row = None
        self._cell = None
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if tag == 'tr':
            css = (attributes.get('class') or '').strip().lower()
            if css.startswith('r'):
                self._row = {'cells': [], 'href': '', 'titles': []}
            return
        if self._row is None:
            return
        if tag == 'td':
            self._cell = []
            self._depth = 0
        elif tag == 'a':
            href = attributes.get('href') or ''
            if href and not self._row['href']:
                self._row['href'] = href
            # The release string lives in a link tooltip rather than in the
            # cell text, so keep every title attribute we pass.
            title = (attributes.get('title') or '').strip()
            if title:
                self._row['titles'].append(title)
        elif tag == 'img':
            # Language is encoded as the alt text of a flag image.
            alt = (attributes.get('alt') or '').strip()
            if alt and self._cell is not None:
                self._cell.append(alt)

    def handle_endtag(self, tag):
        if tag == 'td' and self._row is not None and self._cell is not None:
            text = ' '.join(' '.join(self._cell).split())
            self._row['cells'].append(text)
            self._cell = None
        elif tag == 'tr' and self._row is not None:
            if self._row['cells']:
                self.rows.append(self._row)
            self._row = None
            self._cell = None

    def handle_data(self, data):
        if self._cell is not None:
            chunk = data.strip()
            if chunk:
                self._cell.append(chunk)


def _cell(row, index):
    cells = row.get('cells') or []
    if index < len(cells):
        value = cells[index].strip()
        return '' if value in ('\xa0', '&nbsp;', '-') else value
    return ''


def _to_int(value):
    match = _NUM_RE.search(str(value or ''))
    if not match:
        return 0
    try:
        return int(float(match.group(0).replace(',', '.')))
    except ValueError:
        return 0


def _to_float(value):
    match = _NUM_RE.search(str(value or ''))
    if not match:
        return None
    try:
        return float(match.group(0).replace(',', '.'))
    except ValueError:
        return None


def parse_results(document):
    """Parse a search results page into raw row dicts.

    Kept separate from the network layer so it can be tested against saved
    HTML without touching titulky.com.
    """
    parser = _ResultTableParser()
    try:
        parser.feed(document)
        parser.close()
    except Exception:
        # A half-parsed page still yields the rows seen so far, which is
        # better than losing the whole search to one malformed tag.
        pass

    results = []
    for row in parser.rows:
        href = row.get('href') or ''
        match = _ID_RE.search(href)
        if not match:
            continue
        release = ''
        for title in row.get('titles') or []:
            if len(title) > len(release):
                release = title
        results.append({
            'id': match.group(1),
            'link': href.rsplit('.htm', 1)[0].lstrip('/'),
            'title': html.unescape(_cell(row, COL_TITLE)),
            'release': html.unescape(release or _cell(row, COL_VERSION)),
            'episode': _cell(row, COL_EPISODE),
            'year': _cell(row, COL_YEAR),
            'downloads': _to_int(_cell(row, COL_DOWNLOADS)),
            'language': _cell(row, COL_LANGUAGE),
            'discs': _to_int(_cell(row, COL_DISCS)) or 1,
            'size_mb': _to_float(_cell(row, COL_SIZE)),
            'author': html.unescape(_cell(row, COL_AUTHOR)),
        })
    return results


def build_candidates(rows, request):
    """Turn parsed rows into candidates and enforce movie/episode identity."""
    candidates = []
    for row in rows:
        language = normalize_language(row.get('language'))
        if language is None:
            continue
        episodic = bool(row.get('episode') or looks_episodic(row.get('title'), row.get('release')))
        if request.is_episode:
            desired = ('s%02de%02d' % (request.season or 0, request.episode or 0)).lower()
            alternate = ('%dx%02d' % (request.season or 0, request.episode or 0)).lower()
            haystack = ('%s %s %s' % (row.get('episode') or '', row.get('title') or '',
                                      row.get('release') or '')).lower().replace(' ', '')
            if not episodic or (desired not in haystack and alternate not in haystack):
                continue
        elif episodic:
            continue

        year = row.get('year') or None
        release = row.get('release') or row.get('title') or ''
        candidates.append(Candidate(
            provider=PROVIDER,
            provider_id=row['id'],
            language=language,
            release=release,
            title=row.get('title') or '',
            year=year,
            season=request.season if request.is_episode else None,
            episode=request.episode if request.is_episode else None,
            hash_match=False,
            hearing_impaired=looks_sdh(release),
            forced=looks_forced(release),
            download_count=row.get('downloads') or 0,
            size_mb=row.get('size_mb'),
            author=row.get('author') or '',
            handle={
                'provider': PROVIDER,
                'id': row['id'],
                'link': row.get('link') or '',
                'discs': row.get('discs') or 1,
            },
        ))
    return candidates


class TitulkyProvider(object):
    name = PROVIDER
    label = 'Titulky.com'

    def __init__(self, context):
        self.context = context
        self.session = Session(timeout=self._timeout())
        self._last_payload = None

    # -- configuration -----------------------------------------------------

    def _timeout(self):
        return max(3, min(30, self.context.get_int('titulky_timeout_sec', 8)))

    def enabled(self):
        return self.context.get_bool('titulky_enabled', False)

    def _credentials(self):
        return (
            self.context.get_str('titulky_username'),
            self.context.get_str('titulky_password'),
        )

    # -- search ------------------------------------------------------------

    def search(self, request):
        """Anonymous fulltext search. Never logs in, never downloads."""
        if not self.enabled():
            return []
        query = (request.title or '').strip()
        if not query:
            return []

        rows = self._search_rows(query)
        if not rows and request.video_path:
            # The site indexes release names as well as titles, so a filename
            # is a reasonable second attempt when the clean title finds nothing.
            filename = os.path.splitext(os.path.basename(request.video_path))[0]
            if filename and filename.lower() != query.lower():
                self.context.log('titulky: retrying search with filename %r' % filename)
                rows = self._search_rows(filename)

        candidates = build_candidates(rows, request)
        self.context.log('titulky: %d rows -> %d candidates' % (len(rows), len(candidates)))
        return candidates

    def _search_rows(self, query):
        url = '%s/index.php?%s' % (BASE_URL, _urlencode({'Fulltext': query}))
        try:
            document = self.session.get_text(url, encoding='cp1250', timeout=self._timeout())
        except HttpError as exc:
            raise ProviderError('Titulky.com nedostupné: %s' % exc, provider=PROVIDER)
        rows = parse_results(document)
        if not rows and 'Fulltext' not in document and len(document) < 2000:
            raise ProviderError(
                'Titulky.com vrátily neznámou odpověď (možná ochrana proti robotům)',
                provider=PROVIDER,
            )
        return rows

    # -- session -----------------------------------------------------------

    def _session_path(self):
        return os.path.join(self.context.cache_dir, SESSION_FILE)

    def _load_session(self):
        try:
            with open(self._session_path(), 'r', encoding='utf-8') as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return False
        username, _password = self._credentials()
        if data.get('username') != username:
            return False
        if float(data.get('created_at') or 0) + SESSION_TTL_SEC < time.time():
            return False
        cookies = data.get('cookies') or {}
        if not cookies:
            return False
        self.session.load_cookies(cookies, '.titulky.com')
        self.context.log('titulky: reusing cached session')
        return True

    def _store_session(self):
        username, _password = self._credentials()
        payload = {
            'username': username,
            'created_at': time.time(),
            'cookies': self.session.cookie_values(),
        }
        try:
            with open(self._session_path(), 'w', encoding='utf-8') as handle:
                json.dump(payload, handle)
        except OSError as exc:
            self.context.log('titulky: could not cache session: %s' % exc)

    def _clear_session(self):
        try:
            os.remove(self._session_path())
        except OSError:
            pass

    def login(self, force=False):
        username, password = self._credentials()
        if not username or not password:
            raise ProviderError(
                'Pro stahování z Titulky.com vyplň jméno a heslo v nastavení',
                provider=PROVIDER,
            )
        if not force and self._load_session():
            return True

        try:
            document = self.session.post_text(
                BASE_URL + '/index.php',
                data={
                    'Login': username,
                    'Password': password,
                    'foreverlog': '1',
                    'Detail2': '',
                },
                headers={'Origin': BASE_URL, 'Referer': BASE_URL + '/'},
                encoding='cp1250',
                timeout=max(self._timeout(), 15),
            )
        except HttpError as exc:
            raise ProviderError('Přihlášení k Titulky.com selhalo: %s' % exc, provider=PROVIDER)

        if _BAD_LOGIN_RE.search(document):
            self._clear_session()
            raise ProviderError('Titulky.com odmítly jméno nebo heslo', provider=PROVIDER)

        self._store_session()
        self.context.log('titulky: logged in as %s' % username)
        return True

    def is_vip(self):
        """Best-effort premium check. Only used to warn, never to gate."""
        try:
            document = self.session.get_text(
                BASE_URL + '/?Registration=Edit', encoding='cp1250', timeout=self._timeout()
            )
        except HttpError:
            return None
        return bool(_VIP_RE.search(document))

    # -- download ----------------------------------------------------------

    def fetch(self, handle, release_hint='', member=None):
        """Download one subtitle and return (text, chosen_member, members).

        Runs the full interactive sequence: login, request the download page,
        let the user answer a control image if the site asks for one, wait out
        the countdown, then pull the archive.
        """
        subtitle_id = str(handle.get('id') or '').strip()
        if not subtitle_id:
            raise ProviderError('Chybí ID titulků', provider=PROVIDER)

        if self._last_payload and self._last_payload[0] == subtitle_id:
            raw = self._last_payload[1]
        else:
            self.login()
            referer = '%s/%s.htm' % (BASE_URL, handle.get('link') or '')
            document = self._open_download_page(subtitle_id, referer=referer)

            captcha_url = self._captcha_url(document)
            if captcha_url:
                document = self._resolve_captcha(subtitle_id, captcha_url, document)

            wait = self._countdown(document)
            link = self._final_link(document)
            if not link:
                if 'Registration' in document or 'Login' in document:
                    self._clear_session()
                    raise ProviderError(
                        'Titulky.com vyžadují nové přihlášení, zkus to prosím znovu',
                        provider=PROVIDER,
                    )
                raise ProviderError(
                    'Titulky.com nevrátily odkaz ke stažení (možná změna stránky)',
                    provider=PROVIDER,
                )

            if wait:
                self.context.log('titulky: waiting %ds before download' % wait)
                self._wait(wait)

            try:
                raw = self.session.get_bytes(
                    link,
                    headers={'Referer': BASE_URL + '/idown.php'},
                    timeout=max(self._timeout(), 30),
                )
            except HttpError as exc:
                raise ProviderError('Stažení z Titulky.com selhalo: %s' % exc, provider=PROVIDER)
            self._last_payload = (subtitle_id, raw)

        try:
            text, chosen, members = archive.extract(raw, release_hint=release_hint, member=member)
        except archive.ArchiveError as exc:
            raise ProviderError(str(exc), provider=PROVIDER)
        return archive.normalize_newlines(text), chosen, members

    def _open_download_page(self, subtitle_id, referer=None):
        params = {
            'R': str(int(time.time())),
            'titulky': subtitle_id,
            'histstamp': '',
            'zip': 'z',
        }
        url = '%s/idown.php?%s' % (BASE_URL, _urlencode(params))
        try:
            return self.session.get_text(
                url,
                headers={'Referer': referer} if referer else None,
                encoding='cp1250',
                timeout=max(self._timeout(), 20),
            )
        except HttpError as exc:
            raise ProviderError('Titulky.com: %s' % exc, provider=PROVIDER)

    def _submit_control_code(self, subtitle_id, code):
        try:
            return self.session.post_text(
                BASE_URL + '/idown.php',
                data={
                    'downkod': code,
                    'titulky': subtitle_id,
                    'zip': 'z',
                    'securedown': '2',
                    'histstamp': '',
                },
                headers={'Referer': BASE_URL + '/idown.php'},
                encoding='cp1250',
                timeout=max(self._timeout(), 20),
            )
        except HttpError as exc:
            raise ProviderError('Titulky.com: %s' % exc, provider=PROVIDER)

    def _resolve_captcha(self, subtitle_id, captcha_url, document):
        """Show the control image and let the user read it.

        We deliberately do not try to solve it: the image is rendered for a
        human, the human answers, and we pass the answer through. If the host
        gave us no way to ask, we fail with an explanation instead.
        """
        if not self.context.ask_text:
            raise ProviderError(
                'Titulky.com vyžadují opsání kontrolního kódu, ale dialog není dostupný',
                provider=PROVIDER,
            )
        try:
            image = self.session.get_bytes(captcha_url, timeout=self._timeout())
        except HttpError as exc:
            raise ProviderError('Nepodařilo se načíst kontrolní obrázek: %s' % exc, provider=PROVIDER)

        image_path = os.path.join(self.context.cache_dir, 'titulky_control_%d.png' % int(time.time()))
        try:
            with open(image_path, 'wb') as handle:
                handle.write(image)
        except OSError as exc:
            raise ProviderError('Nelze uložit kontrolní obrázek: %s' % exc, provider=PROVIDER)

        try:
            code = self.context.ask_text('Opiš kontrolní kód z obrázku', image_path)
        finally:
            try:
                os.remove(image_path)
            except OSError:
                pass

        if not code:
            raise ProviderError('Stahování zrušeno (nezadán kontrolní kód)', provider=PROVIDER)

        document = self._submit_control_code(subtitle_id, code.strip())
        if self._captcha_url(document):
            raise ProviderError('Kontrolní kód nebyl přijat', provider=PROVIDER)
        return document

    def _wait(self, seconds):
        deadline = time.time() + seconds
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                return
            self.context.notify('Titulky.com: %d s' % int(remaining + 0.5))
            time.sleep(min(1.0, remaining))

    @staticmethod
    def _captcha_url(document):
        match = _CAPTCHA_RE.search(document or '')
        if not match:
            return None
        path = match.group(1).lstrip('./')
        return '%s/%s' % (BASE_URL, path.lstrip('/'))

    @staticmethod
    def _countdown(document):
        match = _COUNTDOWN_RE.search(document or '')
        if not match:
            return 0
        # Cap it: a broken page should not park the dialog for minutes.
        return max(0, min(120, int(match.group(1))))

    @staticmethod
    def _final_link(document):
        match = _DOWNLINK_RE.search(document or '')
        if not match:
            return ''
        href = html.unescape(match.group(1))
        if href.startswith('http'):
            return href
        return '%s/%s' % (BASE_URL, href.lstrip('/'))


def _urlencode(mapping):
    import urllib.parse
    return urllib.parse.urlencode(mapping)
