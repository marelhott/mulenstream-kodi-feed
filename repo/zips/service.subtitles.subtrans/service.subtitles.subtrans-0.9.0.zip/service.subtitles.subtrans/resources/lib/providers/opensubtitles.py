# -*- coding: utf-8 -*-
"""OpenSubtitles.com provider, running inside the addon.

Previously this lived on the Subtrans backend, which meant three things we no
longer want: the backend saw every subtitle search (i.e. what the user was
watching), everyone shared one account's quota, and the only download path
also translated -- so a finished Czech subtitle would have been sent through
the translator for no reason.

Here the addon talks to OpenSubtitles directly with the user's own API key and
account, searches cs+sk+en in one request, and offers two distinct fetches:

    fetch()            -> subtitle text, used as-is  (cs, sk)
    fetch() + backend  -> subtitle text, translated  (en)

The backend is now only ever asked to translate.
"""

import json
import os
import time

from . import archive
from .base import (
    LANG_CS, LANG_EN, LANG_SK, Candidate, ProviderError, normalize_language,
)
from .http import HttpError, Session
from .matching import looks_episodic, looks_forced

PROVIDER = 'opensubtitles'
DEFAULT_HOST = 'api.opensubtitles.com'
SESSION_FILE = 'opensubtitles_session.json'
TOKEN_TTL_SEC = 11 * 60 * 60


class OpenSubtitlesProvider(object):
    name = PROVIDER
    label = 'OpenSubtitles'

    def __init__(self, context):
        self.context = context
        self.session = Session(user_agent=self._user_agent(), timeout=self._timeout())
        self._token = None
        self._host = DEFAULT_HOST
        self._last_payload = None

    # -- configuration -----------------------------------------------------

    def enabled(self):
        return self.context.get_bool('osdb_enabled', True) and bool(self._api_key())

    def _api_key(self):
        return self.context.get_str('osdb_api_key')

    def _credentials(self):
        return (
            self.context.get_str('osdb_username'),
            self.context.get_str('osdb_password'),
        )

    def _timeout(self):
        return max(3, min(30, self.context.get_int('osdb_timeout_sec', 8)))

    def _user_agent(self):
        return self.context.get_str('osdb_user_agent') or 'SubtransKodi/1.0'

    def _limit(self):
        return max(5, min(60, self.context.get_int('osdb_search_limit', 20)))

    # -- transport ---------------------------------------------------------

    def _url(self, path, host=None):
        base = 'https://%s/api/v1' % (host or self._host)
        return base + (path if path.startswith('/') else '/' + path)

    def _call(self, path, method='GET', params=None, body=None, authorized=False,
              raw=False, timeout=None):
        api_key = self._api_key()
        if not api_key:
            raise ProviderError('Chybí OpenSubtitles API klíč v nastavení', provider=PROVIDER)

        url = path if path.startswith('http') else self._url(path)
        if params:
            import urllib.parse
            query = urllib.parse.urlencode(
                [(k, v) for k, v in sorted(params.items()) if v not in (None, '')],
                doseq=True,
            )
            if query:
                url += ('&' if '?' in url else '?') + query

        headers = {
            'Api-Key': api_key,
            'Accept': '*/*' if raw else 'application/json',
        }
        data = None
        if body is not None:
            data = json.dumps(body).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        if authorized:
            headers['Authorization'] = 'Bearer ' + self._ensure_token()

        try:
            payload, _response = self.session.request(
                url, data=data, headers=headers, method=method,
                timeout=timeout or self._timeout(),
            )
        except HttpError as exc:
            if exc.status == 401 and authorized:
                raise _Unauthorized(str(exc))
            if exc.status == 406:
                raise ProviderError(
                    'OpenSubtitles: vyčerpán denní limit stahování', provider=PROVIDER
                )
            raise ProviderError('OpenSubtitles: %s' % exc, provider=PROVIDER)

        if raw:
            return payload
        if not payload:
            return {}
        try:
            return json.loads(payload.decode('utf-8'))
        except ValueError as exc:
            raise ProviderError('OpenSubtitles vrátily neplatnou odpověď: %s' % exc,
                                provider=PROVIDER)

    def _call_authorized(self, path, **kwargs):
        """Authorized call that retries once against a refreshed token."""
        kwargs['authorized'] = True
        try:
            return self._call(path, **kwargs)
        except _Unauthorized:
            self.context.log('opensubtitles: token rejected, logging in again')
            self._token = None
            self._clear_session()
            try:
                return self._call(path, **kwargs)
            except _Unauthorized as exc:
                raise ProviderError('OpenSubtitles odmítly přihlášení: %s' % exc,
                                    provider=PROVIDER)

    # -- authentication ----------------------------------------------------

    def _session_path(self):
        return os.path.join(self.context.cache_dir, SESSION_FILE)

    def _load_session(self):
        try:
            with open(self._session_path(), 'r', encoding='utf-8') as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return None
        username, _password = self._credentials()
        if data.get('username') != username:
            return None
        if float(data.get('expires_at') or 0) <= time.time():
            return None
        self._host = data.get('host') or DEFAULT_HOST
        return data.get('token')

    def _store_session(self, token, host):
        username, _password = self._credentials()
        try:
            with open(self._session_path(), 'w', encoding='utf-8') as handle:
                json.dump({
                    'username': username,
                    'token': token,
                    'host': host or DEFAULT_HOST,
                    'expires_at': time.time() + TOKEN_TTL_SEC,
                }, handle)
        except OSError as exc:
            self.context.log('opensubtitles: could not cache token: %s' % exc)

    def _clear_session(self):
        try:
            os.remove(self._session_path())
        except OSError:
            pass

    def _ensure_token(self):
        if self._token:
            return self._token
        cached = self._load_session()
        if cached:
            self._token = cached
            return cached

        username, password = self._credentials()
        if not username or not password:
            raise ProviderError(
                'Pro stahování z OpenSubtitles vyplň jméno a heslo v nastavení',
                provider=PROVIDER,
            )
        result = self._call(
            '/login', method='POST', body={'username': username, 'password': password}
        ) or {}
        token = result.get('token')
        if not token:
            raise ProviderError('OpenSubtitles nevrátily přihlašovací token', provider=PROVIDER)
        host = (result.get('base_url') or DEFAULT_HOST).replace('https://', '').strip('/')
        self._host = host
        self._token = token
        self._store_session(token, host)
        return token

    # -- search ------------------------------------------------------------

    def search(self, request):
        """One request covering every language we can use.

        Searching cs, sk and en together (rather than en only, as the backend
        path did) is what lets finished Czech subtitles skip translation
        entirely.
        """
        if not self.enabled():
            return []
        if not request.has_identity:
            return []
        wanted = list(request.languages or [LANG_CS, LANG_SK, LANG_EN])
        groups = []
        native = [lang for lang in wanted if lang in (LANG_CS, LANG_SK)]
        if native:
            groups.append(native)
        if LANG_EN in wanted:
            groups.append([LANG_EN])

        candidates = []
        group_timeout = max(3, int(self._timeout() / max(1, len(groups))))
        for languages in groups:
            candidates.extend(self._search_languages(request, languages, group_timeout))
        self.context.log('opensubtitles: %d candidates (%s)' % (
            len(candidates), ','.join(wanted)
        ))
        return candidates

    def _search_languages(self, request, languages, timeout):
        params = {
            'languages': ','.join(languages),
            'order_by': 'download_count',
            'order_direction': 'desc',
            'page': 1,
            'per_page': self._limit(),
            'type': 'episode' if request.is_episode else 'movie',
        }
        if request.is_episode:
            if request.season is not None:
                params['season_number'] = request.season
            if request.episode is not None:
                params['episode_number'] = request.episode
        imdb = request.imdb_id.lower()
        imdb_digits = imdb[2:] if imdb.startswith('tt') else imdb
        if imdb_digits.isdigit():
            params['imdb_id'] = imdb_digits
        else:
            if request.title:
                params['query'] = request.title
            if request.tmdb_id.isdigit():
                params['tmdb_id'] = request.tmdb_id
            if request.year.isdigit():
                params['year'] = request.year
        if request.movie_hash and request.movie_size:
            params['moviehash'] = request.movie_hash
            params['moviebytesize'] = str(request.movie_size)

        data = self._call('/subtitles', params=params, timeout=timeout) or {}
        rows = data.get('data') or []
        candidates = []
        for row in rows:
            candidate = self._to_candidate(row, request)
            if candidate is not None:
                candidates.append(candidate)
        self.context.log('opensubtitles: %d rows -> %d candidates (%s)' % (
            len(rows), len(candidates), ','.join(languages)
        ))
        return candidates

    def _to_candidate(self, row, request):
        if not isinstance(row, dict):
            return None
        attributes = row.get('attributes') or {}
        language = normalize_language(attributes.get('language'))
        if language is None:
            return None

        file_id, file_name = _first_file(attributes)
        if not file_id:
            return None

        feature = attributes.get('feature_details') or {}
        release = str(attributes.get('release') or file_name or feature.get('title') or '')
        feature_season = feature.get('season_number')
        feature_episode = feature.get('episode_number')
        if request.is_episode:
            if request.season is not None and feature_season not in (None, request.season, str(request.season)):
                return None
            if request.episode is not None and feature_episode not in (None, request.episode, str(request.episode)):
                return None
        elif looks_episodic(release, feature.get('title')) or feature_season or feature_episode:
            return None

        return Candidate(
            provider=PROVIDER,
            provider_id=str(file_id),
            language=language,
            release=release,
            title=str(feature.get('title') or ''),
            year=str(feature.get('year') or '') or None,
            season=feature_season,
            episode=feature_episode,
            hash_match=bool(attributes.get('moviehash_match')),
            hearing_impaired=bool(attributes.get('hearing_impaired')),
            forced=bool(attributes.get('foreign_parts_only')) or looks_forced(release),
            fps=attributes.get('fps'),
            download_count=attributes.get('download_count') or 0,
            handle={
                'provider': PROVIDER,
                'file_id': int(file_id),
                'file_name': file_name or ('opensubtitles_%s.srt' % file_id),
            },
        )

    # -- download ----------------------------------------------------------

    def fetch(self, handle, release_hint='', member=None):
        """Download one subtitle and return (text, chosen_member, members)."""
        try:
            file_id = int(handle.get('file_id'))
        except (TypeError, ValueError):
            raise ProviderError('Neplatné OpenSubtitles file_id', provider=PROVIDER)

        if self._last_payload and self._last_payload[0] == file_id:
            raw = self._last_payload[1]
        else:
            result = self._call_authorized(
                '/download', method='POST', body={'file_id': file_id, 'sub_format': 'srt'}
            ) or {}
            link = result.get('link') or result.get('download_url')
            if not link:
                remaining = result.get('remaining')
                if remaining == 0:
                    raise ProviderError(
                        'OpenSubtitles: vyčerpán denní limit stahování', provider=PROVIDER
                    )
                raise ProviderError('OpenSubtitles nevrátily odkaz ke stažení', provider=PROVIDER)

            if result.get('remaining') is not None:
                self.context.log('opensubtitles: %s downloads left today' % result.get('remaining'))

            raw = self._call(link, raw=True, timeout=max(self._timeout(), 30))
            self._last_payload = (file_id, raw)
        try:
            text, chosen, members = archive.extract(raw, release_hint=release_hint, member=member)
        except archive.ArchiveError as exc:
            raise ProviderError(str(exc), provider=PROVIDER)
        return archive.normalize_newlines(text), chosen, members


class _Unauthorized(Exception):
    """Internal: a 401 that should trigger one re-login attempt."""


def _first_file(attributes):
    for entry in (attributes or {}).get('files') or []:
        if not isinstance(entry, dict):
            continue
        file_id = entry.get('file_id') or entry.get('id')
        if file_id:
            return file_id, str(entry.get('file_name') or '')
    return None, ''
