# -*- coding: utf-8 -*-
"""Runs every provider at once and merges what comes back.

Two rules shape this module:

* A slow or broken source must never hold up the others. Providers run in
  parallel behind a per-provider deadline; whatever has not answered in time is
  dropped from this search, reported in the log, and the list is built from the
  rest. titulky.com is HTML scraping and will break some day -- when it does,
  OpenSubtitles and translation have to keep working.
* Nothing is downloaded during search. Providers return metadata only, so the
  cost of offering a result is one HTTP request regardless of how many results
  there are, and daily download quotas are only spent on an actual click.
"""

import hashlib
import json
import os
import time

from .base import LANG_CS, LANG_EN, LANG_SK, Candidate, ProviderError
from .matching import drop_forced_when_possible, rank, split_by_usage

CACHE_FILE = 'search_cache.json'
CACHE_TTL_SEC = 10 * 60
CACHE_MAX_ENTRIES = 24


class ProviderOutcome(object):
    """What one provider did during a search, for logging and for telling the
    user which source is currently unavailable."""

    def __init__(self, name, label):
        self.name = name
        self.label = label
        self.candidates = []
        self.error = ''
        self.elapsed = 0.0

    @property
    def ok(self):
        return not self.error


class SearchResult(object):
    def __init__(self):
        self.ready_cs = []
        self.ready_sk = []
        self.translate = []
        self.outcomes = []
        self.from_cache = False

    @property
    def all_candidates(self):
        return list(self.ready_cs) + list(self.ready_sk) + list(self.translate)

    @property
    def total(self):
        return len(self.ready_cs) + len(self.ready_sk) + len(self.translate)

    @property
    def failed_providers(self):
        return [o for o in self.outcomes if not o.ok]

    def find(self, provider, provider_id):
        for candidate in self.all_candidates:
            if candidate.provider == provider and candidate.provider_id == str(provider_id):
                return candidate
        return None


def search(providers, request, context, total_timeout=12.0, per_provider_timeout=8.0):
    """Query every enabled provider concurrently and return a SearchResult."""
    import threading

    outcomes = []
    active = []
    for provider in providers:
        try:
            if not provider.enabled():
                continue
        except Exception as exc:
            context.log('%s: enabled() failed: %s' % (provider.name, exc))
            continue
        active.append(provider)

    if not active:
        return SearchResult()

    threads = []
    for provider in active:
        outcome = ProviderOutcome(provider.name, getattr(provider, 'label', provider.name))
        outcomes.append(outcome)
        thread = threading.Thread(
            target=_run_provider, args=(provider, request, outcome, context), daemon=True
        )
        thread.start()
        threads.append((thread, outcome))

    deadline = time.time() + total_timeout
    for thread, outcome in threads:
        remaining = min(per_provider_timeout, max(0.0, deadline - time.time()))
        thread.join(remaining)
        if thread.is_alive():
            # The thread is daemonized and will finish into the void. We just
            # stop waiting for it -- a stuck source cannot stall the dialog.
            outcome.error = 'nestihl odpovědět (%.0f s)' % per_provider_timeout
            context.log('%s: timed out after %.1fs' % (outcome.name, per_provider_timeout))

    collected = []
    for outcome in outcomes:
        if outcome.ok:
            collected.extend(outcome.candidates)

    return _assemble(collected, request, outcomes)


def _run_provider(provider, request, outcome, context):
    started = time.time()
    try:
        outcome.candidates = provider.search(request) or []
    except ProviderError as exc:
        outcome.error = str(exc)
        context.log('%s: %s' % (provider.name, exc))
    except Exception as exc:  # noqa: BLE001 - a provider must not crash the dialog
        outcome.error = 'neočekávaná chyba: %s' % exc
        context.log('%s: unexpected failure: %r' % (provider.name, exc))
    finally:
        outcome.elapsed = time.time() - started


def _assemble(candidates, request, outcomes):
    result = SearchResult()
    result.outcomes = outcomes
    if not candidates:
        return result

    ranked = rank(candidates, request)
    ranked = drop_forced_when_possible(ranked)
    ready_cs, ready_sk, translate = split_by_usage(ranked)

    wanted = set(request.languages or [LANG_CS, LANG_SK, LANG_EN])
    result.ready_cs = ready_cs if LANG_CS in wanted else []
    result.ready_sk = ready_sk if LANG_SK in wanted else []
    result.translate = translate if LANG_EN in wanted else []
    return result


# -- cache -----------------------------------------------------------------
#
# Reopening the subtitle dialog for the same video should not re-query every
# source. Only search metadata is cached -- never cookies, tokens or
# credentials, since the cache is a plain file in the addon profile.

def cache_key(request):
    parts = '|'.join([
        request.title, request.year, request.imdb_id, request.tmdb_id,
        request.movie_hash, str(request.movie_size), ','.join(sorted(request.languages)),
        request.media_type, str(request.season or ''), str(request.episode or ''),
    ])
    return hashlib.sha1(parts.encode('utf-8')).hexdigest()[:16]


def from_cached(rows, request):
    """Rebuild a SearchResult from cached rows, or None if nothing usable."""
    candidates = [c for c in (Candidate.from_dict(row) for row in rows or []) if c]
    if not candidates:
        return None
    result = _assemble(candidates, request, [])
    result.from_cache = True
    return result


def load_cached(context, key):
    path = os.path.join(context.cache_dir, CACHE_FILE)
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            store = json.load(handle)
    except (OSError, ValueError):
        return None
    entry = (store or {}).get(key)
    if not entry:
        return None
    if float(entry.get('stored_at') or 0) + CACHE_TTL_SEC < time.time():
        return None
    return entry.get('candidates') or []


def store_cached(context, key, candidates):
    path = os.path.join(context.cache_dir, CACHE_FILE)
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            store = json.load(handle)
        if not isinstance(store, dict):
            store = {}
    except (OSError, ValueError):
        store = {}

    store[key] = {
        'stored_at': time.time(),
        'candidates': [_serialize(c) for c in candidates],
    }
    if len(store) > CACHE_MAX_ENTRIES:
        oldest = sorted(store.items(), key=lambda kv: kv[1].get('stored_at') or 0)
        for stale_key, _value in oldest[:len(store) - CACHE_MAX_ENTRIES]:
            store.pop(stale_key, None)

    try:
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(store, handle)
        os.replace(tmp, path)
    except OSError as exc:
        context.log('search cache write failed: %s' % exc)


def _serialize(candidate):
    data = candidate.to_dict()
    data['match_reasons'] = list(candidate.match_reasons)
    return data
