# -*- coding: utf-8 -*-
"""Turning whatever a source hands us into one UTF-8 subtitle.

Two problems the old single-source path never had to solve:

* Czech archives routinely hold several files -- multiple discs, several
  release variants, or the same subtitle as both .srt and .sub. Handing Kodi
  the alphabetically first one is a coin flip, so we rank the members against
  the release that is actually playing.
* Older Czech subtitles are CP1250, not UTF-8. Kodi renders those as mojibake,
  so decoding is not optional.
"""

import gzip
import io
import os
import re
import zipfile

from .matching import release_score

TEXT_EXTENSIONS = ('.srt', '.sub', '.ssa', '.ass', '.vtt', '.txt')
PREFERRED_EXTENSIONS = ('.srt', '.vtt', '.ass', '.ssa')

# Tried in order. cp1250 covers the Czech/Slovak legacy case; latin-2 is the
# same alphabet with a different byte layout and shows up occasionally.
_ENCODINGS = ('utf-8-sig', 'utf-8', 'cp1250', 'iso-8859-2', 'cp1252')

# C1 controls and the replacement character. A single-byte codec will happily
# decode almost any byte sequence, so these are the tell that we guessed the
# wrong codepage: real subtitle text never contains them, while CP1250 bytes
# read as latin-2 produce them immediately. Note we cannot discriminate on
# letters -- š, ž and ť are ordinary Czech, not damage.
_UNDECODABLE = re.compile('[\u0080-\u009f\ufffd]')

_DISC_RE = re.compile(r'\b(?:cd|disc|disk|part|dvd)\s*([1-9])\b', re.IGNORECASE)


class ArchiveError(Exception):
    pass


def is_zip(raw):
    return bool(raw) and raw[:2] == b'PK'


def is_gzip(raw):
    return bool(raw) and raw[:2] == b'\x1f\x8b'


def decode_text(raw):
    """Decode subtitle bytes to str, guessing the codepage.

    Returns (text, encoding_name). Never raises: the last resort is a lossy
    CP1250 decode, because a subtitle with a few wrong glyphs still beats no
    subtitle at all.
    """
    if isinstance(raw, str):
        return raw, 'str'
    for encoding in _ENCODINGS:
        try:
            text = raw.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
        # utf-8 is self-validating, so a clean decode is conclusive.
        if encoding.startswith('utf-8'):
            return text, encoding
        # The single-byte codecs decode almost anything, so accept one only
        # when the result contains no bytes the codepage could not represent.
        if not _UNDECODABLE.search(text):
            return text, encoding
    return raw.decode('cp1250', errors='replace'), 'cp1250/replace'


def _disc_number(name):
    match = _DISC_RE.search(name)
    return int(match.group(1)) if match else None


def _extension_rank(name):
    ext = os.path.splitext(name)[1].lower()
    try:
        return PREFERRED_EXTENSIONS.index(ext)
    except ValueError:
        return len(PREFERRED_EXTENSIONS)


def rank_members(names, release_hint=''):
    """Order archive members best-first for the given release.

    Sorting is by release match, then by preferred format, then by name so the
    result is stable for archives that carry no useful hints at all.
    """
    scored = []
    for name in names:
        base = os.path.basename(name)
        score, _reasons = release_score(base, release_hint) if release_hint else (0, [])
        scored.append((score, -_extension_rank(base), base.lower(), name))
    scored.sort(key=lambda row: (row[0], row[1]), reverse=True)
    return [row[3] for row in scored]


def subtitle_members(names):
    """Archive entries that are plausibly subtitles, directories removed."""
    out = []
    for name in names:
        if name.endswith('/') or name.endswith('\\'):
            continue
        base = os.path.basename(name)
        if not base or base.startswith('.') or base.startswith('__MACOSX'):
            continue
        if os.path.splitext(base)[1].lower() in TEXT_EXTENSIONS:
            out.append(name)
    return out


def list_archive(raw):
    """Names of the subtitle files inside a ZIP payload."""
    if not is_zip(raw):
        return []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        return subtitle_members(archive.namelist())


def has_multiple_discs(names):
    """True when the archive holds a genuinely split movie rather than
    alternative versions of the same one."""
    discs = set(filter(None, (_disc_number(os.path.basename(n)) for n in names)))
    return len(discs) > 1


def extract(raw, release_hint='', member=None):
    """Unwrap a downloaded payload into (text, member_name, members).

    `member` forces a specific archive entry, which is how the "this archive
    has several variants, which one?" dialog feeds its answer back in.
    """
    if not raw:
        raise ArchiveError('Prázdná odpověď při stahování titulků')

    if is_gzip(raw):
        try:
            raw = gzip.decompress(raw)
        except OSError as exc:
            raise ArchiveError('Poškozený gzip archiv: %s' % exc)

    if not is_zip(raw):
        text, _encoding = decode_text(raw)
        return text, '', []

    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        members = subtitle_members(archive.namelist())
        if not members:
            raise ArchiveError('Archiv neobsahuje žádné titulky')
        ordered = rank_members(members, release_hint)
        pick = member if member in members else ordered[0]
        text, _encoding = decode_text(archive.read(pick))
        return text, pick, ordered


def normalize_newlines(text):
    """Kodi is happiest with plain \\n and no BOM."""
    return str(text or '').replace('\r\n', '\n').replace('\r', '\n').lstrip('﻿')
