# -*- coding: utf-8 -*-
import hashlib
import io
import json
import os
import re
import sys
import time
import zipfile
import gzip
from urllib.parse import parse_qs, urlencode, unquote_plus
import urllib.error
import urllib.parse
import urllib.request

import xbmc  # type: ignore
import xbmcaddon  # type: ignore
import xbmcgui  # type: ignore
import xbmcplugin  # type: ignore
import xbmcvfs  # type: ignore

LIB_DIR = os.path.join(os.path.dirname(__file__), 'resources', 'lib')
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)

from core import build_video_identity as build_video_identity_model
from core import inspect_subtitle_file, score_candidate, score_osdb_item
from core import compute_osdb_hash, subtitle_offset_store
from core import adjust_srt_for_video_duration

import providers as subtitle_providers
from providers import ProviderContext, ProviderError, SearchRequest
from providers import archive as provider_archive
from providers import orchestrator as provider_orchestrator

ADDON_ID = 'service.subtitles.subtrans'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_VERSION = ADDON.getAddonInfo('version')
HANDLE = int(sys.argv[1])
OSDB_TOKEN_TTL_SEC = 11 * 60 * 60
STREAM_AUTO_TEMP_SCAN_LIMIT = 25
SUPPORTED_TEXT_SUBTITLE_EXTS = ('.srt', '.vtt')
BACKEND_UA = 'Kodi-SubtransProvider/' + ADDON_VERSION

SRT_BLOCK_RE = re.compile(
    r'(?ms)^\s*(\d+)\s*\n'
    r'([0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3})\s*-->\s*([0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3})\s*\n'
    r'(.*?)(?=\n\s*\n|\Z)'
)
URL_RE = re.compile(r'^[a-zA-Z][a-zA-Z0-9+.-]*://')

LANG_MAP = {
    'cs': ('CS', 'Czech'), 'czech': ('CS', 'Czech'), 'čeština': ('CS', 'Czech'),
    'sk': ('SK', 'Slovak'), 'slovak': ('SK', 'Slovak'),
    'de': ('DE', 'German'), 'german': ('DE', 'German'), 'deutsch': ('DE', 'German'),
    'fr': ('FR', 'French'), 'french': ('FR', 'French'),
    'es': ('ES', 'Spanish'), 'spanish': ('ES', 'Spanish'), 'español': ('ES', 'Spanish'),
    'it': ('IT', 'Italian'), 'italian': ('IT', 'Italian'),
    'nl': ('NL', 'Dutch'), 'dutch': ('NL', 'Dutch'),
    'pl': ('PL', 'Polish'), 'polish': ('PL', 'Polish'),
    'pt': ('PT-PT', 'Portuguese'), 'portuguese': ('PT-PT', 'Portuguese'),
    'pt-br': ('PT-BR', 'Portuguese (Brazilian)'), 'brazilian': ('PT-BR', 'Portuguese (Brazilian)'),
    'ro': ('RO', 'Romanian'), 'romanian': ('RO', 'Romanian'),
    'hu': ('HU', 'Hungarian'), 'hungarian': ('HU', 'Hungarian'),
    'bg': ('BG', 'Bulgarian'), 'bulgarian': ('BG', 'Bulgarian'),
    'sl': ('SL', 'Slovenian'), 'slovenian': ('SL', 'Slovenian'),
    'da': ('DA', 'Danish'), 'danish': ('DA', 'Danish'),
    'fi': ('FI', 'Finnish'), 'finnish': ('FI', 'Finnish'),
    'sv': ('SV', 'Swedish'), 'swedish': ('SV', 'Swedish'),
    'lt': ('LT', 'Lithuanian'), 'lithuanian': ('LT', 'Lithuanian'),
    'lv': ('LV', 'Latvian'), 'latvian': ('LV', 'Latvian'),
    'et': ('ET', 'Estonian'), 'estonian': ('ET', 'Estonian'),
    'el': ('EL', 'Greek'), 'greek': ('EL', 'Greek'),
    'ja': ('JA', 'Japanese'), 'japanese': ('JA', 'Japanese'),
    'ko': ('KO', 'Korean'), 'korean': ('KO', 'Korean'),
    'zh': ('ZH', 'Chinese'), 'chinese': ('ZH', 'Chinese'), 'zh-cn': ('ZH', 'Chinese'),
    'ru': ('RU', 'Russian'), 'russian': ('RU', 'Russian'),
    'uk': ('UK', 'Ukrainian'), 'ukrainian': ('UK', 'Ukrainian'),
    'tr': ('TR', 'Turkish'), 'turkish': ('TR', 'Turkish'),
    'ar': ('AR', 'Arabic'), 'arabic': ('AR', 'Arabic'),
    'id': ('ID', 'Indonesian'), 'indonesian': ('ID', 'Indonesian'),
}


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[SubtransProvider] %s' % msg, level)


def get_setting_string(key, default=''):
    try:
        value = ADDON.getSettingString(key)
        if value is not None:
            return str(value)
    except Exception:
        pass
    try:
        value = ADDON.getSetting(key)
        if value is not None:
            return str(value)
    except Exception:
        pass
    return str(default)


def get_bool_setting(key, default=False):
    raw = str(get_setting_string(key, 'true' if default else 'false')).strip().lower()
    if raw in ('true', '1', 'yes', 'on'):
        return True
    if raw in ('false', '0', 'no', 'off', ''):
        return False
    return bool(default)


def notify(msg):
    try:
        if get_bool_setting('show_notifications', True):
            xbmcgui.Dialog().notification('Subtrans', msg, '', 3500, False)
    except Exception:
        pass


def get_int_setting(key, default):
    try:
        return int((get_setting_string(key, str(default)) or str(default)).strip())
    except Exception:
        return default


def end_dir(succeeded=True):
    try:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded, cacheToDisc=False)
    except TypeError:
        xbmcplugin.endOfDirectory(HANDLE)


def get_param_dict():
    raw = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else (sys.argv[2] if len(sys.argv) > 2 else '')
    qs = parse_qs(raw)
    return {k: v[0] for k, v in qs.items() if v}


def is_url_path(path):
    return bool(path and URL_RE.match(path))


def translate_special_path(path):
    p = str(path or '').strip()
    if not p:
        return ''
    if p.startswith('special://'):
        try:
            return xbmcvfs.translatePath(p)
        except Exception:
            return p
    return p


def path_exists_any(path):
    p = translate_special_path(path)
    if not p:
        return False
    try:
        return os.path.exists(p)
    except Exception:
        pass
    try:
        return xbmcvfs.exists(p)
    except Exception:
        return False


def path_is_file_any(path):
    p = translate_special_path(path)
    if not p:
        return False
    try:
        return os.path.isfile(p)
    except Exception:
        pass
    try:
        if not xbmcvfs.exists(p):
            return False
        return not xbmcvfs.Stat(p).isDirectory()
    except Exception:
        return False


def list_dir_any(path):
    p = translate_special_path(path)
    if not p:
        return []
    try:
        return os.listdir(p)
    except Exception:
        pass
    try:
        dirs, files = xbmcvfs.listdir(p)
        return list(files or [])
    except Exception:
        return []


def file_mtime_any(path):
    p = translate_special_path(path)
    try:
        return os.path.getmtime(p)
    except Exception:
        pass
    try:
        stat = xbmcvfs.Stat(p)
        value = getattr(stat, 'st_mtime', None)
        if value is None and hasattr(stat, 'mtime'):
            value = stat.mtime()
        if value is None and hasattr(stat, 'st_mtime'):
            value = stat.st_mtime()
        return float(value or 0)
    except Exception:
        return 0.0


def candidate_path_if_local(path):
    if not path:
        return None
    p = translate_special_path(path)
    if is_url_path(p):
        if not p.startswith(('smb://', 'nfs://')):
            return None
    return p if path_is_file_any(p) else None


def is_supported_text_subtitle(path):
    return str(path or '').lower().endswith(SUPPORTED_TEXT_SUBTITLE_EXTS)


def jsonrpc(method, params=None):
    payload = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    try:
        data = json.loads(xbmc.executeJSONRPC(json.dumps(payload)) or '{}')
        if 'error' in data:
            return None
        return data.get('result')
    except Exception:
        return None


def get_active_player_id():
    result = jsonrpc('Player.GetActivePlayers') or []
    for item in result:
        if isinstance(item, dict) and item.get('type') == 'video':
            try:
                return int(item['playerid'])
            except Exception:
                return None
    return None


def current_video_path():
    try:
        p = xbmc.Player().getPlayingFile() or ''
        return p
    except Exception:
        return ''


def get_or_compute_video_hash(video_path):
    """Return (hash_hex, size_bytes) for current playback, cached in a window
    property so search + download reuse the same value. Returns (None, None)
    if not computable."""
    if not video_path:
        return None, None
    if str(video_path).startswith(('plugin://', 'smb://', 'nfs://', 'http://', 'https://')):
        log('Skipping OpenSubtitles hash for non-local playback path to keep subtitle search responsive: %s' % str(video_path)[:120])
        return None, None
    cache_key = 'subtrans.osdb_hash.%s' % hashlib.sha1(video_path.encode('utf-8')).hexdigest()[:12]
    try:
        win = xbmcgui.Window(10000)
        cached = win.getProperty(cache_key)
        if cached:
            parts = cached.split('|', 1)
            if len(parts) == 2 and parts[0] and parts[1].isdigit():
                return parts[0], int(parts[1])
    except Exception:
        pass
    h, sz = compute_osdb_hash(video_path, user_agent=osdb_user_agent())
    if h and sz:
        try:
            xbmcgui.Window(10000).setProperty(cache_key, '%s|%d' % (h, sz))
        except Exception:
            pass
        log('Computed OS hash for %s -> %s (size=%d)' % (video_path[:80], h, sz))
    else:
        log('OS hash not available for %s' % video_path[:80])
    return h, sz


def build_video_key(video_path, identity=None, params=None):
    """Stable per-video key for offset storage. Prefers OS hash (exact file),
    falls back to imdb+season+episode (per-episode), then path hash."""
    h, sz = get_or_compute_video_hash(video_path)
    if h:
        return 'hash:%s' % h
    parts = []
    if identity is not None:
        if getattr(identity, 'imdb_id', None):
            parts.append('imdb:%s' % identity.imdb_id)
        if getattr(identity, 'season', None) is not None:
            parts.append('s%s' % identity.season)
        if getattr(identity, 'episode', None) is not None:
            parts.append('e%s' % identity.episode)
    if params:
        season = (params.get('season') or '').strip()
        episode = (params.get('episode') or '').strip()
        if season:
            parts.append('s%s' % season)
        if episode:
            parts.append('e%s' % episode)
    if parts:
        return '|'.join(parts)
    return 'path:%s' % hashlib.sha1((video_path or '').encode('utf-8')).hexdigest()


def get_current_subtitle_delay_ms():
    """Read current Kodi subtitle delay in milliseconds (0 if no player)."""
    pid = get_active_player_id()
    if pid is None:
        return 0
    try:
        result = jsonrpc('Player.GetProperties', {
            'playerid': pid,
            'properties': ['subtitledelay'],
        }) or {}
        delay = result.get('subtitledelay', 0)
        return int(float(delay)) // 1000
    except Exception:
        return 0


def apply_subtitle_delay_ms(delay_ms):
    """Set subtitle delay on active player. Kodi expects microseconds."""
    pid = get_active_player_id()
    if pid is None:
        return False
    try:
        jsonrpc('Player.SetSubtitle', {
            'playerid': pid,
            'subtitle': 'on',
            'delay': int(delay_ms) * 1000,
        })
        return True
    except Exception as e:
        log('apply_subtitle_delay_ms failed: %s' % e, xbmc.LOGWARNING)
        return False


def profile_dir():
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(p):
        os.makedirs(p, exist_ok=True)
    return p


def get_playback_started_at():
    now = time.time()
    try:
        elapsed = float(xbmc.Player().getTime() or 0.0)
    except Exception:
        elapsed = 0.0
    return max(0.0, now - max(0.0, elapsed))


def extract_active_player_metadata():
    out = {}
    pid = get_active_player_id()
    if pid is None:
        return out
    try:
        result = jsonrpc('Player.GetItem', {
            'playerid': pid,
            'properties': ['title', 'originaltitle', 'year', 'imdbnumber', 'tvshowtitle', 'season', 'episode', 'file', 'uniqueid']
        }) or {}
        item = result.get('item') or {}
    except Exception:
        return out

    def pick(*keys):
        for key in keys:
            val = item.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        return ''

    title = pick('originaltitle', 'title')
    if title:
        out['title'] = title
    tvshowtitle = pick('tvshowtitle')
    if tvshowtitle:
        out['tvshowtitle'] = tvshowtitle
    year = str(item.get('year') or '').strip()
    if year.isdigit():
        out['year'] = year
    imdb = pick('imdbnumber')
    if imdb:
        out['imdb'] = imdb
    uniqueid = item.get('uniqueid') or {}
    if isinstance(uniqueid, dict):
        imdb_uid = str(uniqueid.get('imdb') or '').strip()
        tmdb_uid = str(uniqueid.get('tmdb') or '').strip()
        if imdb_uid and not out.get('imdb'):
            out['imdb'] = imdb_uid
        if tmdb_uid:
            out['tmdb'] = tmdb_uid
    season = str(item.get('season') or '').strip()
    episode = str(item.get('episode') or '').strip()
    if season.isdigit():
        out['season'] = season
    if episode.isdigit():
        out['episode'] = episode
    file_path = pick('file')
    if file_path:
        out['file'] = file_path
    return out


def tokenize_match_text(value):
    return [tok for tok in re.split(r'[^a-z0-9]+', str(value or '').lower()) if len(tok) >= 2]


def normalize_title_text(value):
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9]+', ' ', str(value or '').lower())).strip()


def looks_opaque_video_name(value):
    stem = os.path.splitext(os.path.basename(str(value or '').strip()))[0].lower()
    if not stem:
        return False
    if stem.startswith('temp') or stem.startswith('stream'):
        return True
    if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', stem):
        return True
    if re.match(r'^[0-9a-f]{24,}$', stem):
        return True
    if re.match(r'^[0-9a-z_-]{24,}$', stem) and len(tokenize_match_text(stem)) <= 2:
        return True
    return False


def best_kodi_title(video_path='', params=None):
    params = params or {}
    for key in (
        'VideoPlayer.Title',
        'Player.Title',
        'VideoPlayer.OriginalTitle',
        'ListItem.OriginalTitle',
        'ListItem.Title',
    ):
        value = (xbmc.getInfoLabel(key) or '').strip()
        if value and value.lower() != 'subtrans':
            return value
    player_meta = extract_active_player_metadata()
    if player_meta.get('title'):
        return str(player_meta.get('title')).strip()
    umbrella_meta = umbrella_window_metadata()
    if umbrella_meta.get('title'):
        return str(umbrella_meta.get('title')).strip()
    playback = extract_plugin_playback_metadata(video_path)
    if playback.get('title'):
        return str(playback.get('title')).strip()
    for key in ('searchstring', 'query', 'title'):
        value = str(params.get(key) or '').strip()
        if value:
            return value
    return ''


def log_title_probe(video_path, params=None):
    params = params or {}
    snapshot = {
        'video_path': str(video_path or ''),
        'player_getitem_title': extract_active_player_metadata().get('title') or '',
        'player_getitem_year': extract_active_player_metadata().get('year') or '',
        'plugin_title': extract_plugin_playback_metadata(video_path).get('title') or '',
        'plugin_year': extract_plugin_playback_metadata(video_path).get('year') or '',
        'VideoPlayer.OriginalTitle': xbmc.getInfoLabel('VideoPlayer.OriginalTitle') or '',
        'VideoPlayer.Title': xbmc.getInfoLabel('VideoPlayer.Title') or '',
        'Player.Title': xbmc.getInfoLabel('Player.Title') or '',
        'ListItem.OriginalTitle': xbmc.getInfoLabel('ListItem.OriginalTitle') or '',
        'ListItem.Title': xbmc.getInfoLabel('ListItem.Title') or '',
        'ListItem.Label': xbmc.getInfoLabel('ListItem.Label') or '',
        'VideoPlayer.Year': xbmc.getInfoLabel('VideoPlayer.Year') or '',
        'VideoPlayer.Premiered': xbmc.getInfoLabel('VideoPlayer.Premiered') or '',
        'param_title': params.get('title') or '',
        'param_query': params.get('query') or '',
        'param_searchstring': params.get('searchstring') or '',
        'param_year': params.get('year') or '',
    }
    try:
        log('Title probe: %s' % json.dumps(snapshot, ensure_ascii=False))
    except Exception:
        log('Title probe failed to serialize', xbmc.LOGWARNING)


def collect_hint_tokens(values):
    tokens = set()
    for value in values or []:
        base = os.path.basename(str(value or '').strip())
        stem = os.path.splitext(base)[0]
        for tok in tokenize_match_text(stem):
            tokens.add(tok)
    return tokens


def score_hint_token_overlap(path, active_hint_tokens=None, general_hint_tokens=None):
    active_hint_tokens = active_hint_tokens or set()
    general_hint_tokens = general_hint_tokens or set()
    cand_tokens = set(tokenize_match_text(os.path.splitext(os.path.basename(path or ''))[0]))
    if not cand_tokens:
        return 0
    score = 0
    if active_hint_tokens:
        score += min(140, len(cand_tokens & active_hint_tokens) * 35)
    if general_hint_tokens:
        score += min(70, len(cand_tokens & general_hint_tokens) * 14)
    return score


def current_video_display_name(video_path, params=None):
    params = params or {}
    base_name = os.path.splitext(os.path.basename(video_path))[0] if video_path else ''
    base_tokens = set(tokenize_match_text(base_name))
    base_is_opaque = looks_opaque_video_name(base_name)
    player_meta = extract_active_player_metadata()
    player_title = (player_meta.get('title') or '').strip()
    if player_title:
        player_tokens = set(tokenize_match_text(player_title))
        if player_tokens and (not base_tokens or base_is_opaque or len(base_tokens & player_tokens) >= max(1, min(2, len(player_tokens)))):
            year = player_meta.get('year') or extract_video_search_year(params)
            return '%s (%s)' % (player_title, year) if year and year not in player_title else player_title
    playback = extract_plugin_playback_metadata(video_path)
    plugin_title = (playback.get('title') or '').strip()
    if plugin_title:
        plugin_tokens = set(tokenize_match_text(plugin_title))
        if plugin_tokens and (not base_tokens or base_is_opaque or len(base_tokens & plugin_tokens) >= max(1, min(2, len(plugin_tokens)))):
            year = extract_video_search_year(params)
            return '%s (%s)' % (plugin_title, year) if year and year not in plugin_title else plugin_title

    umbrella_meta = umbrella_window_metadata()
    umbrella_title = (umbrella_meta.get('title') or '').strip()
    if umbrella_title:
        umbrella_tokens = set(tokenize_match_text(umbrella_title))
        if umbrella_tokens and (not base_tokens or base_is_opaque or len(base_tokens & umbrella_tokens) >= max(1, min(2, len(umbrella_tokens)))):
            year = umbrella_meta.get('year') or extract_video_search_year(params)
            return '%s (%s)' % (umbrella_title, year) if year and year not in umbrella_title else umbrella_title

    for info_label in (
        'VideoPlayer.OriginalTitle',
        'VideoPlayer.Title',
        'Player.Title',
        'ListItem.OriginalTitle',
        'ListItem.Title',
        'ListItem.Label',
    ):
        label_val = (xbmc.getInfoLabel(info_label) or '').strip()
        if label_val:
            label_tokens = set(tokenize_match_text(label_val))
            if (not base_is_opaque) and base_tokens and label_tokens and len(base_tokens & label_tokens) < max(1, min(2, len(base_tokens))):
                continue
            year = extract_video_search_year(params)
            return '%s (%s)' % (label_val, year) if year and year not in label_val else label_val

    for key in ('searchstring', 'query', 'title'):
        val = (params.get(key) or '').strip()
        if val:
            val_tokens = set(tokenize_match_text(val))
            if (not base_is_opaque) and base_tokens and val_tokens and len(base_tokens & val_tokens) < max(1, min(2, len(base_tokens))):
                continue
            year = extract_video_search_year(params)
            return '%s (%s)' % (val, year) if year and year not in val else val

    if video_path:
        return base_name
    return 'aktuální video'


def build_video_identity(video_path, params=None):
    params = params or {}
    title = current_video_display_name(video_path, params)
    base_name = os.path.splitext(os.path.basename(video_path))[0] if video_path else ''
    folder = os.path.dirname(video_path) if video_path and not is_url_path(video_path) else ''
    year = extract_video_search_year(params)
    title_tokens = set(tokenize_match_text(title))
    base_tokens = set(tokenize_match_text(base_name))
    return {
        'title': title,
        'base_name': base_name,
        'base_norm': normalize_title_text(base_name),
        'folder': folder,
        'year': year,
        'title_tokens': title_tokens,
        'base_tokens': base_tokens,
        'all_tokens': title_tokens | base_tokens,
    }


def local_candidate_matches_video(path, video_identity):
    folder = video_identity.get('folder') or ''
    if folder and os.path.dirname(path) != folder:
        return False

    name = os.path.basename(path or '')
    stem = os.path.splitext(name)[0]
    stem_norm = normalize_title_text(stem)
    if not stem_norm:
        return False

    base_norm = video_identity.get('base_norm') or ''
    if base_norm and (stem_norm == base_norm or stem_norm.startswith(base_norm + ' ')):
        return True

    cand_tokens = set(tokenize_match_text(stem))
    base_tokens = video_identity.get('base_tokens') or set()
    title_tokens = video_identity.get('title_tokens') or set()
    all_tokens = video_identity.get('all_tokens') or set()
    year = video_identity.get('year') or ''

    if year and year in stem and title_tokens and len(cand_tokens & title_tokens) >= max(1, min(2, len(title_tokens))):
        return True
    if base_tokens and len(cand_tokens & base_tokens) >= max(1, min(2, len(base_tokens))):
        return True
    if all_tokens and len(cand_tokens & all_tokens) >= max(2, min(3, len(all_tokens))):
        return True
    return False


def get_current_subtitle_candidates(video_path):
    cands = []
    active_cands = []
    active_hint_names = []
    general_hint_names = []
    video_dir = ''
    if video_path and path_exists_any(video_path):
        video_dir = os.path.dirname(video_path)

    cands.extend(get_stream_cinema_subtitle_candidates())
    cands.extend(get_umbrella_subtitle_candidates())

    def append_candidate(raw, prefer_active=False):
        raw_str = str(raw or '').strip()
        if raw_str:
            general_hint_names.append(raw_str)
            if prefer_active:
                active_hint_names.append(raw_str)
        p = candidate_path_if_local(raw_str)
        if not p and video_dir:
            name = os.path.basename(raw_str)
            if name:
                fallback = os.path.join(video_dir, name)
                p = candidate_path_if_local(fallback)
        if not p or not is_supported_text_subtitle(p):
            return
        cands.append(p)
        if prefer_active:
            active_cands.append(p)

    pid = get_active_player_id()
    if pid is not None:
        props = jsonrpc('Player.GetProperties', {'playerid': pid, 'properties': ['currentsubtitle', 'subtitles']}) or {}
        try:
            subtitle_probe = []
            for sub in props.get('subtitles') or []:
                if isinstance(sub, dict):
                    subtitle_probe.append({
                        'name': sub.get('name'),
                        'language': sub.get('language'),
                        'file': sub.get('file'),
                        'index': sub.get('index'),
                    })
            log('Kodi subtitle props: current=%s tracks=%s' % (
                json.dumps(props.get('currentsubtitle') or {}, ensure_ascii=False),
                json.dumps(subtitle_probe, ensure_ascii=False)[:1500],
            ))
        except Exception:
            pass
        for key in ('currentsubtitle',):
            sub = props.get(key)
            if isinstance(sub, dict):
                for name_key in ('file', 'name'):
                    append_candidate(sub.get(name_key), prefer_active=True)
        for sub in props.get('subtitles') or []:
            if isinstance(sub, dict):
                for name_key in ('file', 'name'):
                    append_candidate(sub.get(name_key), prefer_active=False)

    label_path = xbmc.getInfoLabel('VideoPlayer.SubtitlesFilename') or ''
    append_candidate(label_path, prefer_active=True)
    for info_label in (
        'VideoPlayer.SubtitlesLanguage',
        'VideoPlayer.OriginalTitle',
        'VideoPlayer.Title',
        'Player.Title',
        'ListItem.Title',
        'ListItem.Label',
        'VideoPlayer.Filename',
        'Player.Filename',
    ):
        label_val = xbmc.getInfoLabel(info_label) or ''
        if label_val:
            general_hint_names.append(label_val)

    if video_path and path_exists_any(video_path):
        folder = os.path.dirname(video_path)
        try:
            for name in list_dir_any(folder):
                if not is_supported_text_subtitle(name):
                    continue
                full = os.path.join(folder, name)
                if path_is_file_any(full):
                    cands.append(full)
        except Exception:
            pass
        return dedupe_paths(cands)

    should_scan_temp = get_bool_setting('temp_scan_enabled', False)
    if should_scan_temp:
        temp_limit = max(1, get_int_setting('temp_scan_limit', 10))
        if is_url_path(video_path) or str(video_path or '').startswith('plugin://'):
            temp_limit = max(temp_limit, STREAM_AUTO_TEMP_SCAN_LIMIT)
        # Kodi reuses temp directories across playback. Stream add-ons can
        # write external subtitles before Player.GetTime starts, so use a
        # recent window rather than strict playback-start matching.
        min_mtime = max(0.0, time.time() - 30 * 60)
        cands.extend(scan_temp_subs(max_items=temp_limit, min_mtime=min_mtime))

    cands = dedupe_paths(cands)
    return dedupe_paths(cands)


def get_preferred_subtitle_paths(video_path):
    preferred = set()
    video_dir = ''
    if video_path and path_exists_any(video_path):
        video_dir = os.path.dirname(video_path)
    preferred.update(stream_cinema_subtitle_cache_paths())
    preferred.update(umbrella_subtitle_cache_paths())

    def add_preferred(raw):
        raw_str = str(raw or '').strip()
        p = candidate_path_if_local(raw_str)
        if not p and video_dir:
            name = os.path.basename(raw_str)
            if name:
                p = candidate_path_if_local(os.path.join(video_dir, name))
        if p and is_supported_text_subtitle(p):
            preferred.add(p)

    pid = get_active_player_id()
    if pid is not None:
        props = jsonrpc('Player.GetProperties', {'playerid': pid, 'properties': ['currentsubtitle']}) or {}
        sub = props.get('currentsubtitle')
        if isinstance(sub, dict):
            add_preferred(sub.get('file'))
            add_preferred(sub.get('name'))
    add_preferred(xbmc.getInfoLabel('VideoPlayer.SubtitlesFilename') or '')
    return preferred


def score_local_candidate(video_base, path, preferred_paths=None, active_hint_tokens=None, general_hint_tokens=None):
    name = os.path.basename(path).lower()
    stem = os.path.splitext(name)[0]
    score = 0
    preferred_paths = preferred_paths or set()
    if path in preferred_paths:
        score += 500
    if stem == video_base:
        score += 60
    if stem.startswith(video_base + '.') or stem.startswith(video_base + ' '):
        score += 40
    if any(tok in name for tok in ('.en.', '.eng.', 'english')):
        score += 25
    if '.subtrans.' in name:
        score -= 200
    score += score_hint_token_overlap(path, active_hint_tokens=active_hint_tokens, general_hint_tokens=general_hint_tokens)
    try:
        score += min(10, int(os.path.getmtime(path) % 10))
    except Exception:
        pass
    return score


def score_stream_candidate(path, preferred_paths=None, active_hint_tokens=None, general_hint_tokens=None):
    name = os.path.basename(path).lower()
    score = 10
    preferred_paths = preferred_paths or set()
    if path in preferred_paths:
        score += 500
    if any(tok in name for tok in ('.en.', '.eng.', 'english')):
        score += 25
    if '.subtrans.' in name:
        score -= 200
    score += score_hint_token_overlap(path, active_hint_tokens=active_hint_tokens, general_hint_tokens=general_hint_tokens)
    try:
        age_hours = max(0.0, (time.time() - os.path.getmtime(path)) / 3600.0)
        score += max(0, 24 - int(age_hours))
    except Exception:
        pass
    return score


def scan_temp_subs(max_items=25, time_budget_sec=1.5, min_mtime=None):
    roots = []
    for special in ('special://temp/', 'special://profile/temp/', 'special://home/temp/'):
        try:
            root = xbmcvfs.translatePath(special)
        except Exception:
            root = ''
        if root and os.path.isdir(root) and root not in roots:
            roots.append(root)
    if not roots:
        return []
    found = []
    started = time.time()
    for root in roots:
        if time.time() - started > time_budget_sec:
            break
        for cur, dirs, files in os.walk(root):
            if time.time() - started > time_budget_sec:
                break
            rel = os.path.relpath(cur, root)
            depth = 0 if rel == '.' else rel.count(os.sep) + 1
            if depth > 6:
                dirs[:] = []
                continue
            for f in files:
                if time.time() - started > time_budget_sec:
                    break
                if not is_supported_text_subtitle(f):
                    continue
                full = os.path.join(cur, f)
                try:
                    mtime = os.path.getmtime(full)
                    if min_mtime is not None and mtime < min_mtime:
                        continue
                    found.append((mtime, full))
                except Exception:
                    pass
    found.sort(reverse=True)
    return [p for _m, p in found[:max_items]]


def stream_cinema_play_item():
    try:
        raw = xbmcgui.Window(10000).getProperty('SC.play_item') or ''
        return json.loads(raw) if raw else {}
    except Exception as e:
        log('Stream Cinema play item unavailable: %s' % e, xbmc.LOGDEBUG)
        return {}


def safe_json_loads(value, default=None):
    try:
        if not value:
            return {} if default is None else default
        parsed = json.loads(str(value))
        return parsed if parsed is not None else ({} if default is None else default)
    except Exception:
        return {} if default is None else default


def stream_cinema_metadata(play_item=None):
    data = play_item or stream_cinema_play_item()
    out = {}
    if not isinstance(data, dict) or not data:
        return out
    selected = data.get('strms') if isinstance(data.get('strms'), dict) else {}
    for source in (data, selected):
        if not isinstance(source, dict):
            continue
        for src_key, dst_key in (
            ('title', 'title'),
            ('originaltitle', 'title'),
            ('original_title', 'title'),
            ('name', 'title'),
            ('year', 'year'),
            ('imdb', 'imdb'),
            ('imdbnumber', 'imdb'),
            ('tmdb', 'tmdb'),
            ('tvdb', 'tvdb'),
            ('season', 'season'),
            ('episode', 'episode'),
        ):
            value = str(source.get(src_key) or '').strip()
            if value and not out.get(dst_key):
                out[dst_key] = value
    return out


def stream_cinema_context_active():
    data = stream_cinema_play_item()
    if not isinstance(data, dict) or not data:
        return False
    return bool(data.get('strms') or stream_cinema_selected_source_hint(data) or stream_cinema_metadata(data))


def umbrella_window_metadata():
    if stream_cinema_context_active():
        return {}
    out = {}
    try:
        win = xbmcgui.Window(10000)
        raw_meta = win.getProperty('plugin.video.umbrella.container.meta') or ''
        meta = safe_json_loads(urllib.parse.unquote(raw_meta.replace('%22', '\\"')), {})
        if not isinstance(meta, dict):
            meta = {}
        for src_key, dst_key in (
            ('title', 'title'),
            ('originaltitle', 'title'),
            ('tvshowtitle', 'tvshowtitle'),
            ('year', 'year'),
            ('imdb', 'imdb'),
            ('imdbnumber', 'imdb'),
            ('tmdb', 'tmdb'),
            ('tvdb', 'tvdb'),
            ('season', 'season'),
            ('episode', 'episode'),
        ):
            value = str(meta.get(src_key) or '').strip()
            if value and not out.get(dst_key):
                out[dst_key] = value
        for prop_key, dst_key in (
            ('plugin.video.umbrella.container.title', 'title'),
            ('plugin.video.umbrella.container.imdb', 'imdb'),
            ('plugin.video.umbrella.container.tmdb', 'tmdb'),
            ('plugin.video.umbrella.container.tvdb', 'tvdb'),
            ('plugin.video.umbrella.container.season', 'season'),
            ('plugin.video.umbrella.container.episode', 'episode'),
        ):
            value = str(win.getProperty(prop_key) or '').strip()
            if value and not out.get(dst_key):
                out[dst_key] = value
        if out.get('tvshowtitle'):
            out['title'] = out.get('tvshowtitle') or out.get('title')
        return out
    except Exception as e:
        log('Umbrella metadata unavailable: %s' % e, xbmc.LOGDEBUG)
        return {}


def umbrella_selected_source():
    try:
        win = xbmcgui.Window(10000)
        for key in ('plugin.video.umbrella.selected_source', 'plugin.video.umbrella.resolving_source'):
            raw = win.getProperty(key) or ''
            data = safe_json_loads(raw, {})
            if isinstance(data, dict) and data:
                return data
        return {}
    except Exception as e:
        log('Umbrella selected source unavailable: %s' % e, xbmc.LOGDEBUG)
        return {}


def umbrella_selected_source_hint():
    source = umbrella_selected_source()
    if not source:
        return ''
    parts = []
    for key in ('name', 'filename', 'fileName', 'release_title', 'title', 'info', 'quality', 'provider', 'source', 'debrid', 'hash'):
        value = str(source.get(key) or '').strip()
        if value and value.lower() != 'n/a':
            parts.append(value)
    return ' | '.join(parts)


def umbrella_subtitle_roots():
    roots = []
    for special in (
        'special://profile/addon_data/plugin.video.umbrella/subtitles',
        'special://home/userdata/addon_data/plugin.video.umbrella/subtitles',
    ):
        try:
            root = xbmcvfs.translatePath(special)
        except Exception:
            root = ''
        if root and os.path.isdir(root) and root not in roots:
            roots.append(root)
    return roots


def umbrella_subtitle_cache_paths(max_age_sec=45 * 60):
    # Umbrella's subtitle directory is a shared cache. Treat it as unsafe unless
    # the user explicitly enables temp scanning; otherwise stale subtitles from
    # the previous stream can be offered as LOCAL and translated by mistake.
    if not get_bool_setting('temp_scan_enabled', False):
        return []
    found = []
    min_mtime = time.time() - max_age_sec
    for root in umbrella_subtitle_roots():
        try:
            for cur, _dirs, files in os.walk(root):
                for name in files:
                    if not is_supported_text_subtitle(name):
                        continue
                    path = os.path.join(cur, name)
                    try:
                        if os.path.getmtime(path) >= min_mtime:
                            found.append(path)
                    except Exception:
                        pass
        except Exception:
            pass
    found.sort(key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0, reverse=True)
    return dedupe_paths(found[:12])


def get_umbrella_subtitle_candidates():
    paths = umbrella_subtitle_cache_paths()
    if paths:
        log('Umbrella subtitle cache candidates: %s' % ', '.join(os.path.basename(p) for p in paths[:4]))
    return paths


def stream_cinema_subtitle_ref(play_item=None):
    data = play_item or stream_cinema_play_item()
    selected = data.get('strms') if isinstance(data, dict) else {}
    if isinstance(selected, dict):
        for key in ('subs', 'subtitles', 'subtitle'):
            value = selected.get(key)
            if value:
                return str(value)
    if isinstance(data, dict):
        for key in ('subs', 'subtitles', 'subtitle'):
            value = data.get(key)
            if value:
                return str(value)
    return ''


def stream_cinema_selected_source_hint(play_item=None):
    data = play_item or stream_cinema_play_item()
    if not isinstance(data, dict):
        return ''
    selected = data.get('strms') if isinstance(data.get('strms'), dict) else {}
    parts = []
    for source in (selected, data):
        if not isinstance(source, dict):
            continue
        for key in (
            'name', 'title', 'filename', 'fileName', 'release', 'release_title',
            'quality', 'video_quality', 'size', 'source', 'provider', 'ident',
            'hash', 'lang', 'audio', 'codec',
        ):
            value = str(source.get(key) or '').strip()
            if value and value.lower() != 'n/a':
                parts.append(value)
    deduped = []
    seen = set()
    for part in parts:
        key = part.lower()
        if key not in seen:
            seen.add(key)
            deduped.append(part)
    return ' | '.join(deduped)


def stream_cinema_subtitle_cache_paths():
    try:
        cache = profile_cache_dir()
        return [
            os.path.join(cache, name)
            for name in os.listdir(cache)
            if name.startswith('streamcinema_') and is_supported_text_subtitle(name)
        ]
    except Exception:
        return []


def stream_cinema_import_kraska():
    errors = []
    for addon_id in ('plugin.video.mulenstream', 'plugin.video.stream-cinema'):
        try:
            sc_root = xbmcvfs.translatePath('special://home/addons/%s' % addon_id)
            if not sc_root or not os.path.isdir(sc_root):
                continue
            if sc_root not in sys.path:
                sys.path.insert(0, sc_root)
            from resources.lib.api.kraska import getKraInstance  # type: ignore
            return getKraInstance()
        except Exception as e:
            errors.append('%s: %s' % (addon_id, e))
    if errors:
        log('MulenStream/Stream Cinema resolver import failed: %s' % '; '.join(errors), xbmc.LOGWARNING)
    return None


def stream_cinema_subtitle_ident(subtitle_ref):
    ref = str(subtitle_ref or '').strip()
    if not ref:
        return ''
    marker = '/file/'
    if marker in ref:
        return ref.split(marker, 1)[1].split('?', 1)[0].strip('/')
    if re.match(r'^[A-Za-z0-9:_-]{6,}$', ref):
        return ref
    return ''


def download_url_to_cache(url, file_name_hint, key_hint):
    req = urllib.request.Request(url, headers={'User-Agent': osdb_user_agent()})
    with urllib.request.urlopen(req, timeout=max(5, min(30, backend_timeout()))) as resp:
        raw = resp.read()
    ext = '.vtt' if str(file_name_hint or '').lower().endswith('.vtt') or b'WEBVTT' in raw[:128] else '.srt'
    safe_base = re.sub(r'[^A-Za-z0-9._-]+', '_', os.path.splitext(file_name_hint or 'subtitle')[0]).strip('._') or 'subtitle'
    key = hashlib.sha1((key_hint + '|' + safe_base).encode('utf-8')).hexdigest()[:12]
    out_path = os.path.join(profile_cache_dir(), 'streamcinema_%s.%s%s' % (key, safe_base, ext))
    with open(out_path, 'wb') as fh:
        fh.write(raw)
    return out_path


def get_stream_cinema_subtitle_candidates():
    subtitle_ref = stream_cinema_subtitle_ref()
    ident = stream_cinema_subtitle_ident(subtitle_ref)
    if not ident:
        return []
    cache_key = 'streamcinema|%s' % ident
    expected_key = hashlib.sha1((cache_key + '|streamcinema_external').encode('utf-8')).hexdigest()[:12]
    for cached in stream_cinema_subtitle_cache_paths():
        if expected_key in os.path.basename(cached):
            return [cached]
    kr = stream_cinema_import_kraska()
    if not kr:
        return []
    try:
        url = kr.resolve(ident)
        if not url:
            return []
        out_path = download_url_to_cache(url, 'streamcinema_external.srt', cache_key)
        log('Stream Cinema assigned subtitle resolved into Subtrans cache: %s' % os.path.basename(out_path))
        return [out_path]
    except Exception as e:
        log('Stream Cinema subtitle resolve failed: %s' % e, xbmc.LOGWARNING)
        return []


def dedupe_paths(paths):
    out = []
    seen = set()
    for p in paths:
        n = os.path.normpath(p)
        if n not in seen and os.path.isfile(n):
            seen.add(n)
            out.append(n)
    return out


def parse_srt(text):
    normalized = text.replace('\r\n', '\n').replace('\r', '\n')
    rows = []
    for m in SRT_BLOCK_RE.finditer(normalized):
        rows.append({'i': int(m.group(1)), 's': m.group(2), 'e': m.group(3), 't': m.group(4).rstrip('\n')})
    if not rows:
        raise RuntimeError('Unable to parse SRT')
    return rows


def format_srt(rows):
    chunks = []
    for idx, row in enumerate(rows, start=1):
        chunks.append('%d\n%s --> %s\n%s\n' % (idx, row['s'], row['e'], row['t']))
    return '\n'.join(chunks)


def read_text(path):
    raw = None
    try:
        with open(path, 'rb') as fh:
            raw = fh.read()
    except Exception:
        try:
            fh = xbmcvfs.File(path)
            if hasattr(fh, 'readBytes'):
                raw = fh.readBytes()
            else:
                raw = fh.read()
            try:
                fh.close()
            except Exception:
                pass
        except Exception:
            raw = None
    if raw is None:
        raise RuntimeError('Cannot read subtitle file')
    raw = bytes(raw)
    for enc in ('utf-8-sig', 'utf-8', 'cp1250', 'cp1252', 'latin-1'):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    raise RuntimeError('Cannot decode subtitle file')


def profile_cache_dir():
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    cache = os.path.join(p, 'provider_cache')
    if not os.path.isdir(cache):
        os.makedirs(cache, exist_ok=True)
    return cache


def backend_mode_enabled():
    return True


def backend_base_url():
    raw = get_setting_string('backend_base_url', '').strip()
    if not raw:
        raise RuntimeError('Backend URL not set in addon settings')
    return raw.rstrip('/')


def backend_secret():
    secret = _setting_value('backend_secret', '').strip()
    if not secret:
        raise RuntimeError('Backend secret not set in addon settings')
    return secret


def backend_timeout():
    return max(5, min(120, get_int_setting('backend_timeout_sec', 25)))


def backend_download_timeout():
    # Large subtitle files (4K releases) can legitimately take much longer.
    return max(20, min(600, get_int_setting('backend_download_timeout_sec', 180)))


def backend_strict_match_enabled():
    return get_bool_setting('backend_strict_match', True)


def backend_min_confidence():
    return max(0, min(100, get_int_setting('backend_min_confidence', 60)))


def backend_hide_forced_results():
    return get_bool_setting('backend_hide_forced_results', True)


def backend_request(path, payload, timeout=None):
    url = backend_base_url() + path
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-KODI-SECRET': backend_secret(),
            'User-Agent': BACKEND_UA,
        },
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout or backend_timeout()) as resp:
            raw = resp.read().decode('utf-8')
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode('utf-8', errors='replace')
        raise RuntimeError('Backend HTTP %s: %s' % (e.code, detail[:300]))


def backend_search_subtitles(params, video_path):
    identity = build_video_identity_model(video_path, playback_started_at=get_playback_started_at(), params=params)
    player_meta = extract_active_player_metadata()
    playback = extract_plugin_playback_metadata(video_path)
    stream_cinema_meta = stream_cinema_metadata()
    umbrella_meta = umbrella_window_metadata()
    umbrella_release_hint = umbrella_selected_source_hint()
    stream_cinema_release_hint = stream_cinema_selected_source_hint()
    stream_cinema_release_hint = stream_cinema_selected_source_hint()
    umbrella_release_hint = umbrella_selected_source_hint()
    visible_title = best_kodi_title(video_path, params)
    season, episode = extract_video_search_season_episode(params)
    if identity.season is not None:
        season = str(identity.season)
    if identity.episode is not None:
        episode = str(identity.episode)
    video_resolution = (xbmc.getInfoLabel('VideoPlayer.VideoResolution') or '').strip()
    release_hint = ' | '.join([
        str(video_path or ''),
        xbmc.getInfoLabel('VideoPlayer.FileNameAndPath') or '',
        xbmc.getInfoLabel('Player.Filenameandpath') or '',
        xbmc.getInfoLabel('VideoPlayer.Filename') or '',
        xbmc.getInfoLabel('Player.Filename') or '',
        xbmc.getInfoLabel('VideoPlayer.Title') or '',
        xbmc.getInfoLabel('Player.Title') or '',
        xbmc.getInfoLabel('VideoPlayer.OriginalTitle') or '',
        xbmc.getInfoLabel('ListItem.Title') or '',
        xbmc.getInfoLabel('ListItem.Label') or '',
        xbmc.getInfoLabel('ListItem.FileNameAndPath') or '',
        stream_cinema_release_hint,
        umbrella_release_hint,
        umbrella_meta.get('title') or '',
        umbrella_meta.get('imdb') or '',
    ]).strip()
    osdb_hash, osdb_size = get_or_compute_video_hash(video_path)
    payload = {
        'query': normalize_search_title(visible_title or player_meta.get('title') or stream_cinema_meta.get('title') or umbrella_meta.get('title') or playback.get('title') or identity.title or extract_video_search_query(params, video_path)),
        'year': str(player_meta.get('year') or stream_cinema_meta.get('year') or umbrella_meta.get('year') or identity.year or extract_video_search_year(params) or ''),
        'season': season,
        'episode': episode,
        'imdbId': player_meta.get('imdb') or stream_cinema_meta.get('imdb') or umbrella_meta.get('imdb') or playback.get('imdb') or identity.imdb_id or '',
        'tmdbId': player_meta.get('tmdb') or stream_cinema_meta.get('tmdb') or umbrella_meta.get('tmdb') or playback.get('tmdb') or '',
        'videoResolution': video_resolution,
        'releaseHint': release_hint,
        'movieHash': osdb_hash or '',
        'movieByteSize': str(osdb_size) if osdb_size else '',
        'limit': max(1, get_int_setting('backend_search_limit', 10)),
    }
    log('Backend search payload: query="%s" year="%s" imdb="%s" tmdb="%s" season="%s" episode="%s" visible_title="%s" player_title="%s" stream_cinema_title="%s" stream_cinema_release="%s" umbrella_title="%s" umbrella_release="%s" plugin_title="%s" identity_title="%s"' % (
        payload.get('query') or '',
        payload.get('year') or '',
        payload.get('imdbId') or '',
        payload.get('tmdbId') or '',
        payload.get('season') or '',
        payload.get('episode') or '',
        visible_title or '',
        player_meta.get('title') or '',
        stream_cinema_meta.get('title') or '',
        stream_cinema_release_hint or '',
        umbrella_meta.get('title') or '',
        umbrella_release_hint or '',
        playback.get('title') or '',
        identity.title or '',
    ))
    if looks_opaque_video_name(payload.get('query') or '') and not payload.get('imdbId') and not payload.get('tmdbId'):
        log_title_probe(video_path, params)
    if not payload['query'] and not payload['imdbId'] and not payload['tmdbId']:
        raise RuntimeError('OpenSubtitles search skipped: missing movie metadata (title/IMDb/TMDb)')
    data = backend_request('/api/kodi/subtitles/search', payload, timeout=max(5, min(20, backend_timeout())))
    log('Backend search returned %s results' % len(data.get('results') or []))
    return data.get('results') or []


READY_SUBTITLE_EXTENSIONS = ('.srt', '.vtt', '.ass', '.ssa', '.sub', '.txt')


def write_subtitle_text_to_cache(text, file_name_hint, key_hint, force_srt=False):
    safe_name = re.sub(
        r'[^A-Za-z0-9._-]+', '_', (file_name_hint or 'subtitle.srt')
    ).strip('._') or 'subtitle.srt'
    extension = os.path.splitext(safe_name)[1].lower()
    if force_srt:
        safe_name = os.path.splitext(safe_name)[0] + '.srt'
    elif extension not in READY_SUBTITLE_EXTENSIONS:
        safe_name += '.srt'
    key = hashlib.sha1((key_hint + '|' + safe_name).encode('utf-8')).hexdigest()[:12]
    out_path = os.path.join(profile_cache_dir(), '%s.%s' % (key, safe_name))
    with open(out_path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)
    return out_path


def write_srt_text_to_cache(srt_text, file_name_hint, key_hint):
    return write_subtitle_text_to_cache(
        srt_text, file_name_hint, key_hint, force_srt=True
    )


def backend_translate_local_srt(src_path, target_code):
    source_name = os.path.basename(str(src_path or '').rstrip('/')) or 'subtitle.srt'
    data = backend_request('/api/kodi/translate-srt', {
        'srt': read_text(src_path),
        'targetLanguage': target_code,
        'fileName': source_name,
    }, timeout=backend_timeout())
    srt_text = data.get('srt') or ''
    if not srt_text:
        raise RuntimeError('Backend did not return translated SRT')
    srt_text = maybe_apply_fps_adjustment(srt_text)
    key_hint = 'local|%s|%s|%s' % (src_path, int(file_mtime_any(src_path)), target_code)
    return write_srt_text_to_cache(srt_text, data.get('fileName') or source_name, key_hint)


def backend_download_translate_osdb(file_id, target_code, name_hint=''):
    data = backend_request('/api/kodi/subtitles/download-translate', {
        'fileId': int(file_id),
        'targetLanguage': target_code,
        'fileName': name_hint or ('osdb_%s.srt' % int(file_id)),
    }, timeout=backend_download_timeout())
    if data.get('subtitle_invalid'):
        reasons = data.get('reasons') or []
        detail = '; '.join(reasons) if reasons else (data.get('error') or 'invalid source subtitle')
        raise RuntimeError('Titulky se nepodařilo použít: %s' % detail)
    srt_text = data.get('srt') or ''
    if not srt_text:
        raise RuntimeError('Backend did not return translated SRT')
    srt_text = maybe_apply_fps_adjustment(srt_text)
    key_hint = 'osdb|%s|%s' % (int(file_id), target_code)
    return write_srt_text_to_cache(srt_text, data.get('fileName') or (name_hint or 'subtitle.srt'), key_hint)


def current_video_duration_sec():
    """Return playing video duration in seconds (int), or None."""
    try:
        raw = xbmc.getInfoLabel('Player.Duration') or xbmc.getInfoLabel('VideoPlayer.Duration') or ''
        raw = raw.strip()
        if not raw:
            return None
        return int(float(raw))
    except Exception:
        return None


def maybe_apply_fps_adjustment(srt_text):
    """If subtitle duration vs video duration suggests an FPS mismatch, rescale."""
    if not get_bool_setting('auto_fps_adjust', True):
        return srt_text
    video_dur = current_video_duration_sec()
    if not video_dur:
        return srt_text
    adjusted, scale = adjust_srt_for_video_duration(srt_text, video_dur)
    if abs(scale - 1.0) > 1e-6:
        log('FPS auto-adjust: scaled subtitle timestamps by %.5f (video=%ds)' % (scale, video_dur))
    return adjusted


def read_json_file(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {} if default is None else default


def write_json_file(path, data):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh)
    os.replace(tmp, path)


def osdb_enabled():
    return get_bool_setting('osdb_enabled', True)


def osdb_api_key():
    return get_setting_string('osdb_api_key', '').strip()


def osdb_username():
    return get_setting_string('osdb_username', '').strip()


def osdb_password():
    return get_setting_string('osdb_password', '').strip()


def osdb_user_agent():
    custom = get_setting_string('osdb_user_agent', '').strip()
    return custom or ('SubtransKodi/' + ADDON_VERSION)


def osdb_timeout():
    return max(3, min(20, get_int_setting('osdb_timeout_sec', 8)))


def osdb_session_path():
    return os.path.join(profile_cache_dir(), 'opensubtitles_session.json')


def osdb_session_cache_key():
    return hashlib.sha1(('%s|%s' % (osdb_api_key(), osdb_username())).encode('utf-8')).hexdigest()


def osdb_base_url_from_host(host):
    h = (host or '').strip()
    if not h:
        h = 'api.opensubtitles.com'
    if h.startswith('http://') or h.startswith('https://'):
        base = h.rstrip('/')
    else:
        base = 'https://' + h.strip('/')
    if base.endswith('/api/v1'):
        return base
    return base + '/api/v1'


def osdb_build_url(path, base_host=None):
    p = path if path.startswith('/') else ('/' + path)
    if p.startswith('/api/v1/'):
        return osdb_base_url_from_host(base_host)[:-7] + p
    if p == '/api/v1':
        return osdb_base_url_from_host(base_host)
    return osdb_base_url_from_host(base_host) + p


def osdb_request(path, method='GET', params=None, json_body=None, token=None, base_host=None, timeout=None, expect_json=True):
    api_key = osdb_api_key()
    if not api_key:
        raise RuntimeError('OpenSubtitles API key not set')
    if isinstance(path, str) and (path.startswith('http://') or path.startswith('https://')):
        url = path
    else:
        url = osdb_build_url(path, base_host=base_host)
    if params:
        query = urllib.parse.urlencode([(k, v) for k, v in params.items() if v is not None], doseq=True)
        if query:
            url += ('&' if '?' in url else '?') + query

    headers = {
        'User-Agent': osdb_user_agent(),
        'Api-Key': api_key,
        'Accept': 'application/json' if expect_json else '*/*',
    }
    data = None
    if json_body is not None:
        data = json.dumps(json_body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    if token:
        headers['Authorization'] = 'Bearer ' + token

    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout or osdb_timeout()) as resp:
            raw = resp.read()
            if not expect_json:
                return raw, dict(resp.headers)
            if not raw:
                return {}
            return json.loads(raw.decode('utf-8'))
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        raise RuntimeError('OpenSubtitles HTTP %s %s' % (e.code, body[:300]))


def osdb_load_session():
    data = read_json_file(osdb_session_path(), default={})
    if not isinstance(data, dict):
        return None
    if data.get('cache_key') != osdb_session_cache_key():
        return None
    if not data.get('token'):
        return None
    if float(data.get('expires_at', 0) or 0) <= time.time():
        return None
    return data


def osdb_save_session(token, base_host):
    data = {
        'token': token,
        'base_host': (base_host or 'api.opensubtitles.com').strip(),
        'expires_at': time.time() + OSDB_TOKEN_TTL_SEC,
        'cache_key': osdb_session_cache_key(),
    }
    write_json_file(osdb_session_path(), data)
    return data


def osdb_login(force=False):
    if not osdb_enabled():
        raise RuntimeError('OpenSubtitles fallback disabled')
    if not osdb_api_key():
        raise RuntimeError('OpenSubtitles API key not set')
    if not osdb_username() or not osdb_password():
        raise RuntimeError('OpenSubtitles username/password not set')

    if not force:
        cached = osdb_load_session()
        if cached:
            return cached

    payload = {'username': osdb_username(), 'password': osdb_password()}
    last_err = None
    for login_path in ('/login', '/api/v1/login'):
        try:
            res = osdb_request(login_path, method='POST', json_body=payload, expect_json=True)
            token = (res or {}).get('token')
            base_host = (res or {}).get('base_url') or 'api.opensubtitles.com'
            if token:
                return osdb_save_session(token, base_host)
        except Exception as e:
            last_err = e
    raise RuntimeError('OpenSubtitles login failed: %s' % (last_err or 'unknown error'))


def osdb_request_auth(path, method='GET', params=None, json_body=None, expect_json=True):
    sess = osdb_login(force=False)
    try:
        return osdb_request(
            path,
            method=method,
            params=params,
            json_body=json_body,
            token=sess.get('token'),
            base_host=sess.get('base_host'),
            timeout=osdb_timeout(),
            expect_json=expect_json,
        )
    except Exception as e:
        msg = str(e)
        if 'HTTP 401' in msg or 'Unauthorized' in msg or 'unauthorized' in msg:
            sess = osdb_login(force=True)
            return osdb_request(
                path,
                method=method,
                params=params,
                json_body=json_body,
                token=sess.get('token'),
                base_host=sess.get('base_host'),
                timeout=osdb_timeout(),
                expect_json=expect_json,
            )
        raise


def extract_video_search_query(params, video_path):
    # Prefer Kodi metadata (similar strategy to official OpenSubtitles addon)
    player_meta = extract_active_player_metadata()
    tv_title = str(player_meta.get('tvshowtitle') or xbmc.getInfoLabel('VideoPlayer.TVshowtitle') or '').strip()
    if tv_title:
        return tv_title

    player_title = str(player_meta.get('title') or '').strip()
    if player_title:
        return player_title

    umbrella_meta = umbrella_window_metadata()
    umbrella_title = str(umbrella_meta.get('title') or '').strip()
    if umbrella_title:
        return umbrella_title

    playback = extract_plugin_playback_metadata(video_path)
    plugin_title = str(playback.get('title') or '').strip()
    if plugin_title:
        return plugin_title

    for info_label in (
        'VideoPlayer.OriginalTitle',
        'VideoPlayer.Title',
        'Player.Title',
        'ListItem.OriginalTitle',
        'ListItem.Title',
        'ListItem.Label',
    ):
        label_val = (xbmc.getInfoLabel(info_label) or '').strip()
        if label_val:
            return label_val

    for key in ('searchstring', 'query', 'title'):
        val = (params.get(key) or '').strip()
        if val:
            return val
    for info_label in ('VideoPlayer.Filename', 'Player.Filename'):
        label_val = (xbmc.getInfoLabel(info_label) or '').strip()
        if label_val:
            name = os.path.splitext(os.path.basename(label_val))[0]
            name = re.sub(r'[\._]+', ' ', name)
            name = re.sub(r'\s+', ' ', name).strip()
            if name:
                return name
    if video_path:
        name = os.path.splitext(os.path.basename(video_path))[0]
        name = re.sub(r'[\._]+', ' ', name)
        name = re.sub(r'\s+', ' ', name).strip()
        if name:
            return name
    return ''


def normalize_search_title(value):
    text = re.sub(r'[\._]+', ' ', str(value or '')).strip()
    if not text:
        return ''
    raw_text = re.sub(r'\s+', ' ', text).strip()
    parts = []
    stop_tokens = {
        '2160p', '1080p', '720p', '480p', '4k', 'uhd', 'hdr', 'hdr10', 'webrip', 'webdl',
        'web-dl', 'bluray', 'brrip', 'remux', 'x264', 'x265', 'h264', 'h265', 'hevc',
        'dvdrip', 'proper', 'repack', 'aac', 'ddp', 'dts', 'atmos'
    }
    for token in re.split(r'\s+', text):
        low = token.lower()
        if re.match(r'^(19|20)\d{2}$', low):
            break
        if re.match(r'^[sS]\d{1,2}[eE]\d{1,2}$', token):
            break
        if low in stop_tokens:
            break
        parts.append(token)
    cleaned = ' '.join(parts).strip()
    if len([p for p in parts if p]) < 2:
        return raw_text
    return cleaned or text


def extract_plugin_playback_metadata(video_path):
    out = {}
    if not video_path or not video_path.startswith('plugin://'):
        return out
    try:
        parsed = urllib.parse.urlparse(video_path)
        q = urllib.parse.parse_qs(parsed.query or '')
    except Exception:
        return out

    def qv(key):
        vals = q.get(key) or []
        return str(vals[0]).strip() if vals else ''

    imdb = qv('imdb')
    if imdb:
        out['imdb'] = imdb
    tmdb = qv('tmdb')
    if tmdb:
        out['tmdb'] = tmdb
    title = qv('title') or qv('originaltitle')
    if title:
        out['title'] = title.replace('+', ' ')
    year = qv('year')
    if year and year.isdigit():
        out['year'] = year

    meta_raw = qv('meta')
    if meta_raw:
        try:
            meta = json.loads(urllib.parse.unquote_plus(meta_raw))
            if isinstance(meta, dict):
                if not out.get('title'):
                    t = str(meta.get('originaltitle') or meta.get('title') or '').strip()
                    if t:
                        out['title'] = t
                if not out.get('year'):
                    y = str(meta.get('year') or '').strip()
                    if y.isdigit():
                        out['year'] = y
                if not out.get('imdb'):
                    imdb2 = str(meta.get('imdb') or meta.get('imdbnumber') or '').strip()
                    if imdb2:
                        out['imdb'] = imdb2
                if not out.get('tmdb'):
                    tmdb2 = str(meta.get('tmdb') or '').strip()
                    if tmdb2:
                        out['tmdb'] = tmdb2
        except Exception:
            pass
    return out


def extract_video_search_year(params):
    try:
        player_year = extract_active_player_metadata().get('year')
        if player_year and str(player_year).isdigit():
            return str(player_year)
    except Exception:
        pass
    try:
        meta_year = extract_plugin_playback_metadata(current_video_path()).get('year')
        if meta_year and str(meta_year).isdigit():
            return str(meta_year)
    except Exception:
        pass
    try:
        umbrella_year = umbrella_window_metadata().get('year')
        if umbrella_year and str(umbrella_year).isdigit():
            return str(umbrella_year)
    except Exception:
        pass
    label_val = (xbmc.getInfoLabel('VideoPlayer.Year') or '').strip()
    if label_val and label_val.isdigit():
        return label_val
    premiered = (xbmc.getInfoLabel('VideoPlayer.Premiered') or '').strip()
    m = re.match(r'^(19|20)\d{2}', premiered)
    if m:
        return m.group(0)
    val = (params.get('year') or '').strip()
    return val if val.isdigit() else ''


def extract_video_search_season_episode(params):
    season = ''
    episode = ''

    player_meta = extract_active_player_metadata()
    p_season = str(player_meta.get('season') or '').strip()
    p_episode = str(player_meta.get('episode') or '').strip()
    if p_season.isdigit():
        season = p_season
    if p_episode.isdigit():
        episode = p_episode

    umbrella_meta = umbrella_window_metadata()
    u_season = str(umbrella_meta.get('season') or '').strip()
    u_episode = str(umbrella_meta.get('episode') or '').strip()
    if not season and u_season.isdigit():
        season = u_season
    if not episode and u_episode.isdigit():
        episode = u_episode

    s_label = (xbmc.getInfoLabel('VideoPlayer.Season') or '').strip()
    e_label = (xbmc.getInfoLabel('VideoPlayer.Episode') or '').strip()
    if not season and s_label.isdigit():
        season = s_label
    if not episode and e_label.isdigit():
        episode = e_label

    if not season:
        s_param = (params.get('season') or '').strip()
        if s_param.isdigit():
            season = s_param
    if not episode:
        e_param = (params.get('episode') or '').strip()
        if e_param.isdigit():
            episode = e_param

    return season, episode


def osdb_extract_first_file(attributes):
    for f in (attributes or {}).get('files') or []:
        if not isinstance(f, dict):
            continue
        file_id = f.get('file_id') or f.get('id')
        if not file_id:
            continue
        try:
            fid = int(file_id)
        except Exception:
            continue
        file_name = str(f.get('file_name') or '')
        return fid, file_name
    return None, None


def osdb_search_subtitles(params, video_path, max_results=5):
    identity = build_video_identity_model(video_path, playback_started_at=get_playback_started_at(), params=params)
    player_meta = extract_active_player_metadata()
    playback = extract_plugin_playback_metadata(video_path)
    stream_cinema_meta = stream_cinema_metadata()
    umbrella_meta = umbrella_window_metadata()
    umbrella_release_hint = umbrella_selected_source_hint()
    stream_cinema_release_hint = stream_cinema_selected_source_hint()
    visible_title = best_kodi_title(video_path, params)
    query = normalize_search_title(visible_title or player_meta.get('title') or stream_cinema_meta.get('title') or umbrella_meta.get('title') or playback.get('title') or identity.title or extract_video_search_query(params, video_path))
    imdb_raw = str(player_meta.get('imdb') or stream_cinema_meta.get('imdb') or umbrella_meta.get('imdb') or playback.get('imdb') or identity.imdb_id or '').strip()
    tmdb_raw = str(player_meta.get('tmdb') or stream_cinema_meta.get('tmdb') or umbrella_meta.get('tmdb') or playback.get('tmdb') or '').strip()
    imdb_digits = imdb_raw[2:] if imdb_raw.lower().startswith('tt') else imdb_raw
    if not query and not imdb_digits and not tmdb_raw:
        return []

    req_params = {
        'languages': 'en',
        'order_by': 'download_count',
        'order_direction': 'desc',
        'page': 1,
        'per_page': max(20, min(60, max_results)),
    }
    if imdb_digits.isdigit():
        req_params['imdb_id'] = imdb_digits
    else:
        if query:
            req_params['query'] = query
        if tmdb_raw.isdigit():
            req_params['tmdb_id'] = tmdb_raw
        year = str(player_meta.get('year') or stream_cinema_meta.get('year') or umbrella_meta.get('year') or identity.year or extract_video_search_year(params) or '')
        if year and year.isdigit():
            req_params['year'] = year

    season, episode = extract_video_search_season_episode(params)
    if identity.season is not None:
        season = str(identity.season)
    if identity.episode is not None:
        episode = str(identity.episode)
    if season.isdigit():
        req_params['season_number'] = season
    if episode.isdigit():
        req_params['episode_number'] = episode

    osdb_hash, osdb_size = get_or_compute_video_hash(video_path)
    if osdb_hash and osdb_size:
        req_params['moviehash'] = osdb_hash
        req_params['moviebytesize'] = str(osdb_size)

    log('OSDB direct search params: query="%s" imdb="%s" tmdb="%s" year="%s" season="%s" episode="%s" visible_title="%s" player_title="%s" stream_cinema_title="%s" stream_cinema_release="%s" umbrella_title="%s" umbrella_release="%s" plugin_title="%s" identity_title="%s"' % (
        query or '',
        imdb_digits or '',
        tmdb_raw or '',
        req_params.get('year') or '',
        req_params.get('season_number') or '',
        req_params.get('episode_number') or '',
        visible_title or '',
        player_meta.get('title') or '',
        stream_cinema_meta.get('title') or '',
        stream_cinema_release_hint or '',
        umbrella_meta.get('title') or '',
        umbrella_release_hint or '',
        playback.get('title') or '',
        identity.title or '',
    ))
    data = osdb_request_auth('/subtitles', method='GET', params=req_params, expect_json=True) or {}
    items = []
    for row in data.get('data') or []:
        if not isinstance(row, dict):
            continue
        attrs = row.get('attributes') or {}
        file_id, file_name = osdb_extract_first_file(attrs)
        if not file_id:
            continue
        lang = str(attrs.get('language') or 'en').lower()
        if lang != 'en':
            continue
        release = str(attrs.get('release') or attrs.get('feature_details', {}).get('title') or file_name or 'OpenSubtitles')
        hi = bool(attrs.get('hearing_impaired'))
        downloads = attrs.get('download_count') or attrs.get('new_download_count') or 0
        items.append({
            'file_id': file_id,
            'file_name': file_name or ('opensubtitles_%s.srt' % file_id),
            'label': release,
            'language': lang,
            'hearing_impaired': hi,
            'downloads': downloads,
        })
    return items


def decode_subtitle_payload(raw):
    if not raw:
        raise RuntimeError('Empty subtitle download payload')
    if raw[:2] == b'PK':
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            names = [n for n in zf.namelist() if not n.endswith('/')]
            srt_names = [n for n in names if n.lower().endswith('.srt')]
            pick = srt_names[0] if srt_names else (names[0] if names else None)
            if not pick:
                raise RuntimeError('Downloaded ZIP contains no files')
            return zf.read(pick)
    if raw[:2] == b'\x1f\x8b':
        return gzip.decompress(raw)
    return raw


def osdb_download_subtitle(file_id, name_hint=''):
    payload = {'file_id': int(file_id), 'sub_format': 'srt'}
    data = osdb_request_auth('/download', method='POST', json_body=payload, expect_json=True) or {}
    link = data.get('link') or data.get('download_url')
    if not link:
        raise RuntimeError('OpenSubtitles did not return download link')
    raw, _headers = osdb_request(link, method='GET', expect_json=False, timeout=max(8, osdb_timeout()))
    content = decode_subtitle_payload(raw)
    cache_dir = profile_cache_dir()
    safe_name = re.sub(r'[^A-Za-z0-9._-]+', '_', (name_hint or ('osdb_%s.srt' % file_id))).strip('._')
    if not safe_name.lower().endswith('.srt'):
        safe_name += '.srt'
    out_path = os.path.join(cache_dir, 'osdb_%s_%s' % (int(file_id), safe_name))
    with open(out_path, 'wb') as fh:
        fh.write(content)
    return out_path


def build_translation_context(rows, indexes, window=2, title_hint=''):
    ctx = []
    if title_hint:
        ctx.append('[Movie: %s]' % str(title_hint).strip())
    used = set(indexes)
    for idx in indexes:
        start = max(0, idx - window)
        end = min(len(rows), idx + window + 1)
        for pos in range(start, end):
            if pos in used:
                continue
            text = str((rows[pos] or {}).get('t') or '').strip()
            if text:
                ctx.append(text.replace('\n', ' '))
    return ' '.join(ctx)


def parse_requested_languages(params):
    raw_values = []
    for key in ('languages', 'language', 'preferredlanguage'):
        val = params.get(key, '')
        if val:
            raw_values.extend(re.split(r'[,;/|]+', val))
    if not raw_values:
        # fallback default for your use-case
        raw_values = ['Czech']

    out = []
    seen = set()
    for raw in raw_values:
        token = (raw or '').strip()
        if not token:
            continue
        key = token.lower()
        if key in LANG_MAP:
            target_code, label = LANG_MAP[key]
        else:
            upper = token.upper()
            if upper in [v[0] for v in LANG_MAP.values()]:
                target_code, label = upper, token
            else:
                continue
        if target_code not in seen:
            seen.add(target_code)
            out.append((target_code, label))
    return out or [('CS', 'Czech')]


def _target_lang_aliases(languages):
    aliases = set()
    for code, label in languages or []:
        c = (code or '').strip().lower()
        l = (label or '').strip().lower()
        if c:
            aliases.add(c)
            aliases.add(c.split('-')[0])
        if l:
            aliases.add(l)
            aliases.update(re.split(r'[\s_()/-]+', l))
    # common subtitle filename aliases
    if 'cs' in aliases or 'czech' in aliases:
        aliases.update(['cs', 'cz', 'cze', 'ces', 'czech', 'cesky', 'čeština'])
    if 'sk' in aliases or 'slovak' in aliases:
        aliases.update(['sk', 'slo', 'slk', 'slovak'])
    return {a for a in aliases if a}


def is_generated_or_target_subtitle(path, languages):
    name = os.path.basename(path or '').lower()
    stem = os.path.splitext(name)[0]
    if '.subtrans.' in name or stem.endswith('.subtrans'):
        return True
    # If filename explicitly says EN, keep it as a valid source candidate.
    if any(tok in name for tok in ('.en.', '.eng.', 'english')):
        return False

    # common generated names from Kodi/temp workflows
    if stem.startswith('tempsubtitle') and re.search(r'\.(?:cs|sk|de|fr|es|it|pl|pt|pt-br|nl|sv|da|fi|hu|ro|bg|el|tr|ja|ko|zh|ru|uk|ar|id)$', stem):
        return True

    aliases = _target_lang_aliases(languages)
    if not aliases:
        return False

    tokens = [tok for tok in re.split(r'[^a-z0-9]+', stem) if tok]
    if not tokens:
        return False
    token_set = set(tokens)
    if token_set & aliases:
        return True

    # suffixes like ".cs" or "_czech" (tokenized above in most cases, but keep explicit)
    for alias in aliases:
        if stem.endswith('.' + alias) or stem.endswith('_' + alias) or stem.endswith('-' + alias):
            return True
    return False


def build_plugin_url(**kwargs):
    base = sys.argv[0]
    return base + '?' + urlencode(kwargs)


def normalize_release_hint_text(value):
    return re.sub(r'[^a-z0-9+.-]+', ' ', str(value or '').lower())


def extract_release_tokens(value):
    ignore = set([
        '2160p', '1080p', '720p', '4k', 'uhd', 'web', 'webdl', 'webrip', 'bluray', 'brrip', 'remux',
        'x264', 'x265', 'h264', 'h265', 'hevc', 'aac', 'ddp', 'atmos', 'proper', 'repack', 'internal',
        'extended', 'multi', 'eng', 'english', 'subs', 'subtitles', 'readnfo', 'cleaned', 'forced'
    ])
    out = []
    for tok in normalize_release_hint_text(value).split(' '):
        if not tok or tok in ignore or re.match(r'^(19|20)\d{2}$', tok):
            continue
        if len(tok) < 2 or len(tok) > 15:
            continue
        out.append(tok)
    return set(out)


def extract_release_group(value):
    match = re.search(r'(?:-|\s)([A-Za-z0-9]{2,15})\s*$', str(value or '').strip())
    if not match:
        return ''
    group = str(match.group(1) or '').lower()
    if group in ('srt', 'ass', 'sub', 'en', 'eng', 'proper', 'repack', 'forced'):
        return ''
    return group


def extract_release_profile(value):
    txt = ' %s ' % normalize_release_hint_text(value)
    out = {
        'source': '',
        'source_type': '',
        'codec': '',
        'audio': '',
        'hdr': '',
        'group': extract_release_group(value),
        'tokens': extract_release_tokens(value),
    }
    if re.search(r'\b(amzn|amazon)\b', txt):
        out['source'] = 'amzn'
    elif re.search(r'\b(nf|netflix)\b', txt):
        out['source'] = 'nf'
    elif re.search(r'\b(dsnp|disney)\b', txt):
        out['source'] = 'dsnp'
    elif re.search(r'\b(hmax|max)\b', txt):
        out['source'] = 'hmax'
    elif re.search(r'\b(appletv|atvp)\b', txt):
        out['source'] = 'atvp'
    elif re.search(r'\b(hulu)\b', txt):
        out['source'] = 'hulu'

    if re.search(r'\b(remux)\b', txt):
        out['source_type'] = 'remux'
    elif re.search(r'\b(bluray|blu-ray|brrip)\b', txt):
        out['source_type'] = 'bluray'
    elif re.search(r'\b(web[-.\s]?dl)\b', txt):
        out['source_type'] = 'webdl'
    elif re.search(r'\bwebrip\b', txt):
        out['source_type'] = 'webrip'
    elif re.search(r'\bweb\b', txt):
        out['source_type'] = 'web'

    if re.search(r'\b(x265|hevc|h265)\b', txt):
        out['codec'] = 'x265'
    elif re.search(r'\b(x264|h264)\b', txt):
        out['codec'] = 'x264'

    if re.search(r'\b(atmos)\b', txt):
        out['audio'] = 'atmos'
    elif re.search(r'\b(ddp(?:5\.1|7\.1)?|eac3)\b', txt):
        out['audio'] = 'ddp'
    elif re.search(r'\b(truehd)\b', txt):
        out['audio'] = 'truehd'
    elif re.search(r'\b(dts)\b', txt):
        out['audio'] = 'dts'
    elif re.search(r'\b(aac)\b', txt):
        out['audio'] = 'aac'

    if re.search(r'\b(dovi|dolby vision|dv)\b', txt):
        out['hdr'] = 'dv'
    elif re.search(r'\b(hdr10\+|hdr10|hdr)\b', txt):
        out['hdr'] = 'hdr'
    return out


def release_hint_score(label, release_hint):
    hint = extract_release_profile(release_hint)
    cand = extract_release_profile(label)
    score = 0
    if hint['source']:
        score += 26 if cand['source'] == hint['source'] else (-18 if cand['source'] else 0)
    if hint['source_type']:
        score += 22 if cand['source_type'] == hint['source_type'] else (-14 if cand['source_type'] else 0)
    if hint['codec']:
        score += 12 if cand['codec'] == hint['codec'] else (-10 if cand['codec'] else 0)
    if hint['audio']:
        score += 14 if cand['audio'] == hint['audio'] else (-8 if cand['audio'] else 0)
    if hint['hdr']:
        score += 14 if cand['hdr'] == hint['hdr'] else (-10 if cand['hdr'] else 0)
    if hint['group']:
        score += 36 if cand['group'] == hint['group'] else (-28 if cand['group'] else 0)
    shared = len(hint['tokens'] & cand['tokens'])
    score += min(36, shared * 9)
    return score


def rerank_osdb_items(items, release_hint):
    if not items:
        return []
    identity = build_video_identity_model(current_video_path(), playback_started_at=get_playback_started_at())
    ranked = []
    for item in items or []:
        rel_score = release_hint_score(item.get('label') or item.get('file_name') or item.get('fileName') or '', release_hint)
        engine_score, engine_reasons = score_osdb_item(item, identity, release_hint=release_hint)
        clone = dict(item)
        clone['_provider_rel_score'] = rel_score + engine_score
        clone['_provider_reasons'] = engine_reasons
        ranked.append(clone)
    ranked.sort(key=lambda it: (it.get('_provider_rel_score', 0), int(it.get('confidence') or 0), int(it.get('downloads') or it.get('downloadCount') or 0)), reverse=True)
    return ranked


def is_forced_osdb_item(item):
    txt = ('%s %s' % (item.get('label') or '', item.get('file_name') or item.get('fileName') or '')).lower()
    return ('forced' in txt) or txt.endswith('.en.forced')


def add_result_item(label, label2, url, sync=True, hearing_impaired=False):
    li = xbmcgui.ListItem(label=label)
    try:
        li.setLabel2(label2)
    except Exception:
        pass
    try:
        li.setArt({'icon': 'DefaultAddonSubtitles.png'})
    except Exception:
        pass
    li.setProperty('sync', 'true' if sync else 'false')
    li.setProperty('hearing_imp', 'true' if hearing_impaired else 'false')
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)


def add_separator_item(title):
    li = xbmcgui.ListItem(label=title)
    try:
        li.setLabel2('')
    except Exception:
        pass
    li.setProperty('sync', 'false')
    li.setProperty('hearing_imp', 'false')
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=build_plugin_url(action='noop'),
        listitem=li,
        isFolder=False
    )


def add_info_item(label, label2=''):
    li = xbmcgui.ListItem(label=label)
    try:
        li.setLabel2(label2)
    except Exception:
        pass
    li.setProperty('sync', 'false')
    li.setProperty('hearing_imp', 'false')
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=build_plugin_url(action='noop'),
        listitem=li,
        isFolder=False
    )


def short_release_name(value, max_len=44):
    text = ' '.join(str(value or '').replace('_', ' ').split())
    if len(text) <= max_len:
        return text
    return text[:max_len - 1] + '…'


def rank_local_candidates(cands, video_identity, languages, preferred_paths=None):
    ranked = []
    preferred_paths = preferred_paths or set()
    for src_path in cands or []:
        if is_generated_or_target_subtitle(src_path, languages):
            continue
        source = 'temp' if '/temp/' in src_path.replace('\\', '/').lower() else 'local'
        metadata = inspect_subtitle_file(src_path)
        metadata['preferred'] = src_path in preferred_paths
        candidate = score_candidate(src_path, source, video_identity, metadata=metadata, now=time.time())
        ranked.append(candidate)
    ranked.sort(key=lambda cand: (cand.confidence, cand.entry_count), reverse=True)
    return ranked


def choose_local_source(ranked_candidates):
    if not ranked_candidates:
        return None
    for candidate in ranked_candidates:
        if candidate.tier == 'high':
            return candidate
    for candidate in ranked_candidates:
        if candidate.tier == 'medium':
            return candidate
    return None


def add_local_candidate_items(ranked_candidates, languages, video_title, max_items=3, allow_low=False):
    added = 0
    for candidate in ranked_candidates:
        if candidate.tier == 'low' and not allow_low:
            continue
        target_code, lang_label = languages[0]
        if added >= max_items:
            break
        confidence_prefix = '%s%% ' % candidate.confidence
        label = '%sLOCAL -> %s' % (confidence_prefix, lang_label)
        if candidate.tier == 'high' and added == 0:
            label = '%sLOCAL best -> %s' % (confidence_prefix, lang_label)
        elif candidate.tier == 'low':
            label = '%sLOCAL risky -> %s' % (confidence_prefix, lang_label)
        label2 = short_release_name(os.path.basename(candidate.path), max_len=52)
        if candidate.reasons:
            label2 = '%s | %s' % (label2, ', '.join(candidate.reasons[:2]))
        url = build_plugin_url(
            action='download',
            src_kind='local',
            src=candidate.path,
            target=target_code,
            langlabel=lang_label,
            video_title=video_title
        )
        add_result_item(label, label2, url, sync=True)
        added += 1
    return added


def choose_primary_language(languages):
    if languages:
        return languages[0]
    return ('CS', 'Czech')


# ---------------------------------------------------------------------------
# Provider glue
#
# Everything Kodi-shaped stays on this side of the line. The providers get a
# plain settings callable, a logger, a cache directory and a way to ask the
# user a question -- nothing else -- so the whole search path stays testable
# without Kodi.
# ---------------------------------------------------------------------------

def baked_credentials():
    """Optional credentials compiled into the personal repository build.

    The source file is git-ignored but the personal publisher may include it
    in the release ZIP so a normal repository install needs no TV input.
    """
    try:
        from credentials import CREDENTIALS  # type: ignore
    except ImportError:
        return {}
    except Exception as exc:
        log('credentials.py could not be loaded: %s' % exc, xbmc.LOGWARNING)
        return {}
    return CREDENTIALS if isinstance(CREDENTIALS, dict) else {}


PRIVATE_CREDENTIAL_KEYS = (
    'osdb_api_key', 'osdb_username', 'osdb_password',
    'titulky_username', 'titulky_password', 'backend_secret',
)


def private_credentials_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, 'private_credentials.json')


def load_profile_credentials():
    try:
        with open(private_credentials_path(), 'r', encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {key: str(data.get(key) or '') for key in PRIVATE_CREDENTIAL_KEYS}


def persist_profile_credentials(values):
    """Persist private seed values outside the addon install directory.

    Kodi replaces the install directory during an update but keeps addon_data,
    so one private sideload is enough for all later public code updates.
    """
    path = private_credentials_path()
    payload = {key: str(values.get(key) or '') for key in PRIVATE_CREDENTIAL_KEYS}
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except OSError as exc:
        log('private credentials could not be persisted: %s' % exc, xbmc.LOGWARNING)
        try:
            os.remove(tmp)
        except OSError:
            pass


def private_credentials():
    stored = load_profile_credentials()
    seed = baked_credentials()
    if seed:
        merged = dict(stored)
        for key in PRIVATE_CREDENTIAL_KEYS:
            if seed.get(key):
                merged[key] = str(seed[key])
        persist_profile_credentials(merged)
        return merged
    return stored


BAKED_CREDENTIALS = private_credentials()


def _setting_value(key, default=None):
    """Read a setting without caring which type it was declared as.

    An empty text setting falls back to the baked-in value, so a private build
    works out of the box while a per-device override in the settings dialog
    still takes precedence.
    """
    if isinstance(default, bool):
        return get_bool_setting(key, default)
    if isinstance(default, int):
        return get_int_setting(key, default)
    # The backend token is provisioned as part of the private device profile.
    # Prefer it over any legacy value Kodi may have retained from an older
    # public settings default during an addon update.
    if key == 'backend_secret' and BAKED_CREDENTIALS.get(key):
        return str(BAKED_CREDENTIALS[key])
    value = get_setting_string(key, '' if default is None else str(default))
    if not value and key in BAKED_CREDENTIALS:
        return str(BAKED_CREDENTIALS.get(key) or '')
    return value


def ask_control_code(prompt, image_path):
    """Show a control image and let the user type what it says.

    The image is rendered for a person to read; we never try to solve it
    ourselves. Cancelling simply aborts the download.
    """
    try:
        dialog = xbmcgui.Dialog()
        window = xbmcgui.WindowDialog()
        control = xbmcgui.ControlImage(280, 180, 720, 260, image_path)
        window.addControl(control)
        window.show()
        try:
            return dialog.input(prompt, type=xbmcgui.INPUT_ALPHANUM) or ''
        finally:
            window.close()
    except Exception as exc:
        log('control-code dialog failed: %s' % exc, xbmc.LOGWARNING)
        try:
            return xbmcgui.Dialog().input(prompt, type=xbmcgui.INPUT_ALPHANUM) or ''
        except Exception:
            return ''


def provider_context():
    return ProviderContext(
        settings=_setting_value,
        log=lambda message: log('[providers] %s' % message),
        cache_dir=profile_cache_dir(),
        ask_text=ask_control_code,
        notify=notify,
    )


def build_search_request(params, video_path):
    """Collect everything the providers need out of Kodi, once."""
    identity = build_video_identity_model(
        video_path, playback_started_at=get_playback_started_at(), params=params
    )
    player_meta = extract_active_player_metadata()
    playback = extract_plugin_playback_metadata(video_path)
    stream_cinema_meta = stream_cinema_metadata()
    umbrella_meta = umbrella_window_metadata()
    visible_title = best_kodi_title(video_path, params)
    season, episode = extract_video_search_season_episode(params)
    if identity.season is not None:
        season = str(identity.season)
    if identity.episode is not None:
        episode = str(identity.episode)
    is_episode = bool(season or episode)

    release_hint = ' | '.join(filter(None, [
        str(video_path or ''),
        xbmc.getInfoLabel('VideoPlayer.FileNameAndPath') or '',
        xbmc.getInfoLabel('VideoPlayer.Filename') or '',
        xbmc.getInfoLabel('Player.Filename') or '',
        xbmc.getInfoLabel('ListItem.FileNameAndPath') or '',
        stream_cinema_selected_source_hint(),
        umbrella_selected_source_hint(),
    ]))

    movie_hash, movie_size = get_or_compute_video_hash(video_path)
    return SearchRequest(
        title=normalize_search_title(
            visible_title
            or player_meta.get('title')
            or stream_cinema_meta.get('title')
            or umbrella_meta.get('title')
            or playback.get('title')
            or identity.title
            or extract_video_search_query(params, video_path)
        ),
        year=str(
            player_meta.get('year')
            or stream_cinema_meta.get('year')
            or umbrella_meta.get('year')
            or identity.year
            or extract_video_search_year(params)
            or ''
        ),
        imdb_id=str(
            player_meta.get('imdb')
            or stream_cinema_meta.get('imdb')
            or umbrella_meta.get('imdb')
            or playback.get('imdb')
            or identity.imdb_id
            or ''
        ),
        tmdb_id=str(
            player_meta.get('tmdb')
            or stream_cinema_meta.get('tmdb')
            or umbrella_meta.get('tmdb')
            or playback.get('tmdb')
            or ''
        ),
        release_hint=release_hint,
        movie_hash=movie_hash or '',
        movie_size=movie_size or 0,
        languages=requested_source_languages(),
        video_path=video_path or '',
        media_type='episode' if is_episode else 'movie',
        season=season,
        episode=episode,
    )


def requested_source_languages():
    """Which languages we ask the sources for.

    Czech is always on. Slovak and English are opt-out, because Slovak is a
    perfectly usable finished subtitle for most people here and English is the
    input the translator needs when nothing Czech exists.
    """
    languages = [subtitle_providers.LANG_CS]
    if get_bool_setting('accept_slovak', True):
        languages.append(subtitle_providers.LANG_SK)
    if get_bool_setting('offer_translation', True):
        languages.append(subtitle_providers.LANG_EN)
    return languages


def search_timeouts():
    total = max(4, min(30, get_int_setting('search_total_timeout_sec', 12)))
    per_provider = max(3, min(total, get_int_setting('search_provider_timeout_sec', 8)))
    return total, per_provider


def backend_translate_text(srt_text, target_code, file_name='subtitle.srt', key_hint=''):
    """Translate subtitle text we already hold.

    The backend never sees a search any more, and never sees a finished Czech
    subtitle -- only a foreign source the user explicitly asked to translate.
    """
    data = backend_request('/api/kodi/translate-srt', {
        'srt': srt_text,
        'targetLanguage': target_code,
        'fileName': file_name,
    }, timeout=backend_download_timeout())
    if data.get('subtitle_invalid'):
        reasons = data.get('reasons') or []
        detail = '; '.join(reasons) if reasons else (data.get('error') or 'nepoužitelný zdroj')
        raise RuntimeError('Titulky se nepodařilo použít: %s' % detail)
    translated = data.get('srt') or ''
    if not translated:
        raise RuntimeError('Backend nevrátil přeložené titulky')
    translated = maybe_apply_fps_adjustment(translated)
    return write_srt_text_to_cache(
        translated, data.get('fileName') or file_name, key_hint or file_name
    )


def store_ready_subtitle(srt_text, file_name, key_hint):
    """Write a finished subtitle straight to the cache, no backend involved."""
    text = provider_archive.normalize_newlines(srt_text)
    if str(file_name or '').lower().endswith('.srt'):
        text = maybe_apply_fps_adjustment(text)
    return write_subtitle_text_to_cache(text, file_name, key_hint)


def add_candidate_item(candidate, video_title, target_code, lang_label):
    """One aggregated result row.

    The label has to answer two questions at a glance: what language am I
    getting, and will clicking this cost me a minute of translation. Anything
    marked "→ CZ (překlad)" goes through the backend; everything else lands in
    the player immediately.
    """
    source_label = 'Titulky.com' if candidate.provider == 'titulky' else 'OpenSubtitles'
    if candidate.needs_translation:
        headline = '%s → %s (překlad) · %s' % (candidate.lang_label, lang_label, source_label)
    else:
        headline = '%s · %s · přímé stažení' % (candidate.lang_label, source_label)

    details = [short_release_name(candidate.describe(), max_len=52)]
    details.append('%d %%' % candidate.match_score)
    if candidate.hash_match:
        details.append('přesná shoda souboru')
    elif candidate.match_reasons:
        details.append(', '.join(candidate.match_reasons[:2]))
    if candidate.hearing_impaired:
        details.append('SDH')

    url = build_plugin_url(
        action='download',
        src_kind='provider',
        provider=candidate.provider,
        handle=json.dumps(candidate.handle),
        release_hint_short=short_release_name(candidate.release, max_len=80),
        needs_translation='1' if candidate.needs_translation else '0',
        target=target_code,
        langlabel=lang_label,
        video_title=video_title,
    )
    add_result_item(
        headline,
        ' | '.join(filter(None, details)),
        url,
        sync=candidate.hash_match,
        hearing_impaired=candidate.hearing_impaired,
    )


def render_group(title, candidates, video_title, target_code, lang_label, limit):
    if not candidates:
        return 0
    add_separator_item(title)
    shown = 0
    for candidate in candidates[:limit]:
        add_candidate_item(candidate, video_title, target_code, lang_label)
        shown += 1
    if len(candidates) > limit:
        log('%s: showing %d of %d candidates' % (title, shown, len(candidates)))
    return shown


def run_aggregated_search(request, context, video_title):
    """Query the sources, or reuse a recent answer for the same video.

    Reopening the subtitle dialog is common -- the user browses the list,
    backs out, comes back. Re-running every provider for that is wasted time
    and, for titulky.com, wasted goodwill, so a short-lived cache of the
    metadata answers it instead. Only search results are cached; credentials
    and session cookies never enter this file.
    """
    key = provider_orchestrator.cache_key(request)
    if get_bool_setting('cache_search_results', True):
        cached = provider_orchestrator.load_cached(context, key)
        if cached:
            result = provider_orchestrator.from_cached(cached, request)
            if result is not None:
                log('Reusing cached search (%d results)' % result.total)
                return result

    notify('Hledám titulky pro "%s"...' % (video_title or request.title))
    total_timeout, per_provider_timeout = search_timeouts()
    result = provider_orchestrator.search(
        subtitle_providers.build_providers(context),
        request,
        context,
        total_timeout=total_timeout,
        per_provider_timeout=per_provider_timeout,
    )
    log('Aggregated search: %d CZ, %d SK, %d EN (%s)' % (
        len(result.ready_cs), len(result.ready_sk), len(result.translate),
        '; '.join('%s %.1fs%s' % (o.name, o.elapsed, '' if o.ok else ' FAIL')
                  for o in result.outcomes),
    ))

    # Never cache a partial answer: if a source timed out or errored, the next
    # attempt should get a real chance to include it.
    if result.total and not result.failed_providers and get_bool_setting('cache_search_results', True):
        provider_orchestrator.store_cached(context, key, result.all_candidates)
    return result


def action_search(params):
    try:
        video_path = current_video_path()
        playback_started_at = get_playback_started_at()
        video_identity = build_video_identity_model(
            video_path, playback_started_at=playback_started_at, params=params
        )
        video_title = best_kodi_title(video_path, params) or video_identity.title
        languages = parse_requested_languages(params)
        target_code, lang_label = choose_primary_language(languages)
        added = 0

        # --- local files first: instant, free, and usually the best match ---
        local_candidates = get_current_subtitle_candidates(video_path)
        preferred_paths = get_preferred_subtitle_paths(video_path)
        ranked_local = rank_local_candidates(
            local_candidates, video_identity, languages, preferred_paths=preferred_paths
        ) if local_candidates else []
        local_pool = [c for c in ranked_local if c.tier in ('high', 'medium')][:3]
        local_pool += [c for c in ranked_local if c.tier == 'low'][:3]

        # --- then every online source, in parallel ---
        request = build_search_request(params, video_path)
        context = provider_context()
        result = provider_orchestrator.SearchResult()
        if request.has_identity:
            result = run_aggregated_search(request, context, video_title)
        else:
            log('Skipping online search: no usable title/IMDb/TMDb', xbmc.LOGWARNING)

        limit = max(1, min(20, get_int_setting('results_per_group', 6)))
        added += render_group('=== Hotové české ===', result.ready_cs,
                              video_title, target_code, lang_label, limit)
        added += render_group('=== Hotové slovenské ===', result.ready_sk,
                              video_title, target_code, lang_label, limit)
        added += render_group('=== K překladu ===', result.translate,
                              video_title, target_code, lang_label, limit)

        if local_pool:
            add_separator_item('=== Lokální soubory (překlad) ===')
            added += add_local_candidate_items(
                local_pool, languages, video_title, max_items=6, allow_low=True
            )

        # A source that is down should say so rather than silently shrink the
        # list -- otherwise a broken titulky.com just looks like "no results".
        for outcome in result.failed_providers:
            add_info_item('%s nedostupné' % outcome.label, outcome.error)

        if not added:
            if result.failed_providers:
                notify('Zdroje titulků selhaly: %s' % ', '.join(
                    o.label for o in result.failed_providers
                ))
            else:
                notify('Nenalezeny žádné titulky')
        end_dir(succeeded=True)
    except Exception as e:
        log('action_search failed: %s' % e, xbmc.LOGERROR)
        notify('Chyba provideru (search)')
        end_dir(succeeded=False)


def choose_archive_member(members, release_hint):
    """Ask which file to use when an archive genuinely offers a choice.

    Multi-disc archives and multi-release archives look the same from the
    outside, so rather than guessing silently we let the user pick when there
    is more than one plausible answer.
    """
    if len(members) < 2:
        return None
    if not get_bool_setting('ask_archive_member', True):
        return None
    labels = [short_release_name(os.path.basename(name), max_len=60) for name in members]
    if provider_archive.has_multiple_discs(members):
        heading = 'Archiv obsahuje více disků — vyber soubor'
    else:
        heading = 'Archiv obsahuje více variant — vyber soubor'
    try:
        choice = xbmcgui.Dialog().select(heading, labels)
    except Exception as exc:
        log('archive member dialog failed: %s' % exc, xbmc.LOGWARNING)
        return None
    return members[choice] if choice >= 0 else None


def download_from_provider(params, target_code, progress=None):
    """Fetch a candidate, then either hand it straight to Kodi or translate it.

    This is the split the whole redesign exists for: a finished Czech or Slovak
    subtitle is written to the cache and returned, and the translation backend
    is never contacted. Only an English source takes the slow path.
    """
    provider_name = (params.get('provider') or '').strip()
    try:
        handle = json.loads(unquote_plus(params.get('handle') or '{}'))
    except ValueError:
        raise RuntimeError('Poškozený odkaz na titulky')
    if not isinstance(handle, dict) or not handle:
        raise RuntimeError('Chybí údaje ke stažení titulků')

    context = provider_context()
    provider = None
    for candidate_provider in subtitle_providers.build_providers(context):
        if candidate_provider.name == provider_name:
            provider = candidate_provider
            break
    if provider is None:
        raise RuntimeError('Neznámý zdroj titulků: %s' % provider_name)

    release_hint = unquote_plus(params.get('release_hint_short') or '')
    needs_translation = (params.get('needs_translation') or '0') == '1'

    if progress:
        progress.update(20, 'Stahuji z %s...' % getattr(provider, 'label', provider_name))

    try:
        text, chosen, members = provider.fetch(handle, release_hint=release_hint)
    except ProviderError as exc:
        raise RuntimeError(str(exc))

    if len(members) > 1:
        picked = choose_archive_member(members, release_hint)
        if picked and picked != chosen:
            if progress:
                progress.update(45, 'Načítám vybraný soubor...')
            try:
                text, chosen, members = provider.fetch(
                    handle, release_hint=release_hint, member=picked
                )
            except ProviderError as exc:
                raise RuntimeError(str(exc))

    file_name = os.path.basename(chosen) or ('%s_%s.srt' % (provider_name, handle.get('id') or handle.get('file_id') or 'subtitle'))
    key_hint = '%s|%s|%s' % (provider_name, handle.get('id') or handle.get('file_id'), chosen)

    if not needs_translation:
        if progress:
            progress.update(85, 'Připravuji titulky...')
        return store_ready_subtitle(text, file_name, key_hint)

    if progress:
        progress.update(55, 'Překládám do %s...' % target_code)
    return backend_translate_text(
        text, target_code, file_name=file_name, key_hint='%s|%s' % (key_hint, target_code)
    )


def action_download(params):
    src_kind = (params.get('src_kind') or 'local').lower()
    src = unquote_plus(params.get('src', ''))
    target = (params.get('target', '') or '').upper()
    langlabel = params.get('langlabel', target) or target
    video_title = unquote_plus(params.get('video_title', '') or '').strip()
    if not target:
        notify('Chybí cílový jazyk')
        end_dir(succeeded=False)
        return

    progress = None
    try:
        try:
            progress = xbmcgui.DialogProgress()
            # Only the translation path is slow, so say which one this is.
            if src_kind == 'provider' and (params.get('needs_translation') or '0') != '1':
                heading = 'Stahuji titulky...'
                footer = 'Bez překladu'
            else:
                heading = 'Překlad titulků...'
                footer = 'Cíl: %s' % langlabel
            progress.create('Subtrans', heading, 'Film: %s' % (video_title or 'aktuální video'), footer)
            progress.update(5, 'Načítám titulky...')
        except Exception:
            progress = None

        if src_kind == 'provider':
            out_path = download_from_provider(params, target, progress)
        elif src_kind == 'osdb':
            # Legacy backend path, kept for profiles that have no OpenSubtitles
            # account of their own configured yet.
            file_id_raw = params.get('file_id', '')
            try:
                file_id = int(file_id_raw)
            except Exception:
                raise RuntimeError('Neplatné OpenSubtitles file_id')
            if progress:
                progress.update(15, 'Stahuji + překládám přes backend...')
            name_hint = unquote_plus(params.get('os_name', '') or params.get('os_label', '')) or ('osdb_%s.srt' % file_id)
            out_path = backend_download_translate_osdb(file_id, target, name_hint=name_hint)
        else:
            if not src or not path_is_file_any(src):
                notify('Zdrojové titulky nejsou dostupné')
                end_dir(succeeded=False)
                return
            if progress:
                progress.update(15, 'Překládám místní titulky pro: %s' % (video_title or os.path.basename(src)))
            out_path = backend_translate_local_srt(src, target)
        if progress:
            progress.update(95, 'Vrácení titulků do Kodi...')
        li = xbmcgui.ListItem(label=os.path.basename(out_path))
        li.setProperty('sync', 'true')
        li.setProperty('hearing_imp', 'false')
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=out_path, listitem=li, isFolder=False)
        end_dir(succeeded=True)
        try:
            schedule_post_download_sync(video_title)
        except Exception as sync_exc:
            log('post-download sync hook failed: %s' % sync_exc, xbmc.LOGWARNING)
    except Exception as e:
        log('Download/translate failed: %s' % e, xbmc.LOGERROR)
        notify(str(e))
        end_dir(succeeded=False)
    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass


def schedule_post_download_sync(video_title_hint=''):
    """Background hook: 2s after a subtitle is returned, restore any saved
    offset for this video (local first, then backend) and optionally prompt
    the user to fine-tune timing. Runs in a daemon thread so it doesn't
    block the addon's response to Kodi."""
    import threading

    def worker():
        try:
            time.sleep(2.0)
            video_path = current_video_path()
            if not video_path:
                return
            video_key = build_video_key(video_path)
            label_hint = video_title_hint or video_path
            saved = subtitle_offset_store.get_offset(profile_dir(), video_key)
            if saved is None:
                remote, remote_label = subtitle_offset_store.get_remote_offset(backend_request, video_key)
                if remote is not None:
                    subtitle_offset_store.set_offset(profile_dir(), video_key, remote, label=remote_label or label_hint)
                    saved = remote
                    log('Restored offset from backend store: %+d ms' % saved)
            if saved is not None and saved != 0:
                if apply_subtitle_delay_ms(saved):
                    notify('Obnoven posun titulků: %+d ms' % saved)
                return
            if not get_bool_setting('prompt_for_sync_after_download', True):
                return
            run_subtitle_sync_dialog(video_key, label_hint)
        except Exception as e:
            log('post-download sync worker failed: %s' % e, xbmc.LOGWARNING)

    threading.Thread(target=worker, daemon=True).start()


def run_subtitle_sync_dialog(video_key, video_title_hint=''):
    """Show an adjust dialog with quick nudge buttons. Persists the final
    offset both locally and to the backend store. Loops until the user
    confirms sync or cancels."""
    dialog = xbmcgui.Dialog()
    presets = [
        ('Sedí (konec)', 0, True),
        ('−2 s', -2000, False),
        ('−500 ms', -500, False),
        ('−100 ms', -100, False),
        ('+100 ms', 100, False),
        ('+500 ms', 500, False),
        ('+2 s', 2000, False),
        ('Vymazat paměť', 0, 'clear'),
    ]
    current_offset = get_current_subtitle_delay_ms()
    while True:
        options = ['%s   (nyní: %+d ms)' % (label, current_offset) if i == 0 else label
                   for i, (label, _delta, _flag) in enumerate(presets)]
        choice = dialog.select('Subtrans — posun titulků', options)
        if choice < 0:
            return
        label, delta, flag = presets[choice]
        if flag is True:
            if current_offset != 0:
                subtitle_offset_store.set_offset(profile_dir(), video_key, current_offset, label=video_title_hint)
                subtitle_offset_store.set_remote_offset(backend_request, video_key, current_offset, label=video_title_hint)
                notify('Posun uložen: %+d ms' % current_offset)
            return
        if flag == 'clear':
            subtitle_offset_store.clear_offset(profile_dir(), video_key)
            subtitle_offset_store.clear_remote_offset(backend_request, video_key)
            apply_subtitle_delay_ms(0)
            current_offset = 0
            notify('Paměť posunu vymazána')
            continue
        current_offset += delta
        apply_subtitle_delay_ms(current_offset)


def action_noop():
    end_dir(succeeded=True)


def main():
    try:
        params = get_param_dict()
        action = (params.get('action') or '').lower()
        if action in ('', 'search', 'manualsearch'):
            action_search(params)
        elif action == 'download':
            action_download(params)
        elif action == 'noop':
            action_noop()
        else:
            log('Unknown action: %s params=%s' % (action, params), xbmc.LOGWARNING)
            end_dir(succeeded=False)
    except Exception as e:
        log('Fatal provider error: %s' % e, xbmc.LOGERROR)
        notify('Fatal provider error')
        end_dir(succeeded=False)


if __name__ == '__main__':
    main()
